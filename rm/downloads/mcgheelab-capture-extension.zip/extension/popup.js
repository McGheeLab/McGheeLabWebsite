/* popup.js — toolbar popup. Phase 6b: shows the active tab's detection,
 * a sign-in button, and a Capture button that writes a queued capture
 * record (PDF in Storage + metadata in Firestore) for the dashboard
 * to merge.
 *
 * All Firebase calls happen in the background service worker; the popup
 * just sends messages.
 */

function $(id) { return document.getElementById(id); }

function send(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (resp) => {
      // V3.821 — keep the reason. `lastError` is "Receiving end does not
      // exist" when the service worker could not start; an old worker answers
      // "unknown type: …" to any message it predates.
      const le = chrome.runtime.lastError;
      resolve(resp || { ok: false, error: (le && le.message) || 'no reply from the extension' });
    });
  });
}

/* V3.821 — a stale load. Chrome reads the popup's files from disk every time
 * it opens, but the manifest, the service worker and the content scripts
 * only change when the extension is RELOADED (↻ on chrome://extensions, or a
 * Chrome restart). After a new zip is unpacked over the old folder — or the
 * folder is edited in place — the popup is new and the worker is old, so
 * every new message comes back "unknown type" and the page "can't be read".
 * Compare the manifest on disk with the one Chrome loaded, and offer the one
 * click that fixes it: chrome.runtime.reload() re-reads everything. */
let _staleShown = false;
function isStaleReply(r) {
  const e = r && !r.ok && String(r.error || '');
  return !!e && /unknown type|Receiving end does not exist|no reply from the extension|message port closed/i.test(e);
}
async function checkStale(reason) {
  let disk = '';
  try { disk = String((await (await fetch(chrome.runtime.getURL('manifest.json'))).json()).version || ''); } catch (_) { /* packed install: same as loaded */ }
  const loaded = String((chrome.runtime.getManifest() || {}).version || '');
  if (!reason && (!disk || disk === loaded)) return false;
  showStale(disk, loaded, reason);
  return true;
}
function showStale(disk, loaded, reason) {
  let bar = $('pop-stale');
  if (!bar) {
    bar = document.createElement('div'); bar.id = 'pop-stale'; bar.className = 'pop-stale';
    const first = document.querySelector('.pop-section'); document.body.insertBefore(bar, first || null);
  }
  const what = disk && loaded && disk !== loaded ? `This extension was updated on disk (${esc(disk)}) but Chrome is still running ${esc(loaded)}.` : 'Chrome is running an older copy of this extension than the one on disk.';
  bar.innerHTML = `<div><strong>Reload needed.</strong> ${what}${reason ? ` <span class="pop-stale-why">(${esc(reason)})</span>` : ''}</div><button id="pop-stale-btn" class="pop-btn" type="button">Reload now</button><div class="pop-stale-hint">The popup closes while Chrome reloads it — open it again afterwards. Pages that were already open re-read fine; the extension injects what it needs.</div>`;
  $('pop-stale-btn').addEventListener('click', () => { try { chrome.runtime.reload(); } catch (e) { bar.querySelector('.pop-stale-hint').textContent = 'Could not reload from here: open chrome://extensions and press ↻ on McGhee Lab Capture.'; } });
  _staleShown = true;
}
// Test seam (test/extension-e2e.mjs drives the popup as a tab): module-scoped functions are not globals.
window.__mcgheePopup = { checkStale, isStaleReply, showStale, send, _renderCaptureFailure, _sourceLine, _showLastCapture: (d) => _showLastCapture(d), setActiveTab: (id) => { _activeTabId = id; } };

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

/* V3.819 — quick-open links. Whatever was just loaded (a paper into the
 * library, an item into a purchase request) gets one link that opens it on
 * the lab site. Papers: the single-paper page once it is in items.json;
 * a fresh capture goes through library.html?paper=<id>, which merges the
 * pending captures and then opens the paper. */
const RM_BASE = 'https://mcgheelab.com/rm/pages/';
function paperLink(paperId, fresh) {
  const id = encodeURIComponent(paperId || '');
  return fresh ? `${RM_BASE}library.html?paper=${id}` : `${RM_BASE}library-paper.html?id=${id}`;
}
function openLink(url, label) {
  return `<a href="${esc(url)}" data-open-rm="${esc(url)}" class="pop-open" title="${esc(url)}">${esc(label || 'open')} ↗</a>`;
}
document.addEventListener('click', (ev) => {
  const a = ev.target.closest('[data-open-rm]');
  if (!a) return;
  ev.preventDefault();
  chrome.tabs.create({ url: a.dataset.openRm });
});

async function refreshAuth() {
  const dot = $('pop-dot');
  const userEl = $('pop-user');
  const btn = $('pop-auth-btn');
  const status = $('pop-auth-status');
  const r = await send({ type: 'whoami' });
  const profile = r && r.profile;
  if (profile) {
    dot.classList.add('signed-in');
    userEl.textContent = profile.displayName || profile.email || profile.uid;
    // 0.4.3 — the address Chrome signed in with (an alias is an equal way into the same account)
    userEl.title = 'Signed in with ' + (profile.signedInAs || profile.email || '') +
      (profile.signedInAs && profile.email && profile.signedInAs !== profile.email ? ' — same account as ' + profile.email : '');
    btn.textContent = 'Sign out';
    btn.dataset.action = 'sign-out';
    status.textContent = '';
    status.className = 'pop-status';
  } else {
    dot.classList.remove('signed-in');
    userEl.textContent = 'Not signed in';
    btn.textContent = 'Sign in';
    btn.dataset.action = 'sign-in';
  }
}

// Holds the active tab's last detection so the Capture click handler
// doesn't have to re-query the background mid-flow.
let _activeTabId = null;
let _activeDetection = null;

async function refreshDetection() {
  const root = $('pop-detection');
  const captureSection = $('pop-capture-section');
  // Find active tab.
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    root.innerHTML = '<div class="pop-empty">No active tab.</div>';
    captureSection.style.display = 'none';
    return;
  }
  _activeTabId = tab.id;
  const r = await send({ type: 'get-detection', tabId: tab.id });
  const d = r && r.data;
  _activeDetection = d || null;
  if (!d || (!d.doi && !d.arxiv_id && !d.pmid && !d.pdf_url)) {
    root.innerHTML = '<div class="pop-empty">No paper identifiers detected on this page.</div>';
    captureSection.style.display = 'none';
    return;
  }
  const rows = [];
  if (d.source === 'pdf-tab') {   // V3.823
    rows.push(['This tab', d.from_page ? `the PDF of <a href="${esc(d.from_page)}" data-open-rm="${esc(d.from_page)}" class="pop-open" title="${esc(d.from_page)}">${esc(d.from_page.replace(/^https?:\/\//, '').slice(0, 56))}</a>` : 'a PDF']);
  }
  if (d.title) rows.push(['Title', esc(d.title.slice(0, 140))]);
  if (d.doi) rows.push(['DOI', `<code>${esc(d.doi)}</code> ${openLink('https://doi.org/' + d.doi, 'doi.org')}${d.doi_source === 'pdf-bytes' ? ' <span style="color:#6b7280;">(read from the PDF)</span>' : d.doi_source === 'pii' ? ' <span style="color:#6b7280;">(from the Elsevier id, CrossRef-confirmed)</span>' : d.source === 'doi-link' || d.source === 'doi-text' ? ' <span style="color:#6b7280;">(found on the page)</span>' : ''}`]);   // V3.823 — the DOI as a link
  if (d.arxiv_id) rows.push(['arXiv', `<code>${esc(d.arxiv_id)}</code>`]);
  if (d.pmid) rows.push(['PMID', `<code>${esc(d.pmid)}</code>`]);
  if (d.pdf_url) rows.push(['PDF URL', `<code>${esc(d.pdf_url.slice(0, 80))}${d.pdf_url.length > 80 ? '…' : ''}</code>`]);
  // V3.822/V3.823 — the page's own View PDF / Download PDF route, with a link
  // to click it yourself: pass the journal's human check, then press Capture
  // on the PDF tab (the worker carries this page's DOI and title over).
  const route = d.source !== 'pdf-tab' && d.pdf_candidates && d.pdf_candidates.find((c) => c.url !== d.pdf_url);
  if (route) rows.push(['PDF route', `<code>${esc(route.url.slice(0, 64))}${route.url.length > 64 ? '…' : ''}</code> <a href="${esc(route.url)}" data-open-pdf="${esc(route.url)}" class="pop-open" title="Open the page’s ${esc(route.text || 'PDF')} link in a new tab, as a click would">${esc(route.text || 'open')} ↗</a>`]);
  if (d.source) rows.push(['Source', esc(d.source)]);
  root.innerHTML = rows.map(([k, v]) =>
    `<div class="pop-row"><span class="pop-key">${k}</span><span class="pop-val">${v}</span></div>`
  ).join('');

  captureSection.style.display = 'block';
  const captureBtn = $('pop-capture-btn');
  const captureStatus = $('pop-capture-status');
  const inLibraryHost = $('pop-in-library');
  const hasPdf = !!(d.pdf_url || (d.url && /\.pdf($|\?)/i.test(d.url)) || d.arxiv_id || (d.pdf_candidates && d.pdf_candidates.length));

  if (d.in_library_paper_id) {
    inLibraryHost.style.display = 'block';
    inLibraryHost.innerHTML = `✓ Already in library: <code>${esc(d.in_library_paper_id)}</code> · ${openLink(paperLink(d.in_library_paper_id, false), 'open')}`;
    captureBtn.textContent = 'Re-capture';
    captureBtn.disabled = !hasPdf;
    captureBtn.classList.toggle('pop-btn-disabled', !hasPdf);
    captureBtn.classList.add('pop-btn-ghost');
    captureStatus.textContent = '';
    captureStatus.className = 'pop-status';
  } else {
    inLibraryHost.style.display = 'none';
    inLibraryHost.innerHTML = '';
    captureBtn.textContent = 'Capture';
    captureBtn.classList.remove('pop-btn-ghost');
    captureBtn.disabled = !hasPdf;
    captureBtn.classList.toggle('pop-btn-disabled', !hasPdf);
    captureStatus.textContent = hasPdf ? '' : 'No PDF URL on this page.';
    captureStatus.className = 'pop-status';
    if (d.source === 'pdf-tab' && !d.doi && !d.arxiv_id && !d.title) {   // V3.823
      captureStatus.textContent = 'No identifiers found for this PDF — it would be filed by its hash. Open the article page first (the DOI and title then come along), or capture anyway.';
    }
  }
  $('pop-capture-result').innerHTML = '';
  await _showLastCapture(d);   // V3.824
}

/* V3.824 — a capture's outcome outlives the popup: the worker keeps the last
 * stage / result / error per tab; show it when the popup reopens, and follow
 * the stages live while it is open. */
let _liveCaptureTab = null;
function _fmtTime(iso) { try { return new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); } catch (_) { return ''; } }
async function _showLastCapture(d) {
  if (!_activeTabId) return;
  const r = await send({ type: 'last-capture', tabId: _activeTabId });
  const st = r && r.ok && r.state; if (!st) return;
  const status = $('pop-capture-status'), result = $('pop-capture-result');
  if (st.status === 'running') {
    status.textContent = `Capture in progress (${_fmtTime(st.at)}): ${st.stage || '…'}`; status.className = 'pop-status';
    _liveCaptureTab = _activeTabId;
    return;
  }
  if (!st.outcome) return;
  const when = `<div class="pop-last">Last capture on this tab, ${esc(_fmtTime(st.at))}:</div>`;
  if (st.outcome.ok) { _renderCaptureSuccess(st.outcome.result, status, result); result.innerHTML = when + result.innerHTML; }
  else { _renderCaptureFailure(st.outcome, status, result); result.innerHTML = when + result.innerHTML; }
}
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg.tabId !== 'number' || msg.tabId !== _activeTabId) return;
  if (msg.type === 'capture-stage') { const s = $('pop-capture-status'); if (s) { s.textContent = msg.stage; s.className = 'pop-status'; } }
  if (msg.type === 'capture-done' && msg.outcome) {
    const status = $('pop-capture-status'), result = $('pop-capture-result');
    if (msg.outcome.ok) _renderCaptureSuccess(msg.outcome.result, status, result); else _renderCaptureFailure(msg.outcome, status, result);
  }
});

async function _captureWithOpts(extraMsg) {
  const btn = $('pop-capture-btn');
  const status = $('pop-capture-status');
  const result = $('pop-capture-result');
  if (!_activeTabId) return;
  const w = await send({ type: 'whoami' });
  if (!w || !w.profile) {
    status.textContent = 'Sign in first.';
    status.className = 'pop-status error';
    return;
  }
  btn.disabled = true;
  btn.classList.add('pop-btn-disabled');
  status.textContent = 'Capturing…';
  status.className = 'pop-status';
  result.innerHTML = '';
  const r = await send(Object.assign({ type: 'capture', tabId: _activeTabId }, extraMsg || {}));
  btn.disabled = false;
  btn.classList.remove('pop-btn-disabled');
  return r;
}

async function onCaptureClick() {
  const status = $('pop-capture-status');
  const result = $('pop-capture-result');
  const r = await _captureWithOpts();
  if (r === undefined) return;
  if (!r || !r.ok) { _renderCaptureFailure(r, status, result); return; }
  const res = r.result || {};
  status.textContent = res.dedup ? 'Already captured.' : 'Captured.';
  status.className = 'pop-status ok';
  const sizeKB = res.size_bytes ? Math.round(res.size_bytes / 1024) + ' KB' : '';
  const lines = [];
  if (res.title) lines.push(`<div><strong>${esc(res.title.slice(0, 100))}</strong></div>`);
  lines.push(`<div>id: <code>${esc(res.paper_id || '')}</code></div>`);
  if (res.doi_found === 'pdf' && res.doi) lines.push(`<div>DOI found inside the PDF: <code>${esc(res.doi)}</code> ${openLink('https://doi.org/' + res.doi, 'doi.org')}</div>`);   // V3.823
  if (sizeKB) lines.push(`<div>${sizeKB} · hash <code>${esc((res.hash || '').slice(0, 12))}</code></div>`);
  if (_sourceLine(res.pdf_source)) lines.push(_sourceLine(res.pdf_source));
  lines.push(`<div style="margin-top:4px;">${openLink(paperLink(res.paper_id, !res.dedup), 'Open it in the library')} <span style="color:#6b7280;">— the library merges it as it opens.</span></div>`);
  result.innerHTML = lines.join('');
}

async function onManualUrlClick() {
  const input = $('pop-manual-url');
  const url = String(input.value || '').trim();
  if (!url) {
    $('pop-capture-status').textContent = 'Paste a PDF URL first.';
    $('pop-capture-status').className = 'pop-status error';
    return;
  }
  const result = $('pop-capture-result');
  const status = $('pop-capture-status');
  const r = await _captureWithOpts({ pdfUrlOverride: url });
  if (r === undefined) return;
  if (!r || !r.ok) { _renderCaptureFailure(r, status, result); return; }
  input.value = '';
  _renderCaptureSuccess(r.result, status, result);
}

async function onManualFileChange(ev) {
  const file = ev.target.files && ev.target.files[0];
  if (!file) return;
  if (file.type && file.type !== 'application/pdf' && !/\.pdf$/i.test(file.name)) {
    $('pop-capture-status').textContent = 'Only PDF files are supported.';
    $('pop-capture-status').className = 'pop-status error';
    return;
  }
  const buffer = await file.arrayBuffer();
  // Reset input so the same file can be re-picked after a failure.
  ev.target.value = '';
  const status = $('pop-capture-status');
  const result = $('pop-capture-result');
  const r = await _captureWithOpts({ pdfBuffer: buffer, pdfFilename: file.name });
  if (r === undefined) return;
  if (!r || !r.ok) { _renderCaptureFailure(r, status, result); return; }
  _renderCaptureSuccess(r.result, status, result);
}

/* V3.822 — where the PDF came from, in words; and a failed capture that says
 * what was tried. A PDF Chrome saved but the extension may not read gets the
 * two ways to finish (file access, or upload the saved file). */
const PDF_SOURCE_LABEL = { 'auto-link': 'the page’s PDF link', 'page-fetch': 'fetched as the page (the journal’s own download)', 'browser-download': 'downloaded by Chrome, then read from disk', unpaywall: 'Unpaywall open-access copy', 'manual-url': 'the URL you pasted', 'manual-file': 'the file you uploaded' };
function _sourceLine(src) { if (!src || src === 'auto') return ''; return `<div style="color:#6b7280;font-size:10px;">Source: ${esc(PDF_SOURCE_LABEL[src] || src)}</div>`; }
function _renderCaptureFailure(r, status, result) {
  const err = (r && r.error) || 'Capture failed.';
  if (r && r.needsFileAccess) {
    status.textContent = `Chrome saved ${r.filename || 'the PDF'} to your Downloads, but the extension cannot read it yet.`;
    status.className = 'pop-status error';
    result.innerHTML = `<div class="pop-fileaccess"><div><strong>Finish one of two ways</strong></div>
      <div>1. <button class="pop-link" type="button" data-open-ext-settings>Open extension settings</button>, turn on <strong>Allow access to file URLs</strong>, come back and press <strong>Capture</strong> again — from then on it reads its own downloads.</div>
      <div>2. <strong>Upload file…</strong> below and pick <code>${esc(r.filename || '')}</code> from Downloads.</div></div>`;
    const body = $('pop-manual-body'); if (body) body.style.display = 'block';
    return;
  }
  const lines = String(err).split('\n');
  status.textContent = lines[0];
  status.className = 'pop-status error';
  const rest = lines.slice(1).filter(Boolean);
  // V3.823 — the human route: click the page's own PDF link, pass the check, capture from the PDF tab.
  const d = _activeDetection || {};
  const route = d.source !== 'pdf-tab' ? ((d.pdf_candidates || []).find((c) => c.url) || (d.pdf_url ? { url: d.pdf_url, text: 'PDF' } : null)) : null;
  const hint = route ? `<div class="pop-hint">The journal may want a human: <a href="${esc(route.url)}" data-open-pdf="${esc(route.url)}" class="pop-open">open its ${esc(route.text || 'PDF')} link ↗</a>, pass any check, then press <strong>Capture</strong> on the PDF tab — the DOI and title come along.</div>` : (d.source === 'pdf-tab' ? '<div class="pop-hint">If the PDF link has expired (ScienceDirect links last five minutes), go back to the article and open View PDF again.</div>' : '');
  if (result) result.innerHTML = hint + (rest.length ? `<details class="pop-tried"><summary>What was tried</summary>${rest.map((l) => `<div>${esc(l)}</div>`).join('')}</details>` : '');
}
document.addEventListener('click', (ev) => {
  if (!ev.target.closest('[data-open-ext-settings]')) return;
  ev.preventDefault();
  send({ type: 'open-extension-details' });
});
// V3.823 — open the page's PDF route as a click would: a new tab whose opener
// is this one, so the PDF tab inherits the article's DOI and title.
document.addEventListener('click', (ev) => {
  const a = ev.target.closest('[data-open-pdf]');
  if (!a) return;
  ev.preventDefault();
  const opts = { url: a.dataset.openPdf, active: true };
  if (typeof _activeTabId === 'number') opts.openerTabId = _activeTabId;
  chrome.tabs.create(opts);
});

function _renderCaptureSuccess(res, status, result) {
  res = res || {};
  status.textContent = res.dedup ? 'Already captured.' : 'Captured.';
  status.className = 'pop-status ok';
  const sizeKB = res.size_bytes ? Math.round(res.size_bytes / 1024) + ' KB' : '';
  const lines = [];
  if (res.title) lines.push(`<div><strong>${esc(res.title.slice(0, 100))}</strong></div>`);
  lines.push(`<div>id: <code>${esc(res.paper_id || '')}</code></div>`);
  if (res.doi_found === 'pdf' && res.doi) lines.push(`<div>DOI found inside the PDF: <code>${esc(res.doi)}</code> ${openLink('https://doi.org/' + res.doi, 'doi.org')}</div>`);   // V3.823
  if (sizeKB) lines.push(`<div>${sizeKB} · hash <code>${esc((res.hash || '').slice(0, 12))}</code></div>`);
  if (_sourceLine(res.pdf_source)) lines.push(_sourceLine(res.pdf_source));
  lines.push(`<div style="margin-top:4px;">${openLink(paperLink(res.paper_id, !res.dedup), 'Open it in the library')} <span style="color:#6b7280;">— the library merges it as it opens.</span></div>`);
  result.innerHTML = lines.join('');
}

function _authorLine(authors) {
  if (!Array.isArray(authors) || !authors.length) return '';
  const names = authors.slice(0, 3).map(a => {
    const family = a.family || '';
    const initials = (a.given || '').split(/\s+/).map(s => s[0]).filter(Boolean).join('. ');
    return [family, initials ? initials + '.' : ''].filter(Boolean).join(', ');
  });
  if (authors.length > 3) names.push('et al.');
  return names.join('; ');
}

function _renderSearchResult(meta, idx) {
  const journalYear = [meta.journal, meta.year].filter(Boolean).join(' · ');
  const subtitle = [_authorLine(meta.authors), journalYear].filter(Boolean).join(' — ');
  const idHint = meta.doi
    ? `DOI ${esc(meta.doi)}`
    : meta.arxiv_id
      ? `arXiv ${esc(meta.arxiv_id)}`
      : meta.pmid
        ? `PMID ${esc(meta.pmid)}`
        : '';
  // background.js stamps in_library_paper_id on each result by querying
  // paper_index. When set, render a green "in library" badge instead of
  // the "+ Add" button so the user can see they don't need to re-add.
  const inLib = !!meta.in_library_paper_id;
  const action = inLib
    ? `<span title="Already in library: ${esc(meta.in_library_paper_id)}" style="font-size:11px;padding:3px 10px;background:#dcfce7;color:#166534;border:1px solid #86efac;border-radius:6px;font-weight:600;">✓ In library</span>`
    : `<button class="pop-btn pop-btn-ghost" data-search-add="${idx}" style="padding:3px 10px;font-size:11px;">+ Add</button>`;
  return `
    <div class="pop-search-row" style="padding:8px;border:1px solid #e5e7eb;border-radius:6px;margin-bottom:6px;background:#fff;">
      <div style="font-weight:500;color:#111827;line-height:1.3;">${esc((meta.title || '').slice(0, 140))}</div>
      ${subtitle ? `<div style="color:#6b7280;font-size:10px;margin-top:2px;">${esc(subtitle)}</div>` : ''}
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px;gap:6px;">
        <span style="color:#9ca3af;font-size:10px;">${idHint}</span>
        ${action}
      </div>
    </div>
  `;
}

let _searchResults = [];

async function onSearchClick() {
  const input = $('pop-search-input');
  const status = $('pop-search-status');
  const host = $('pop-search-results');
  const q = input.value.trim();
  if (!q) {
    status.textContent = 'Enter a DOI, arXiv ID, PMID, or title.';
    status.className = 'pop-status error';
    return;
  }
  // Require sign-in for the eventual Add step.
  const w = await send({ type: 'whoami' });
  if (!w || !w.profile) {
    status.textContent = 'Sign in first.';
    status.className = 'pop-status error';
    return;
  }
  status.textContent = 'Searching…';
  status.className = 'pop-status';
  host.innerHTML = '';
  const r = await send({ type: 'search', query: q });
  if (!r || !r.ok) {
    status.textContent = (r && r.error) || 'Search failed.';
    status.className = 'pop-status error';
    return;
  }
  _searchResults = r.results || [];
  if (!_searchResults.length) {
    status.textContent = 'No results.';
    status.className = 'pop-status';
    return;
  }
  // For arXiv/PMID stub results, set a hint about what'll happen.
  const stub = _searchResults.length === 1 && (_searchResults[0].source || '').endsWith('-stub');
  status.textContent = stub
    ? `${_searchResults.length} result (metadata will be filled in by the dashboard sync)`
    : `${_searchResults.length} result${_searchResults.length === 1 ? '' : 's'}`;
  status.className = 'pop-status ok';
  host.innerHTML = _searchResults.map((m, i) => _renderSearchResult(m, i)).join('');
}

async function onSearchResultClick(ev) {
  const btn = ev.target.closest('[data-search-add]');
  if (!btn) return;
  const idx = parseInt(btn.dataset.searchAdd, 10);
  const meta = _searchResults[idx];
  if (!meta) return;
  btn.disabled = true;
  btn.textContent = 'Adding…';
  const r = await send({ type: 'add-by-metadata', metadata: meta, source_url: '' });
  if (!r || !r.ok) {
    btn.disabled = false;
    btn.textContent = '+ Add';
    $('pop-search-status').textContent = (r && r.error) || 'Add failed.';
    $('pop-search-status').className = 'pop-status error';
    return;
  }
  btn.textContent = r.result.dedup ? 'Already queued' : 'Added';
  btn.classList.add('pop-copy-ok');
  if (r.result && r.result.paper_id) {
    const row = btn.closest('.pop-search-row');
    const host = row ? row.querySelector('[data-search-open]') : null;
    const link = openLink(paperLink(r.result.paper_id, true), 'open');
    if (host) host.innerHTML = link;
    else if (row) { const d = document.createElement('div'); d.setAttribute('data-search-open', ''); d.style.cssText = 'font-size:11px;margin-top:4px;'; d.innerHTML = link; row.appendChild(d); }
  }
  // Clear the badge cache via background on success — handled there.
}

/* ---------------- V3.819 — "+ Item" ---------------- */

let _items = [];          // what the content script found, as last rendered
let _itemsPage = { url: '', host: '' };
const SOURCE_LABEL = { jsonld: 'structured data', microdata: 'structured data', vendor: 'vendor page', og: 'page tags', title: 'page title', selection: 'your selection', manual: 'typed' };

function _money(it) {
  if (typeof it.price === 'number') return (it.currency && it.currency !== 'USD' ? it.currency + ' ' : '$') + it.price.toFixed(2);
  return it.priceText || '';
}
function _renderItemRow(it, i) {
  const meta = [it.vendor, it.catalogueNumber, _money(it), it.packSize].filter(Boolean).map(esc).join(' · ');
  const src = SOURCE_LABEL[it.source] || it.source || '';
  return `<div class="pop-item" data-item="${i}">
    <div class="pop-item-head">
      <div style="min-width:0;flex:1;">
        <div class="pop-item-name">${esc(it.name)}${src ? `<span class="pop-item-src">${esc(src)}</span>` : ''}${it.url && it.url !== _itemsPage.url ? ` ${openLink(it.url, 'open')}` : ''}</div>
        ${meta ? `<div class="pop-item-meta">${meta}</div>` : ''}
      </div>
      <button class="pop-btn" data-item-add="${i}" style="padding:4px 10px;font-size:11px;flex:none;">+ Add</button>
    </div>
    <div class="pop-item-form" data-item-form="${i}" style="display:none;"></div>
  </div>`;
}
function _renderItemForm(it, i) {
  const f = (k, label, v, wide, ph) => `<label class="${wide ? 'wide' : ''}">${label}<input data-k="${k}" value="${esc(v ?? '')}" placeholder="${esc(ph || '')}"></label>`;
  return [
    f('name', 'Item *', it.name, true),
    f('vendor', 'Vendor', it.vendor), f('catalogueNumber', 'Catalogue / part #', it.catalogueNumber),
    f('price', 'Unit price ($)', typeof it.price === 'number' ? it.price : '', false, it.priceText || '0.00'), f('quantity', 'Quantity', it._quantity || 1),
    f('packSize', 'Pack size', it.packSize), f('url', 'Link', it.url, false),
    `<label class="wide">Note for the request (optional — why, which project)<textarea data-k="note" placeholder="e.g. for the Friday gel run; charge to the prostate award">${esc(it._note || '')}</textarea></label>`,
    `<div class="pop-item-actions"><button class="pop-btn" data-item-save="${i}" style="padding:5px 12px;font-size:11px;">Add to request</button><button class="pop-btn pop-btn-ghost" data-item-cancel="${i}" style="padding:4px 10px;font-size:11px;">Cancel</button></div>`,
    `<div class="pop-item-err" data-item-err="${i}" style="display:none;"></div>`,
  ].join('');
}

async function refreshItems() {
  const host = $('pop-items');
  const status = $('pop-items-status');
  status.textContent = ''; status.className = 'pop-status';
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { host.innerHTML = '<div class="pop-empty">No active tab.</div>'; return; }
  _activeTabId = tab.id;
  const r = await send({ type: 'get-items', tabId: tab.id });
  const d = r && r.data;
  _items = (d && d.items) || [];
  _itemsPage = { url: (d && d.url) || tab.url || '', host: (d && d.host) || '' };
  if (!d) {
    if (r && r.ok && r.pdfTab) {   // V3.823
      host.innerHTML = '<div class="pop-empty">This tab is a PDF — nothing to buy here. Capture above adds it to the library.</div>';
      return;
    }
    // V3.821 — say WHY. An old service worker (stale load) is the common case
    // and has a one-click fix; a genuinely unreadable tab gets the old advice.
    if (isStaleReply(r)) {
      await checkStale(r.error);
      host.innerHTML = '<div class="pop-empty">The extension needs a reload before it can read pages — use <strong>Reload now</strong> above, then open this popup again.</div>';
      return;
    }
    const err = (r && (r.why || r.error)) || '';
    const why = err ? ` (${esc(err)})` : '';
    host.innerHTML = `<div class="pop-empty">Can’t read this tab${why}. Chrome pages, the Web Store, PDF viewers and file:// tabs are off limits to extensions. On a normal site, reload the page once and try again, or use “add by hand”.</div>`;
    return;
  }
  const partial = Array.isArray(d.errors) && d.errors.length ? ` Part of the page could not be read (${esc(d.errors.join('; ')).slice(0, 200)}).` : '';
  _itemsPage.titleItem = d.titleItem || null;   // V3.823 — for "add by hand"
  if (!_items.length) {
    host.innerHTML = d.paper
      ? '<div class="pop-empty">Nothing to buy here — this tab is a paper (Capture above adds it to the library).</div>'   // V3.823
      : `<div class="pop-empty">Nothing for sale found on this page.${partial} Select the item’s name on the page and re-scan, or add it by hand (it starts with the page’s title).</div>`;
    return;
  }
  host.innerHTML = _items.map(_renderItemRow).join('');
  if (!d.confident) {
    status.textContent = 'No product data on this page — this is just its title. Check the fields before adding.' + partial;
  } else if (partial) {
    status.textContent = partial.trim();
  }
}

function _openItemForm(i, prefill) {
  const form = document.querySelector(`[data-item-form="${i}"]`);
  if (!form) return;
  const it = Object.assign({}, _items[i] || {}, prefill || {});
  form.innerHTML = _renderItemForm(it, i);
  form.style.display = 'grid';
  const btn = document.querySelector(`[data-item-add="${i}"]`); if (btn) btn.style.display = 'none';
  const first = form.querySelector('[data-k="quantity"]'); if (first) { first.focus(); first.select(); }
}
function _closeItemForm(i) {
  const form = document.querySelector(`[data-item-form="${i}"]`); if (form) { form.style.display = 'none'; form.innerHTML = ''; }
  const btn = document.querySelector(`[data-item-add="${i}"]`); if (btn) btn.style.display = '';
}
async function _saveItem(i) {
  const form = document.querySelector(`[data-item-form="${i}"]`); if (!form) return;
  const err = form.querySelector(`[data-item-err="${i}"]`);
  const val = (k) => { const el = form.querySelector(`[data-k="${k}"]`); return el ? el.value.trim() : ''; };
  const w = await send({ type: 'whoami' });
  if (!w || !w.profile) { err.textContent = 'Sign in first (top of this popup).'; err.style.display = 'block'; return; }
  if (!val('name')) { err.textContent = 'The item needs a name.'; err.style.display = 'block'; form.querySelector('[data-k="name"]').focus(); return; }
  const priceRaw = val('price');
  if (priceRaw && !/^\d+(\.\d+)?$/.test(priceRaw)) { err.textContent = 'Unit price must be a plain number — no $ sign.'; err.style.display = 'block'; form.querySelector('[data-k="price"]').focus(); return; }
  const qtyRaw = val('quantity');
  if (qtyRaw && !(/^\d+(\.\d+)?$/.test(qtyRaw) && parseFloat(qtyRaw) > 0)) { err.textContent = 'Quantity must be a number of 1 or more.'; err.style.display = 'block'; form.querySelector('[data-k="quantity"]').focus(); return; }
  err.style.display = 'none';
  const base = _items[i] || { source: 'manual' };
  const item = {
    name: val('name'), vendor: val('vendor'), catalogueNumber: val('catalogueNumber'), price: priceRaw === '' ? null : parseFloat(priceRaw),
    priceText: priceRaw || base.priceText || '', currency: base.currency || 'USD', packSize: val('packSize'), url: val('url'), image: base.image || '',
    description: base.description || '', source: base.source || 'manual',
  };
  const saveBtn = form.querySelector(`[data-item-save="${i}"]`);
  saveBtn.disabled = true; saveBtn.textContent = 'Adding…';
  const r = await send({ type: 'add-item', tabId: _activeTabId, item, quantity: qtyRaw || 1, note: val('note'), sourceUrl: _itemsPage.url, sourceHost: _itemsPage.host });
  if (!r || !r.ok) {
    saveBtn.disabled = false; saveBtn.textContent = 'Add to request';
    err.textContent = (r && r.error) || 'Could not add it.'; err.style.display = 'block';
    return;
  }
  form.innerHTML = `<div class="pop-item-done">Added to your queue. ${openLink(r.rmUrl, 'Open the request on the lab site')}<div style="color:#4d7c0f;font-weight:400;margin-top:2px;">Project, why and one-time/recurring are asked there. The item joins the catalogue only once the request is approved.${r.watchId ? ' The price and this page are saved; it is re-checked every three months.' : ''}</div></div>`;
  form.style.display = 'grid';
  // Open RM straight away — one click from vendor page to a prefilled request.
  try { await chrome.tabs.create({ url: r.rmUrl }); } catch (_) { /* the link above still works */ }
}
function onItemsClick(ev) {
  const add = ev.target.closest('[data-item-add]');
  if (add) { _openItemForm(parseInt(add.dataset.itemAdd, 10)); return; }
  const cancel = ev.target.closest('[data-item-cancel]');
  if (cancel) { _closeItemForm(parseInt(cancel.dataset.itemCancel, 10)); return; }
  const save = ev.target.closest('[data-item-save]');
  if (save) { _saveItem(parseInt(save.dataset.itemSave, 10)); return; }
}
function onItemsManual() {
  // A row at the top. V3.823: on a shop page where nothing was found it starts
  // with the page's title (the old low-confidence "title" item); blank elsewhere.
  const t = (!_items.length && _itemsPage.titleItem) || null;
  const blank = Object.assign({ name: '', vendor: '', catalogueNumber: '', price: null, priceText: '', currency: 'USD', packSize: '', url: _itemsPage.url, image: '', description: '', source: 'manual' }, t ? { name: t.name, vendor: t.vendor, description: t.description } : {});
  _items.unshift(blank);
  $('pop-items').innerHTML = _items.map(_renderItemRow).join('');
  _openItemForm(0);
  const name = document.querySelector('[data-item-form="0"] [data-k="name"]'); if (name) name.focus();
}

document.addEventListener('DOMContentLoaded', () => {
  $('pop-items').addEventListener('click', onItemsClick);
  $('pop-items').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); const f = e.target.closest('[data-item-form]'); if (f) _saveItem(parseInt(f.dataset.itemForm, 10)); }
  });
  $('pop-items-rescan').addEventListener('click', refreshItems);
  $('pop-items-manual').addEventListener('click', onItemsManual);
  checkStale().then(() => refreshItems());   // V3.821 — the reload bar first, then the page
  // V3.820 — price watch status + a manual run
  refreshWatch();
  $('pop-watch-run').addEventListener('click', async () => {
    const btn = $('pop-watch-run'), st = $('pop-watch-status');
    btn.disabled = true; btn.textContent = 'Checking…'; st.textContent = 'Opening the due pages in background tabs (a few seconds each)…'; st.className = 'pop-status';
    const r = await send({ type: 'price-check-now', max: 5 });
    btn.disabled = false; btn.textContent = 'Check now';
    if (!r || !r.ok) { st.textContent = (r && r.error) || 'Check failed.'; st.className = 'pop-status error'; return; }
    if (!r.signedIn) { st.textContent = 'Sign in first.'; st.className = 'pop-status error'; return; }
    st.textContent = r.checked ? `Checked ${r.checked}: ${r.ok} price${r.ok === 1 ? '' : 's'} updated, ${r.failed} could not be read${r.skipped ? `, ${r.skipped} being checked elsewhere` : ''}.` : (r.due ? 'All due pages are being checked by another browser.' : 'Nothing is due.');
    st.className = 'pop-status ok';
    refreshWatch();
  });
});

async function refreshWatch() {
  const line = $('pop-watch-line'); if (!line) return;
  const r = await send({ type: 'price-watch-status' });
  if (!r || !r.ok) { line.textContent = isStaleReply(r) ? 'Price watch: reload the extension first' : 'Price watch: unavailable'; if (isStaleReply(r)) checkStale(r.error); return; }
  if (!r.signedIn) { line.textContent = 'Price watch: sign in to see what is due'; return; }
  line.textContent = r.due ? `Price watch: ${r.due} page${r.due === 1 ? '' : 's'} due for a re-check` : 'Price watch: nothing due (every 3 months, automatic)';
}

document.addEventListener('DOMContentLoaded', () => {
  $('pop-auth-btn').addEventListener('click', async () => {
    const action = $('pop-auth-btn').dataset.action;
    const status = $('pop-auth-status');
    const btn = $('pop-auth-btn');
    btn.disabled = true;
    btn.classList.add('pop-btn-disabled');
    status.textContent = action === 'sign-in' ? 'Signing in…' : 'Signing out…';
    status.className = 'pop-status';
    const r = await send({ type: action });
    btn.disabled = false;
    btn.classList.remove('pop-btn-disabled');
    if (!r || !r.ok) {
      status.textContent = (r && r.error) || 'Failed.';
      status.className = 'pop-status error';
    } else {
      status.textContent = action === 'sign-in' ? 'Signed in.' : 'Signed out.';
      status.className = 'pop-status ok';
    }
    await refreshAuth();
  });

  $('pop-capture-btn').addEventListener('click', onCaptureClick);

  // Search section: collapsible toggle + handlers.
  const toggle = $('pop-search-toggle');
  const body = $('pop-search-body');
  toggle.addEventListener('click', () => {
    const open = body.style.display !== 'none';
    body.style.display = open ? 'none' : 'block';
    toggle.textContent = open ? 'expand' : 'collapse';
    if (!open) setTimeout(() => $('pop-search-input').focus(), 0);
  });
  $('pop-search-btn').addEventListener('click', onSearchClick);
  $('pop-search-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); onSearchClick(); }
  });
  $('pop-search-results').addEventListener('click', onSearchResultClick);

  // Manual capture (6f): expandable section with URL override + file upload.
  const manualToggle = $('pop-manual-toggle');
  const manualBody = $('pop-manual-body');
  manualToggle.addEventListener('click', () => {
    const open = manualBody.style.display !== 'none';
    manualBody.style.display = open ? 'none' : 'block';
    manualToggle.textContent = open ? 'Manual options ▾' : 'Manual options ▴';
  });
  $('pop-manual-url-btn').addEventListener('click', onManualUrlClick);
  $('pop-manual-url').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); onManualUrlClick(); }
  });
  $('pop-manual-file').addEventListener('change', onManualFileChange);

  refreshAuth();
  refreshDetection();
});
