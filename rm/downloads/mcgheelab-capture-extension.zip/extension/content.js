/* content.js — runs on every page. Reads standard scholarly meta tags +
 * URL patterns to decide whether the current page is a paper, and what
 * its identifiers / PDF URL are. Reports the result to the background
 * service worker so the popup + toolbar badge can react.
 *
 * No Firebase calls here — content scripts can't do auth. The background
 * worker owns Firestore/Storage. We just sniff metadata and message.
 */

(function () {
  // ---------------- Detection helpers ----------------

  function meta(names) {
    for (const n of names) {
      const el = document.querySelector(`meta[name="${n}" i], meta[property="${n}" i]`);
      if (el && el.content) return el.content.trim();
    }
    return '';
  }

  function _normalizeDoi(s) {
    if (!s) return '';
    let v = s.trim();
    v = v.replace(/^https?:\/\/(dx\.)?doi\.org\//i, '');
    v = v.replace(/^doi:\s*/i, '');
    return v.toLowerCase();
  }

  function _detectFromMetaAndUrl() {
    const url = location.href;
    const out = { url, doi: '', arxiv_id: '', pmid: '', pdf_url: '', title: '', source: '' };

    out.title = meta(['citation_title', 'dc.title', 'og:title']) || document.title || '';
    // V3.823 — this document IS a PDF (Chrome's viewer, when a content script
    // runs there): the worker then reads the DOI out of the file itself.
    try { out.is_pdf = document.contentType === 'application/pdf'; } catch (_) { out.is_pdf = false; }
    out.doi = _normalizeDoi(
      meta(['citation_doi', 'prism.doi', 'dc.identifier.doi', 'dc.identifier']) ||
      ''
    );
    out.pdf_url = meta(['citation_pdf_url']) || '';

    // Direct PDF URL? Use as-is and try to recover an id from URL.
    if (/\.pdf($|\?)/i.test(url)) {
      out.pdf_url = out.pdf_url || url;
    }

    // arXiv URL pattern
    let m = url.match(/arxiv\.org\/(abs|pdf)\/([\w.\-]+?)(\.pdf)?(?:[?#]|$)/i);
    if (m) {
      out.arxiv_id = m[2].replace(/v\d+$/, '');
      if (!out.pdf_url) out.pdf_url = `https://arxiv.org/pdf/${m[2]}.pdf`;
      out.source = 'arxiv';
    }

    // PubMed URL pattern (pubmed.ncbi.nlm.nih.gov/<pmid>)
    m = url.match(/pubmed\.ncbi\.nlm\.nih\.gov\/(\d+)/);
    if (m) {
      out.pmid = m[1];
      out.source = 'pubmed';
    }

    // PubMed Central URL → PMC<id>
    m = url.match(/ncbi\.nlm\.nih\.gov\/pmc\/articles\/PMC(\d+)/);
    if (m && !out.pdf_url) {
      out.pdf_url = `https://www.ncbi.nlm.nih.gov/pmc/articles/PMC${m[1]}/pdf/`;
    }

    // DOI in URL fallback (works on doi.org/10.xxxx/yyy and many publishers)
    if (!out.doi) {
      const doiMatch = url.match(/\b10\.\d{4,9}\/[-._;()/:A-Z0-9]+/i);
      if (doiMatch) out.doi = _normalizeDoi(doiMatch[0]);
    }

    // V3.823 — a DOI anywhere on the page: a doi.org link inside the article
    // (then anywhere), or a "DOI: 10.…" line in the text. Publisher pages
    // without citation_* tags, repositories, lab sites.
    if (!out.doi) {
      const scope = document.querySelector('article, main, [role="main"], #main-content, .article') || document;
      const link = scope.querySelector('a[href*="doi.org/10."]') || document.querySelector('a[href*="doi.org/10."]');
      if (link) { out.doi = _normalizeDoi(link.getAttribute('href').replace(/^.*doi\.org\//i, '').split(/[?#]/)[0]); if (out.doi) out.source = 'doi-link'; }
      if (!out.doi) {
        const text = (scope.innerText || document.body && document.body.innerText || '').slice(0, 200000);
        const dm = text.match(/\bdoi\s*:?\s*(?:https?:\/\/(?:dx\.)?doi\.org\/)?(10\.\d{4,9}\/[-._;()/:A-Z0-9]+)/i);
        if (dm) { out.doi = _normalizeDoi(dm[1].replace(/[.,;:)]+$/, '')); if (out.doi) out.source = 'doi-text'; }
      }
    }
    if (out.doi && !out.source) out.source = 'doi';
    if (!out.source && out.pdf_url) out.source = 'pdf';
    return out;
  }

  // ---------------- Reporting ----------------

  const detected = _detectFromMetaAndUrl();

  // V3.819 — items for sale on this page (scrape-items.js runs before this
  // file; see manifest content_scripts order). Only the COUNT travels on
  // load — the popup re-scrapes live when it opens.
  function _itemsNow() {
    // V3.821 — a thrown error travels back as { error } so the popup can say
    // why instead of "can't read this tab"; `null` means the scraper is not
    // on this page (a tab opened before this version loaded).
    try { return window.__mcgheeScrapeItems ? window.__mcgheeScrapeItems() : null; }
    catch (e) { return { error: 'scrape failed: ' + ((e && e.message) || String(e)) }; }
  }
  function _confidentItemCount() {
    const r = _itemsNow();
    return r && r.confident && Array.isArray(r.items) ? r.items.length : 0;
  }

  // Send a one-shot notification with the detected info. The background
  // worker stores it keyed by tab id so the popup can read it.
  try {
    chrome.runtime.sendMessage({ type: 'paper-detected', data: detected, items: _confidentItemCount() }, () => {
      // Ignore — background may not be listening if the extension reloaded.
      void chrome.runtime.lastError;
    });
  } catch (_) { /* no-op */ }

  // Reply to background queries with the latest detection result. Re-running
  // detection on each query handles SPAs that update meta tags without a
  // full page reload.
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'request-detection') {
      sendResponse(_detectFromMetaAndUrl());
      return true;
    }
    if (msg && msg.type === 'request-items') {
      sendResponse(_itemsNow());
      return true;
    }
    return false;
  });
})();
