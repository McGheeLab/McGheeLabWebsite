/* scrape-items.js — V3.819 "+ Item". Finds the things for sale on the
 * current page so the popup can offer them for a purchase request.
 *
 * Classic content script (no imports): defines window.__mcgheeScrapeItems()
 * → { url, host, title, selection, items: [...] }. content.js answers the
 * background's 'request-items' with it.
 *
 * Sources, most trustworthy first:
 *   1. JSON-LD  — schema.org Product / Offer / ItemList (most vendors and
 *      every Shopify/Magento-style shop emit it).
 *   2. Microdata — [itemtype*="schema.org/Product"] with itemprop fields.
 *   3. Vendor selectors — Fisher/Thermo, Sigma/Millipore, VWR, Amazon,
 *      McMaster-Carr, Cole-Parmer, Digi-Key, Grainger, BuyWays/Jaggaer.
 *   4. Open Graph product tags, then the page title as a last resort.
 *   Plus the current text selection ("use what I highlighted").
 *
 * Every item: { name, vendor, catalogueNumber, price (number|null),
 *   priceText, currency, packSize, url, image, description, source }
 * Nothing here touches the network or Firebase.
 */
(function () {
  'use strict';

  var MAX_ITEMS = 20;
  var VENDOR_BY_HOST = [
    [/fishersci\./i, 'Fisher Scientific'], [/thermofisher\./i, 'Thermo Fisher'], [/sigmaaldrich\.|emdmillipore\.|merckmillipore\./i, 'Sigma-Aldrich'],
    [/vwr\.|avantorsciences\./i, 'VWR / Avantor'], [/amazon\./i, 'Amazon'], [/mcmaster\./i, 'McMaster-Carr'], [/coleparmer\./i, 'Cole-Parmer'],
    [/digikey\./i, 'Digi-Key'], [/grainger\./i, 'Grainger'], [/buyways\.arizona\.edu|jaggaer\./i, 'BuyWays (UA)'], [/neb\.com/i, 'New England Biolabs'],
    [/qiagen\./i, 'Qiagen'], [/bio-rad\./i, 'Bio-Rad'], [/corning\./i, 'Corning'], [/usascientific\./i, 'USA Scientific'], [/idtdna\./i, 'IDT'],
    [/promega\./i, 'Promega'], [/abcam\./i, 'Abcam'], [/cellsignal\./i, 'Cell Signaling'], [/thomassci\./i, 'Thomas Scientific'], [/newark\.|mouser\./i, 'Mouser / Newark'],
  ];

  function str(v) { return v == null ? '' : String(v).replace(/\s+/g, ' ').trim(); }
  function txt(sel, root) { var el = (root || document).querySelector(sel); return el ? str(el.textContent) : ''; }
  function attr(sel, name, root) { var el = (root || document).querySelector(sel); return el ? str(el.getAttribute(name)) : ''; }
  function meta(names) {
    for (var i = 0; i < names.length; i++) {
      var el = document.querySelector('meta[property="' + names[i] + '" i], meta[name="' + names[i] + '" i], meta[itemprop="' + names[i] + '" i]');
      if (el && el.content) return str(el.content);
    }
    return '';
  }
  function abs(u) { try { return u ? new URL(u, location.href).href : ''; } catch (e) { return ''; } }
  function httpUrl(u) { u = abs(u); return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : ''; }
  /** "$1,234.56" / "USD 12.50" / "12.5" → 12.5; "Request a quote" → null. */
  function priceNum(s) {
    if (s == null || s === '') return null;
    if (typeof s === 'number') return isFinite(s) && s >= 0 ? s : null;
    var t = String(s).replace(/,/g, '');
    var m = t.match(/(?:\$|US\$|USD|EUR|€|£|GBP)\s*(\d+(?:\.\d+)?)/i) || t.match(/(\d+(?:\.\d+)?)\s*(?:USD|EUR|GBP|\$)/i);
    if (!m) { var only = t.match(/^\s*(\d+(?:\.\d+)?)\s*$/); m = only; }
    if (!m) return null;
    var n = parseFloat(m[1]);
    return isFinite(n) && n >= 0 ? n : null;
  }
  function currencyOf(s) {
    s = String(s || '');
    if (/€|EUR/i.test(s)) return 'EUR'; if (/£|GBP/i.test(s)) return 'GBP'; if (/\$|USD/i.test(s)) return 'USD';
    return '';
  }
  function vendorFromHost(host) {
    host = host || location.hostname;
    for (var i = 0; i < VENDOR_BY_HOST.length; i++) if (VENDOR_BY_HOST[i][0].test(host)) return VENDOR_BY_HOST[i][1];
    var parts = host.replace(/^www\./, '').split('.');
    var core = parts.length > 2 && /^(co|com|ac|org)$/.test(parts[parts.length - 2]) ? parts[parts.length - 3] : parts[parts.length - 2] || parts[0];
    return core ? core.charAt(0).toUpperCase() + core.slice(1) : host;
  }
  function makeItem(o, source) {
    var priceText = str(o.priceText || (typeof o.price === 'number' ? String(o.price) : o.price));
    var item = {
      name: str(o.name).slice(0, 300),
      vendor: str(o.vendor) || vendorFromHost(),
      catalogueNumber: str(o.catalogueNumber).slice(0, 80),
      price: priceNum(o.price != null && o.price !== '' ? o.price : priceText),
      priceText: priceText.slice(0, 60),
      currency: str(o.currency) || currencyOf(priceText),
      packSize: str(o.packSize).slice(0, 80),
      url: httpUrl(o.url) || location.href,
      image: httpUrl(o.image),
      description: str(o.description).slice(0, 400),
      source: source,
    };
    return item.name ? item : null;
  }

  /* ─── 1. JSON-LD ─────────────────────────────────────────── */
  function jsonLdNodes() {
    var out = [];
    var scripts = document.querySelectorAll('script[type="application/ld+json" i]');
    for (var i = 0; i < scripts.length; i++) {
      var raw = scripts[i].textContent; if (!raw) continue;
      try { var parsed = JSON.parse(raw); walk(parsed, out, 0); } catch (e) { /* malformed JSON-LD is common; skip */ }
    }
    return out;
  }
  function walk(node, out, depth) {
    if (!node || depth > 6) return;
    if (Array.isArray(node)) { node.forEach(function (n) { walk(n, out, depth + 1); }); return; }
    if (typeof node !== 'object') return;
    out.push(node);
    if (node['@graph']) walk(node['@graph'], out, depth + 1);
    if (node.itemListElement) walk(node.itemListElement, out, depth + 1);
    if (node.item) walk(node.item, out, depth + 1);
    if (node.mainEntity) walk(node.mainEntity, out, depth + 1);
    if (node.offers) walk(node.offers, out, depth + 1);
  }
  function typeIs(node, t) {
    var ty = node && node['@type']; if (!ty) return false;
    return Array.isArray(ty) ? ty.some(function (x) { return String(x).toLowerCase() === t; }) : String(ty).toLowerCase() === t;
  }
  function offerPrice(offers) {
    if (!offers) return { price: null, text: '', currency: '' };
    var list = Array.isArray(offers) ? offers : [offers];
    for (var i = 0; i < list.length; i++) {
      var o = list[i]; if (!o || typeof o !== 'object') continue;
      var p = o.price != null ? o.price : (o.lowPrice != null ? o.lowPrice : (o.priceSpecification && o.priceSpecification.price));
      if (p != null && p !== '') return { price: priceNum(p), text: String(p), currency: str(o.priceCurrency || (o.priceSpecification && o.priceSpecification.priceCurrency)) };
    }
    return { price: null, text: '', currency: '' };
  }
  function fromJsonLd() {
    var items = [];
    jsonLdNodes().forEach(function (n) {
      if (!typeIs(n, 'product') && !typeIs(n, 'individualproduct') && !typeIs(n, 'productmodel')) return;
      var op = offerPrice(n.offers);
      var brand = n.brand && (typeof n.brand === 'string' ? n.brand : n.brand.name);
      var seller = n.offers && (Array.isArray(n.offers) ? n.offers[0] : n.offers); seller = seller && seller.seller && seller.seller.name;
      var img = Array.isArray(n.image) ? n.image[0] : (n.image && typeof n.image === 'object' ? n.image.url : n.image);
      items.push(makeItem({
        name: n.name, vendor: str(seller) || '', catalogueNumber: n.sku || n.mpn || n.productID || n.gtin13 || n.gtin || '',
        price: op.price, priceText: op.text, currency: op.currency, url: n.url || (n.offers && !Array.isArray(n.offers) && n.offers.url) || '',
        image: img, description: [brand ? 'Brand: ' + str(brand) : '', str(n.description)].filter(Boolean).join(' · '),
      }, 'jsonld'));
    });
    return items.filter(Boolean);
  }

  /* ─── 2. Microdata ───────────────────────────────────────── */
  function fromMicrodata() {
    var items = [];
    var nodes = document.querySelectorAll('[itemtype*="schema.org/Product" i], [itemtype*="schema.org/IndividualProduct" i]');
    for (var i = 0; i < nodes.length && items.length < MAX_ITEMS; i++) {
      var root = nodes[i];
      var prop = function (p) { var el = root.querySelector('[itemprop="' + p + '"]'); if (!el) return ''; return str(el.getAttribute('content') || el.getAttribute('href') || el.getAttribute('src') || el.textContent); };
      items.push(makeItem({ name: prop('name'), catalogueNumber: prop('sku') || prop('mpn') || prop('productID'), price: prop('price'), currency: prop('priceCurrency'), url: prop('url'), image: prop('image'), description: prop('description') }, 'microdata'));
    }
    return items.filter(Boolean);
  }

  /* ─── 3. Vendor selectors ────────────────────────────────── */
  function firstText(sels, root) { for (var i = 0; i < sels.length; i++) { var t = txt(sels[i], root); if (t) return t; } return ''; }
  function labelled(re) {
    // "Catalog No. 12-345-67" style labels anywhere in the main content.
    var body = document.body ? (document.body.innerText || '') : '';
    var m = body.match(re); return m ? str(m[1]) : '';
  }
  var VENDORS = [
    { match: /fishersci\.|thermofisher\./i, vendor: null, one: function () {
        return { name: firstText(['h1[class*="product" i]', '.product-title h1', 'h1']) , catalogueNumber: firstText(['[class*="catalog-number" i] span', '[class*="catalogNumber" i]', '[class*="cat-num" i]', '[data-testid*="catalog" i]']) || labelled(/Catalog\s*(?:No\.?|Number|#)[:\s]*([A-Z0-9][A-Z0-9.\-\/]+)/i),
                 priceText: firstText(['[class*="product-price" i] [class*="price" i]', '[class*="productPrice" i]', '[data-testid*="price" i]', '[class*="price" i] .value', '[class*="price" i]']), packSize: labelled(/(?:Pack|Case|Unit)\s*(?:Size|of)?[:\s]*([^\n]{1,40})/i) }; } },
    { match: /sigmaaldrich\.|emdmillipore\.|merckmillipore\./i, vendor: null, one: function () {
        // /US/en/product/aldrich/753084 → the product number is in the URL even before the app renders.
        var fromUrl = (location.pathname.match(/\/product\/[^\/]+\/([A-Za-z0-9.\-]+)/) || [])[1] || '';
        return { name: firstText(['h1[class*="product" i]', 'h1[class*="Product" i]', 'h1']), catalogueNumber: firstText(['[class*="product-number" i]', '[class*="productNumber" i]', '[data-testid*="product-number" i]', '[class*="catalog" i]']) || labelled(/Product\s*(?:No\.?|Number)[:\s]*([A-Z0-9][A-Z0-9.\-]+)/i) || fromUrl,
                 priceText: firstText(['[class*="price" i]', '[class*="Price" i]']) }; },
      many: function () {   // the SKU table: "753084-5G … $45.60" per pack size
        return variantRows(/\b([A-Z0-9]{3,}-?\d*[A-Z]*\d+[A-Z]*(?:-[A-Z0-9]+)?)\b/, function (row) { return /\b\d{3,}-\d+[A-Z]*\b/.test(row); });
      } },
    { match: /vwr\.|avantorsciences\./i, vendor: null, one: function () {
        return { name: firstText(['h1.product-title', 'h1.pdp-title', '[class*="product-name" i]', 'h1']), catalogueNumber: firstText(['[class*="catalog-number" i]', '[class*="product-code" i]', '.cat-number']) || labelled(/(?:Catalog|Cat\.?)\s*(?:No\.?|Number|#)[:\s]*([A-Z0-9][A-Z0-9.\-\/]+)/i),
                 priceText: firstText(['[class*="product-price" i]', '.pdp-price', '[class*="price" i]']) }; },
      many: function () {   // the variants table (Spartacus app): one row per pack, "76520-944 … Carton of 1,000 … $246.57"
        return variantRows(/\b(\d{5}-\d{3})\b/, null, '.display-price');
      } },
    { match: /amazon\./i, vendor: 'Amazon', one: function () {
        var asin = attr('[data-asin]', 'data-asin') || (location.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/) || [])[1] || '';
        return { name: txt('#productTitle') || txt('#title'), catalogueNumber: asin ? 'ASIN ' + asin : '', priceText: firstText(['#corePrice_feature_div .a-offscreen', '#corePriceDisplay_desktop_feature_div .a-offscreen', '#priceblock_ourprice', '#priceblock_dealprice', '.a-price .a-offscreen']),
                 image: attr('#landingImage', 'src'), url: asin ? 'https://www.amazon.com/dp/' + asin : '' }; },
      many: function () {   // the cart
        var rows = document.querySelectorAll('.sc-list-item[data-asin], [data-name="Active Items"] .sc-list-item');
        var out = []; for (var i = 0; i < rows.length; i++) { var r = rows[i]; var asin = r.getAttribute('data-asin') || '';
          out.push({ name: txt('.sc-product-title, .a-truncate-full, .sc-product-link', r), catalogueNumber: asin ? 'ASIN ' + asin : '', priceText: txt('.sc-product-price, .a-price .a-offscreen', r), url: asin ? 'https://www.amazon.com/dp/' + asin : '', image: attr('img.sc-product-image', 'src', r) }); }
        return out; } },
    { match: /mcmaster\./i, vendor: 'McMaster-Carr', one: function () {
        return { name: txt('h1') || meta(['og:title']), catalogueNumber: (location.pathname.match(/\/([0-9]{3,}[A-Z0-9]*)\/?$/) || [])[1] || labelled(/\b(\d{4,6}[A-Z]\d{1,4})\b/), priceText: firstText(['[class*="Price" i]', '[class*="price" i]']) }; } },
    { match: /coleparmer\./i, vendor: null, one: function () { return { name: txt('h1'), catalogueNumber: labelled(/Item\s*#?\s*[:\s]*([A-Z]{1,3}-\d{5}-\d{2})/i), priceText: firstText(['[class*="price" i]']) }; } },
    { match: /digikey\./i, vendor: null, one: function () { return { name: txt('h1'), catalogueNumber: labelled(/DigiKey\s*Part\s*Number[:\s]*([A-Z0-9][A-Z0-9.\-\/]+)/i) || labelled(/Manufacturer\s*Product\s*Number[:\s]*([A-Z0-9][A-Z0-9.\-\/]+)/i), priceText: firstText(['[data-testid*="price" i]', '[class*="price" i]']) }; } },
    { match: /grainger\./i, vendor: null, one: function () { return { name: txt('h1'), catalogueNumber: labelled(/Item\s*#?\s*[:\s]*([A-Z0-9]{4,8})\b/i), priceText: firstText(['[class*="price" i]']) }; } },
    { match: /buyways\.arizona\.edu|jaggaer\./i, vendor: null, one: function () {
        return { name: firstText(['h1', '[class*="item-name" i]', '[class*="itemName" i]', '[class*="product-title" i]']), catalogueNumber: firstText(['[class*="part-number" i]', '[class*="partNumber" i]', '[class*="sku" i]', '[class*="catalog" i]']) || labelled(/(?:Part|SKU|Catalog|Item)\s*(?:No\.?|Number|#)?[:\s]*([A-Z0-9][A-Z0-9.\-\/]+)/i),
                 priceText: firstText(['[class*="price" i]', '[class*="Price" i]', '[class*="cost" i]']) }; },
      many: function () {   // cart lines
        var rows = document.querySelectorAll('[class*="cart-line" i], [class*="LineItem" i], tr[class*="line-item" i]');
        var out = []; for (var i = 0; i < rows.length; i++) { var r = rows[i]; out.push({ name: firstText(['[class*="description" i]', '[class*="name" i]', 'a'], r), catalogueNumber: firstText(['[class*="part" i]', '[class*="sku" i]', '[class*="catalog" i]'], r), priceText: firstText(['[class*="price" i]'], r) }); }
        return out; } },
  ];
  /**
   * Variant tables on app-rendered vendor pages (VWR, Sigma): every price
   * element sits in a row that also carries the pack's catalogue number. Walk
   * up from each price to the smallest ancestor whose text has a catalogue
   * token, and make one item per token: "<h1> — <token>, <pack>" with that
   * row's price. `catRe` captures the token; `rowOk` may veto a row; `priceSel`
   * is the per-row price element (default: any leaf starting with "$").
   */
  /** A node's text with a space between every text node — textContent glues
   * "<span>76520-944</span><span>50 ml</span>" into "76520-94450 ml". */
  function textOf(node) {
    var parts = [];
    try { var w = document.createTreeWalker(node, NodeFilter.SHOW_TEXT); while (w.nextNode()) parts.push(w.currentNode.nodeValue); }
    catch (e) { return str(node.textContent); }
    return str(parts.join(' '));
  }
  function variantRows(catRe, rowOk, priceSel) {
    var h1 = txt('h1') || meta(['og:title']) || str(document.title).replace(/\s*\|.*$/, '');
    var priceEls = priceSel ? document.querySelectorAll(priceSel) : Array.prototype.filter.call(document.querySelectorAll('span, div, td, p, b, strong'), function (el) { return el.children.length === 0 && /^\s*(?:\$|USD)\s?\d/.test(el.textContent || ''); });
    var out = [], seen = {};
    for (var i = 0; i < priceEls.length && out.length < MAX_ITEMS; i++) {
      var el = priceEls[i], node = el, row = null, m = null;
      for (var up = 0; up < 8 && node && node !== document.body; up++) {
        node = node.parentElement; if (!node) break;
        var text = textOf(node); if (text.length > 700) break;
        m = text.match(catRe);
        if (m) { row = node; break; }
      }
      if (!row || !m) continue;
      var rowText = textOf(row);
      if (rowOk && !rowOk(rowText)) continue;
      var cat = m[1]; if (seen[cat]) continue; seen[cat] = 1;
      var pack = (rowText.match(/\b((?:Carton|Case|Pack|Box|Bag|Bottle|Each|Pkg\.?|Pk\.?)(?:\s+of)?\s+[\d,]+[^$]{0,20}?)(?=\s*\$|\s*$)/i) || rowText.match(/\b(\d+(?:\.\d+)?\s?(?:mL|ml|L|g|kg|mg|µL|ea|pcs|pk))\b/) || [])[1] || '';
      var priceText = str(el.textContent);
      out.push({ name: h1 + (cat ? ' — ' + cat : '') + (pack ? ', ' + str(pack) : ''), catalogueNumber: cat, priceText: priceText, packSize: str(pack) });
    }
    return out;
  }

  function fromVendor() {
    for (var i = 0; i < VENDORS.length; i++) {
      var v = VENDORS[i]; if (!v.match.test(location.hostname)) continue;
      var vendor = v.vendor || vendorFromHost();
      var items = [];
      if (v.many) (v.many() || []).forEach(function (o) { if (o && str(o.name)) { o.vendor = vendor; var it = makeItem(o, 'vendor'); if (it) items.push(it); } });
      if (!items.length && v.one) { var o = v.one() || {}; o.vendor = vendor; var it = makeItem(o, 'vendor'); if (it) items.push(it); }
      return items;
    }
    return [];
  }

  /* ─── 4. Open Graph / title ──────────────────────────────── */
  function fromOg() {
    var name = meta(['og:title', 'twitter:title']);
    var price = meta(['product:price:amount', 'og:price:amount', 'price']);
    var isProduct = /product/i.test(meta(['og:type'])) || !!price;
    if (!isProduct || !name) return [];
    var it = makeItem({ name: name, price: price, currency: meta(['product:price:currency', 'og:price:currency']), catalogueNumber: meta(['product:retailer_item_id', 'product:sku', 'sku']), url: meta(['og:url']), image: meta(['og:image']), description: meta(['og:description', 'description']) }, 'og');
    return it ? [it] : [];
  }
  /* ─── 5. The page as printed text ────────────────────────── */
  /** What a person would read off a print-out: lines with a price, and the
   * catalogue number / pack size on the same or the few lines above. Works
   * on app-rendered shops with no markup worth the name. */
  var CAT_TOKEN = /\b([A-Z]{0,4}\d{3,}(?:[-–.\/]\d+[A-Z]*|[A-Z]{1,3})?[A-Z0-9]*|[A-Z0-9]{2,}[-–]\d{2,}[A-Z0-9-]*)\b/;
  var PACK_TOKEN = /\b((?:Carton|Case|Pack|Box|Bag|Bottle|Each|Pkg\.?|Pk\.?)(?:\s+of)?\s+[\d,]+[^$\n]{0,20}?|\d+(?:\.\d+)?\s?(?:mL|ml|L|g|kg|mg|µL|ea|pcs|pk|units?))\b/i;
  function pageText() {
    try { return str(document.body ? document.body.innerText : '').length ? document.body.innerText : ''; } catch (e) { return ''; }
  }
  function fromText() {
    var text = pageText(); if (!text) return [];
    var lines = text.split(/\n+/).map(function (l) { return l.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
    var h1 = txt('h1') || meta(['og:title']) || str(document.title).replace(/\s*[|–-]\s*[^|–-]*$/, '');
    var out = [], seen = {};
    for (var i = 0; i < lines.length && out.length < MAX_ITEMS; i++) {
      var pm = lines[i].match(/(?:\$|US\$|USD)\s?\d[\d,]*(?:\.\d{2})?/);
      if (!pm) continue;
      var window = lines.slice(Math.max(0, i - 4), i + 1).join(' ');
      var cm = window.match(CAT_TOKEN), pk = window.match(PACK_TOKEN);
      var cat = cm ? cm[1] : '';
      if (!cat && out.length) continue;                 // a second price with no number of its own is the same thing again
      var key = cat || 'page';
      if (seen[key]) continue; seen[key] = 1;
      out.push(makeItem({ name: h1 + (cat ? ' — ' + cat : '') + (pk ? ', ' + str(pk[1]) : ''), catalogueNumber: cat, priceText: pm[0], packSize: pk ? str(pk[1]) : '' }, 'text'));
    }
    return out.filter(Boolean);
  }

  /** V3.823 — a paper page (ScienceDirect, MDPI, PubMed…) is never a shop:
   * scholarly meta tags or a DOI / arXiv / PubMed URL. */
  function isPaperPage() {
    if (meta(['citation_doi', 'citation_title', 'citation_pdf_url', 'dc.identifier', 'prism.doi'])) return true;
    var u = location.href;
    return /\b10\.\d{4,9}\/[-._;()/:A-Z0-9]+/i.test(u) || /arxiv\.org\/(abs|pdf)\/|pubmed\.ncbi\.nlm\.nih\.gov\/\d+|ncbi\.nlm\.nih\.gov\/pmc\/articles\/|biorxiv\.org\/content\/|doi\.org\//i.test(u);
  }
  function fromTitle() {
    var name = txt('h1') || meta(['og:title']) || document.title;
    var it = makeItem({ name: name, description: meta(['description']).slice(0, 200) }, 'title');
    return it ? [it] : [];
  }

  /* ─── Merge ──────────────────────────────────────────────── */
  function key(it) { return (it.catalogueNumber || '').toLowerCase().replace(/[^a-z0-9]/g, '') || it.name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 60); }
  function dedupe(lists) {
    var out = [], seen = {};
    lists.forEach(function (list) { (list || []).forEach(function (it) {
      if (!it) return; var k = key(it); if (!k) return;
      if (seen[k]) {   // a later, weaker source may still fill a blank
        var have = seen[k]; ['catalogueNumber', 'priceText', 'image', 'packSize', 'description'].forEach(function (f) { if (!have[f] && it[f]) have[f] = it[f]; });
        if (have.price == null && it.price != null) { have.price = it.price; have.currency = have.currency || it.currency; }
        return;
      }
      seen[k] = it; out.push(it);
    }); });
    return out.slice(0, MAX_ITEMS);
  }

  function scrapeItems() {
    var sel = '', errors = [];
    // V3.821 — each source on its own: a vendor rule or odd markup that throws
    // costs that source, not the whole page, and the popup is told.
    function safe(name, fn) { try { return fn() || []; } catch (e) { errors.push(name + ': ' + ((e && e.message) || String(e))); return []; } }
    try { sel = str(window.getSelection && window.getSelection().toString()).slice(0, 300); } catch (e) {}
    // V3.823 — a paper page (ScienceDirect, MDPI…) is never a shop: its title
    // is not an item, and its "Purchase PDF $35.95" line is not a price.
    var paper = false; try { paper = isPaperPage(); } catch (e) {}
    var strong = dedupe([safe('jsonld', fromJsonLd), safe('microdata', fromMicrodata)]);
    var items = strong.length ? dedupe([strong, safe('vendor', fromVendor)]) : dedupe([safe('vendor', fromVendor), safe('og', fromOg)]);
    // Nothing priced from markup? Read the page as printed text (V3.820) — not on a paper page.
    if (!paper && !items.some(function (it) { return it.price != null; })) items = dedupe([items, safe('text', fromText)]);
    var confident = items.length > 0;
    // A bare page title is no longer offered as an item; it travels as
    // `titleItem` so "add by hand" can prefill the name on a real shop page.
    var titleItem = null;
    if (!items.length && !paper) { var t = safe('title', fromTitle); titleItem = t[0] || null; }
    // A selection becomes a candidate of its own (the page may describe one thing and the person wants another line of it).
    if (sel && sel.length >= 3 && !items.some(function (it) { return it.name.toLowerCase() === sel.toLowerCase(); })) {
      var s = makeItem({ name: sel }, 'selection'); if (s) items.unshift(s);
    }
    // `text` = the page as printed (capped): saved with a price so the number can be re-read later (V3.820 price watch).
    return { url: location.href, host: location.hostname, title: str(document.title), selection: sel, confident: confident, paper: paper, titleItem: titleItem, items: items.slice(0, MAX_ITEMS), text: pageText().slice(0, 40000), errors: errors };
  }

  window.__mcgheeScrapeItems = scrapeItems;
  window.__mcgheeScrapeItemsInternal = { priceNum: priceNum, vendorFromHost: vendorFromHost, fromJsonLd: fromJsonLd, fromMicrodata: fromMicrodata, fromVendor: fromVendor, fromOg: fromOg, fromText: fromText, fromTitle: fromTitle, isPaperPage: isPaperPage, variantRows: variantRows, dedupe: dedupe };
})();
