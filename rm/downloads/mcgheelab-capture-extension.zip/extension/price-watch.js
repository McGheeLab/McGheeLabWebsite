/* price-watch.js — V3.820. The impure half of price watch, for the
 * background service worker: writes observations + page snapshots to
 * Firestore (REST), and runs the three-monthly re-scrape by opening each due
 * product page in a background tab, injecting scrape-items.js, and reading
 * the price back.
 *
 *   recordObservation(obs, {text, title})  → { id, doc } | null
 *   runDueChecks({ max })                   → { checked, ok, failed, skipped, due }
 *   watchStatus()                           → { due, signedIn }
 *
 * Why the browser and not a Cloud Function: vendor pages block server-side
 * fetches and render in JavaScript. The alarm fires every six hours; a
 * 2-hour lease (claimedAt) keeps several lab browsers from scraping the same
 * page; at most `max` tabs per run, one at a time, closed when done.
 */
import {
  getCurrentUser,
  firestoreGetDoc,
  firestoreSetDoc,
  firestoreUpdateFields,
  firestoreCollectionAdd,
  firestoreRunQuery,
} from './firebase-rest.js';
import {
  watchIdFor, mergeWatch, failedCheckPatch, pickItemForWatch, isClaimed, SNAPSHOT_MAX,
} from './price-watch-core.js';

const SETTLE_MS = 7000;
const LOAD_TIMEOUT_MS = 35000;

export async function recordObservation(obs, opts = {}) {
  const id = watchIdFor(obs && obs.url);
  if (!id) return null;
  const profile = await getCurrentUser();
  if (!profile) throw new Error('Not signed in.');
  const now = new Date().toISOString();
  const existing = await firestoreGetDoc(`priceWatch/${id}`);
  const doc = mergeWatch(existing, obs, now, profile.uid);
  if (!doc) return null;
  await firestoreSetDoc(`priceWatch/${id}`, doc);
  if (opts.text) {
    try {
      await firestoreCollectionAdd(`priceWatch/${id}/snapshots`, {
        at: now, url: doc.url, title: String(opts.title || '').slice(0, 300), text: String(opts.text).slice(0, SNAPSHOT_MAX),
        price: doc.latest.price, currency: doc.currency, method: doc.latest.method, by: profile.uid,
      });
    } catch (e) { console.warn('[price-watch] snapshot not saved:', e && e.message); }
  }
  return { id, doc };
}

async function dueWatches(limit) {
  const now = new Date().toISOString();
  const rows = await firestoreRunQuery({
    from: [{ collectionId: 'priceWatch' }],
    where: { fieldFilter: { field: { fieldPath: 'nextCheckAt' }, op: 'LESS_THAN_OR_EQUAL', value: { stringValue: now } } },
    orderBy: [{ field: { fieldPath: 'nextCheckAt' }, direction: 'ASCENDING' }],
    limit: limit || 10,
  });
  return rows.filter((r) => r.data && (r.data.status || 'active') === 'active' && r.data.url);
}

export async function watchStatus() {
  const profile = await getCurrentUser();
  if (!profile) return { due: 0, signedIn: false };
  try { const due = await dueWatches(50); return { due: due.length, signedIn: true }; }
  catch (e) { return { due: 0, signedIn: true, error: e && e.message }; }
}

function waitForTabComplete(tabId) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpd); resolve(); };
    const onUpd = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t && t.status === 'complete') finish(); }).catch(finish);
    setTimeout(finish, LOAD_TIMEOUT_MS);
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Open the watched page in a background tab, scrape it, record the result. */
export async function checkWatch(watch, uid) {
  const id = watch.id;
  const now = new Date().toISOString();
  let tab = null, data = null, err = '';
  try {
    tab = await chrome.tabs.create({ url: watch.url, active: false });
    await waitForTabComplete(tab.id);
    await sleep(SETTLE_MS);
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['scrape-items.js'] });
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (window.__mcgheeScrapeItems ? window.__mcgheeScrapeItems() : null) });
    data = (res && res[0] && res[0].result) || null;
  } catch (e) {
    err = (e && e.message) || String(e);
  } finally {
    if (tab) { try { await chrome.tabs.remove(tab.id); } catch (_) { /* already gone */ } }
  }
  const pick = data ? pickItemForWatch(data.items, watch) : null;
  if (pick && pick.price != null) {
    await recordObservation({ url: watch.url, price: pick.price, currency: pick.currency || watch.currency, vendor: watch.vendor || pick.vendor, catalogueNumber: watch.catalogueNumber || pick.catalogueNumber, name: watch.name || pick.name, method: 'rescrape' }, { text: data.text, title: data.title });
    return { ok: true, id, price: pick.price };
  }
  const patch = failedCheckPatch(watch, now, uid, err || (data ? 'no price on the page' : 'page could not be read'));
  await firestoreUpdateFields(`priceWatch/${id}`, patch);
  return { ok: false, id, error: patch.lastError };
}

export async function runDueChecks(opts = {}) {
  const max = opts.max || 3;
  const profile = await getCurrentUser();
  if (!profile) return { checked: 0, ok: 0, failed: 0, skipped: 0, due: 0, signedIn: false };
  const due = await dueWatches(10);
  const out = { checked: 0, ok: 0, failed: 0, skipped: 0, due: due.length, signedIn: true, results: [] };
  const nowMs = Date.now();
  for (const row of due) {
    if (out.checked >= max) break;
    const watch = Object.assign({ id: row.id }, row.data);
    if (isClaimed(watch, nowMs)) { out.skipped++; continue; }
    const now = new Date().toISOString();
    try { await firestoreUpdateFields(`priceWatch/${watch.id}`, { claimedAt: now, claimedBy: profile.uid, updatedAt: now, lastActorUid: profile.uid }); }
    catch (e) { out.skipped++; continue; }   // someone else got it, or no write access
    out.checked++;
    try {
      const r = await checkWatch(watch, profile.uid);
      if (r.ok) out.ok++; else out.failed++;
      out.results.push(r);
    } catch (e) {
      out.failed++; out.results.push({ ok: false, id: watch.id, error: (e && e.message) || String(e) });
    }
  }
  return out;
}
