/* search.js — phase 6e. CrossRef-backed search and identifier lookup,
 * plus a "metadata-only" path into `pending_captures` for papers the
 * user wants to track but doesn't have a PDF for yet. The dashboard
 * sync materializes these as paper items with `meta.library.pdf = null`.
 *
 * CrossRef supports CORS + JSON, so the worker can hit it directly.
 * arXiv (Atom XML) and PubMed (XML/JSON) are deliberately not parsed
 * here — we hand off arXiv/PMID-only searches to phase 6c which has
 * access to the dashboard's /api/library/lookup proxy.
 */

import {
  firestoreSetDoc,
  firestoreGetDoc,
  getCurrentUser,
} from './firebase-rest.js';

const STOP_WORDS = new Set([
  'a', 'an', 'the', 'of', 'and', 'or', 'in', 'on', 'for', 'to', 'with',
  'from', 'by', 'as', 'at', 'is', 'are', 'be', 'this', 'that', 'using',
  'via', 'over', 'under', 'between', 'into',
]);

/* ---------------- Public ---------------- */

/**
 * Classify a free-text query so the popup knows whether to do an
 * identifier lookup or a bibliographic search.
 */
export function classifyQuery(q) {
  const s = String(q || '').trim();
  if (!s) return null;
  // DOI patterns: bare 10.xxxx/yyy or any doi.org URL.
  if (/^10\.\d{4,9}\//.test(s) || /doi\.org\//i.test(s)) {
    return { kind: 'doi', value: _normalizeDoi(s) };
  }
  // arXiv: explicit prefix or post-2007 nnnn.nnnnn pattern.
  if (/^arxiv:/i.test(s) || /^\d{4}\.\d{4,5}(v\d+)?$/.test(s)) {
    return { kind: 'arxiv', value: s.replace(/^arxiv:\s*/i, '').replace(/v\d+$/, '') };
  }
  // PubMed: explicit prefix or a bare 6-9 digit integer.
  if (/^pmid:\s*\d+$/i.test(s) || /^\d{6,9}$/.test(s)) {
    return { kind: 'pmid', value: s.replace(/^pmid:\s*/i, '') };
  }
  return { kind: 'text', value: s };
}

/**
 * Free-text bibliographic search via CrossRef. Returns up to `limit`
 * results in unified shape.
 */
export async function searchByText(text, limit = 8) {
  const fields = 'DOI,title,author,issued,container-title,short-container-title,volume,issue,page,abstract,URL';
  const url = `https://api.crossref.org/works?query=${encodeURIComponent(text)}&rows=${limit}&select=${fields}`;
  const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
  if (!res.ok) throw new Error(`CrossRef search failed (${res.status})`);
  const j = await res.json();
  const items = (j.message && j.message.items) || [];
  return items.map(_crossrefRow).filter(r => r.title);
}

/**
 * Resolve a single classified identifier into unified metadata. For
 * arXiv / PMID we return a stub (just the id) so the dashboard sync
 * can do the proper lookup via /api/library/lookup later.
 */
export async function lookupByIdentifier(classified) {
  if (!classified) return null;
  if (classified.kind === 'doi') {
    const url = `https://api.crossref.org/works/${encodeURIComponent(classified.value)}`;
    const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if (!res.ok) throw new Error(`CrossRef lookup failed (${res.status})`);
    const j = await res.json();
    return _crossrefRow(j.message);
  }
  if (classified.kind === 'arxiv') {
    return _stub({ arxiv_id: classified.value, source: 'extension-search-stub' });
  }
  if (classified.kind === 'pmid') {
    return _stub({ pmid: classified.value, source: 'extension-search-stub' });
  }
  return null;
}

/**
 * Add a metadata-only entry to pending_captures (no PDF). The dashboard
 * sync materializes this into a paper item with `meta.library.pdf = null`,
 * which the library page renders as "no PDF" with a DOI link.
 */
export async function addMetadataOnly(metadata, sourceUrl) {
  if (!metadata) throw new Error('No metadata to add.');
  const profile = await getCurrentUser();
  if (!profile) throw new Error('Not signed in.');

  const paperId = _mintIdFromMeta(metadata);

  // Cheap dedupe: if a pending_captures doc already exists at this id,
  // surface that instead of writing a duplicate.
  try {
    const existing = await firestoreGetDoc(`pending_captures/${paperId}`);
    if (existing) {
      return { paper_id: paperId, dedup: true, dedup_source: 'pending_captures', metadata };
    }
  } catch (_) { /* not fatal */ }

  await firestoreSetDoc(`pending_captures/${paperId}`, {
    paper_id: paperId,
    captured_at_iso: new Date().toISOString(),
    captured_by_uid: profile.uid,
    captured_by_email: profile.email || '',
    captured_by_name: profile.displayName || '',
    source_url: sourceUrl || '',
    detection: {
      doi: metadata.doi || '',
      arxiv_id: metadata.arxiv_id || '',
      pmid: metadata.pmid || '',
      pdf_url: '',
      title: metadata.title || '',
      source: metadata.source || 'extension-search',
    },
    metadata,
    pdf: null,         // signal "metadata-only"
    status: 'pending',
  });

  return { paper_id: paperId, dedup: false, metadata };
}

/* ---------------- Internals ---------------- */

function _normalizeDoi(s) {
  return String(s || '')
    .replace(/^https?:\/\/(dx\.)?doi\.org\//i, '')
    .replace(/^doi:\s*/i, '')
    .toLowerCase();
}

function _stub(extra) {
  return Object.assign({
    title: '', authors: [], year: '', journal: '',
    doi: '', arxiv_id: '', pmid: '',
  }, extra);
}

function _crossrefRow(m) {
  if (!m) return null;
  const authors = (m.author || []).map(a => ({
    given: a.given || '',
    family: a.family || a.name || '',
  }));
  const issued = (m.issued && m.issued['date-parts'] && m.issued['date-parts'][0]) || [];
  return {
    source: 'crossref',
    title: Array.isArray(m.title) ? (m.title[0] || '') : (m.title || ''),
    authors,
    year: issued[0] ? String(issued[0]) : '',
    journal: Array.isArray(m['container-title']) ? (m['container-title'][0] || '') : (m['container-title'] || ''),
    journal_iso: Array.isArray(m['short-container-title']) ? (m['short-container-title'][0] || '') : '',
    volume: m.volume || '',
    issue: m.issue || '',
    pages: m.page || '',
    doi: (m.DOI || '').toLowerCase(),
    pmid: '',
    arxiv_id: '',
    url: m.URL || (m.DOI ? `https://doi.org/${m.DOI}` : ''),
    abstract: m.abstract || '',
  };
}

function _slug(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

function _shortTitleWord(t) {
  return (t || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter(w => w && !STOP_WORDS.has(w))[0] || '';
}

function _mintIdFromMeta(meta) {
  const a = (meta.authors && meta.authors[0]) || null;
  const lastName = a && a.family ? _slug(a.family) : '';
  const year = String(meta.year || '').slice(0, 4);
  const titleWord = _shortTitleWord(meta.title || '');
  if (lastName || year) {
    return [lastName, year, titleWord].filter(Boolean).join('-');
  }
  if (meta.doi)      return _slug(meta.doi);
  if (meta.arxiv_id) return `arxiv-${_slug(meta.arxiv_id)}`;
  if (meta.pmid)     return `pmid-${meta.pmid}`;
  return `paper-${Date.now().toString(36)}`;
}

// Test hooks.
export const _internals = { classifyQuery, _crossrefRow, _mintIdFromMeta, _slug, _shortTitleWord, _normalizeDoi };
