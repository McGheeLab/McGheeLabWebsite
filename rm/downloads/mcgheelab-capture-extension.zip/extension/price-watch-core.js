/* price-watch-core.js — V3.820. The pure part of price watch: how a product
 * URL becomes a watch id, how an observation merges into a watch record, when
 * the next check is due, which scraped item is the watched one.
 *
 * No chrome.*, no fetch — node-testable (test/price-watch-core.test.mjs).
 * KEEP IN SYNC with rm/js/procurement-core.js (normalizeProductUrl,
 * watchIdFor, newWatchDoc): both sides must compute the same doc id or the
 * site and the extension will keep two records of one page.
 */

export const CHECK_EVERY_DAYS = 90;
export const RETRY_DAYS = 7;
export const MAX_RETRY_DAYS = 30;
export const MAX_FAILURES = 4;
export const CLAIM_TTL_MS = 2 * 60 * 60 * 1000;
export const SNAPSHOT_MAX = 40000;
const DAY = 86400000;
const KEEP_QUERY = ['sku', 'productid', 'product_id', 'id', 'catalognumber', 'catalog', 'item', 'itemid', 'asin', 'pid', 'variant', 'code', 'productcode'];

function str(v) { return v == null ? '' : String(v).trim(); }

/** Host without www, path without trailing slash, Amazon collapsed to /dp/ASIN, only product-identifying query keys, sorted. '' when not http(s). */
export function normalizeProductUrl(u) {
  let x;
  try { x = new URL(str(u)); } catch (e) { return ''; }
  if (!/^https?:$/.test(x.protocol)) return '';
  const host = x.hostname.toLowerCase().replace(/^www\./, '');
  let path = x.pathname.replace(/\/+/g, '/').replace(/\/+$/, '');
  const asin = path.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})(?:[/?]|$)/i);
  if (/(^|\.)amazon\./.test(host) && asin) path = '/dp/' + asin[1].toUpperCase();
  const q = [];
  x.searchParams.forEach((v, k) => { if (KEEP_QUERY.indexOf(k.toLowerCase()) >= 0 && v) q.push(k.toLowerCase() + '=' + v); });
  q.sort();
  return host + path + (q.length ? '?' + q.join('&') : '');
}
function fnv1a(s, seed) {
  let h = seed >>> 0;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return ('00000000' + h.toString(16)).slice(-8);
}
/** 'fishersci-com-<16 hex>' — stable for one product page across the site and the extension. '' when the URL is not watchable. */
export function watchIdFor(u) {
  const n = normalizeProductUrl(u);
  if (!n) return '';
  const host = n.split('/')[0].replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
  return host + '-' + fnv1a(n, 2166136261) + fnv1a(n, 0x9747b28c);
}
export function hostOf(u) { const n = normalizeProductUrl(u); return n ? n.split('/')[0] : ''; }

/** When to look again: 90 days after a good read; 7 × failures days (≤ 30) after a miss. */
export function nextCheckAfter(nowMs, ok, failures) {
  const days = ok ? CHECK_EVERY_DAYS : Math.min(MAX_RETRY_DAYS, RETRY_DAYS * Math.max(1, failures || 1));
  return new Date(nowMs + days * DAY).toISOString();
}
export function isClaimed(watch, nowMs) {
  const t = Date.parse(watch && watch.claimedAt || '');
  return isFinite(t) && nowMs - t < CLAIM_TTL_MS;
}
function normCat(s) { return str(s).toLowerCase().replace(/[^a-z0-9]/g, ''); }
/** The scraped item that IS the watched product: same catalogue number, else the one whose name contains the watched name's first words, else the first with a price. */
export function pickItemForWatch(items, watch) {
  const list = (items || []).filter((it) => it && it.price != null);
  if (!list.length) return null;
  const wc = normCat(watch && watch.catalogueNumber);
  if (wc) { const hit = list.find((it) => normCat(it.catalogueNumber) === wc || normCat(it.name).indexOf(wc) >= 0); if (hit) return hit; }
  const words = str(watch && watch.name).toLowerCase().split(/\s+/).filter((w) => w.length > 2).slice(0, 3);
  if (words.length) { const hit = list.find((it) => words.every((w) => str(it.name).toLowerCase().indexOf(w) >= 0)); if (hit) return hit; }
  return list[0];
}

/** A clean observation or null. obs: { url, price, currency?, vendor?, catalogueNumber?, name?, method, ticketId?, inventoryItemId? } */
export function cleanObservation(obs) {
  const o = obs || {};
  const price = typeof o.price === 'number' ? o.price : parseFloat(o.price);
  if (!isFinite(price) || price < 0 || !normalizeProductUrl(o.url)) return null;
  return {
    url: str(o.url).slice(0, 1000), price: +price.toFixed(2), currency: str(o.currency) || 'USD', vendor: str(o.vendor).slice(0, 120),
    catalogueNumber: str(o.catalogueNumber).slice(0, 80), name: str(o.name).slice(0, 300),
    method: ['capture', 'request', 'rescrape', 'manual'].indexOf(o.method) >= 0 ? o.method : 'manual',
    ticketId: str(o.ticketId) || null, inventoryItemId: str(o.inventoryItemId) || null,
  };
}

/** The whole watch document after this observation (REST PATCH replaces the doc, so every field is here). */
export function mergeWatch(existing, obs, nowISO, uid) {
  const ex = existing || {};
  const o = cleanObservation(obs);
  if (!o) return null;
  const nowMs = Date.parse(nowISO);
  const entry = { at: nowISO, price: o.price, method: o.method, by: uid };
  const history = (Array.isArray(ex.history) ? ex.history : []).concat([entry]);
  const ticketIds = (Array.isArray(ex.ticketIds) ? ex.ticketIds : []).slice();
  if (o.ticketId && ticketIds.indexOf(o.ticketId) < 0) ticketIds.push(o.ticketId);
  const fresh = o.method === 'rescrape' || !ex.nextCheckAt;   // a typed request price never reschedules a live watch
  return {
    url: o.url, normUrl: normalizeProductUrl(o.url), host: hostOf(o.url),
    vendor: o.vendor || str(ex.vendor), catalogueNumber: o.catalogueNumber || str(ex.catalogueNumber), name: o.name || str(ex.name), currency: o.currency,
    latest: entry, history,
    lastCheckedAt: fresh ? nowISO : (ex.lastCheckedAt || nowISO),
    nextCheckAt: fresh ? nextCheckAfter(nowMs, true, 0) : ex.nextCheckAt,
    checkEveryDays: CHECK_EVERY_DAYS, status: 'active', failures: 0, lastError: null, claimedAt: null, claimedBy: null,
    inventoryItemId: o.inventoryItemId || ex.inventoryItemId || null, ticketIds,
    createdAt: ex.createdAt || nowISO, createdBy: ex.createdBy || uid, updatedAt: nowISO, lastActorUid: uid,
  };
}

/** The fields to write after a check that found no price. */
export function failedCheckPatch(watch, nowISO, uid, error) {
  const failures = (Number(watch && watch.failures) || 0) + 1;
  return {
    failures, lastError: str(error).slice(0, 300) || 'no price found', lastCheckedAt: nowISO,
    nextCheckAt: nextCheckAfter(Date.parse(nowISO), false, failures),
    status: failures >= MAX_FAILURES ? 'error' : 'active',
    claimedAt: null, claimedBy: null, updatedAt: nowISO, lastActorUid: uid,
  };
}
