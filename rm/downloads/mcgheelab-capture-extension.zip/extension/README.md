# McGhee Lab Capture (Chrome extension)

A Chrome MV3 extension that one-click-captures papers from publisher
pages and Chrome PDF tabs into the lab's shared Firebase library. Same
project (`mcgheelab-f56cc`), same Firebase Storage path convention
(`papers/{paperId}/{hash}.pdf`), same items.json shape — captures land
in a Firestore queue and merge into the dashboard's `data/items.json`
the next time it loads.

## "+ Item": a purchase request from a vendor page (0.2.0)

Open a product page (Fisher, Sigma, VWR, Amazon, McMaster, Cole-Parmer,
Digi-Key, Grainger, BuyWays, or any shop with structured product data) and
the toolbar icon shows a green **+**. The popup's **Items to buy on this
tab** lists what it found — name, vendor, catalogue number, price — read
from the page's JSON-LD / microdata / Open Graph tags or the vendor's own
layout (`scrape-items.js`). Select text on the page and press **re-scan**
to use that as the item; **add by hand** for anything it missed.

**+ Add** opens a small form (every field editable, plus quantity and a
note). **Add to request** writes the item to *your own* queue in Firestore
(`userData/{uid}/procurementCaptures/{id}` — owner-only, no allowlist) and
opens the lab site's Procurement page with the request prefilled. There you
pick the project, one-time or recurring, and why, and submit. Captures you
did not finish wait under **Captured in your browser** on that page.

Nothing is "in the database" at capture time: the request is an ordinary
purchase ticket, and the item appears in the **Reorder existing** catalogue
only once the PI approves it (and in Inventory only when it is put away).
Sign in with the same Google account you use on the lab site, or the write
is refused.

Every capture — a paper or an item — ends with an **open ↗** link in the
popup that jumps to it on the lab site.

**Price watch (0.3.0).** A price always comes with the page it came from:
the capture records an observation on `priceWatch/{id}` (one doc per product
URL, the same id the lab site computes) and saves the page as printed text
under `priceWatch/{id}/snapshots`. Every six hours an alarm asks for the
watches whose `nextCheckAt` has passed and, for up to three of them, opens
the product page in a **background tab** for a few seconds, reads the price
with the same scraper, appends it to the history and schedules the next
check 90 days out (a page that gives no price is retried in a week, and
marked after four misses). A two-hour lease keeps several lab browsers from
checking the same page. **Check now** in the popup runs it by hand. The lab
site shows the latest list price and the history on the request's card and
in the Reorder existing list.

**Hard pages.** When a tab predates the installed version the popup injects
the scraper itself; when a page has no product markup (VWR, some Sigma
pages) the scraper reads the rendered text the way a person reads a
print-out — every priced line with the catalogue number and pack size
above it.

Fixtures for the scraper: open `test/items-selftest.html` from disk; the
pure price-watch logic: `node test/price-watch-core.test.mjs`.

## Papers behind a wall: the journal's own PDF button (0.4.0)

Many journals (MDPI, Wiley, Elsevier, T&F…) sit behind a bot wall that
answers the extension's background worker with **403 Access Denied** even
though the page, and its **Download PDF** button, open fine in your tab.
The worker's request simply does not look like your click: no Referer, no
page origin (`Sec-Fetch-Site: none`). Capture now climbs a ladder
(`capture.js` `obtainPdf`, routes from `pdf-links.js` / `pdf-fetch.js`):

1. **Direct** — the worker fetches `citation_pdf_url`, then up to two more
   PDF routes found on the page (`<link type=application/pdf>`, an embedded
   viewer, anchors whose href or text says PDF / download; supplements,
   permissions and citation exports are sunk).
2. **As the page** — the same routes fetched from *inside your tab*: same
   origin, same cookies, the page as Referer — exactly what the button
   sends. The bytes are checked for `%PDF-` (walls answer 200 with HTML) and
   handed back base64.
3. **Chrome download** — the best route goes through Chrome's own download
   pipeline (`chrome.downloads`), so the file lands in **Downloads** just as
   the button would put it there. With **Allow access to file URLs** on for
   the extension (chrome://extensions → McGhee Lab Capture → Details) the
   worker reads the file back and the capture finishes by itself.
4. **Unpaywall** — an open-access copy, as before.

If the file was downloaded but the extension may not read files, the popup
says so and offers the two ways to finish: **Open extension settings** (turn
on *Allow access to file URLs*, press Capture again — from then on it reads
its own downloads) or **Upload file…** and pick the saved PDF. A failed
capture lists every route it tried under **What was tried**. The capture
record's `pdf.pdf_source` names the route: `auto`, `auto-link`,
`page-fetch`, `browser-download`, `unpaywall`, `manual-url`, `manual-file`.

**The PDF viewer tab is the paper (0.4.1).** Many journals only hand the PDF
to a human: click the page's **View PDF** / **Download PDF** button yourself
(the popup shows it as **PDF route … open ↗**), pass any "are you human"
check, and press **Capture** on the PDF tab. Chrome's viewer runs no content
script, so the worker builds the record itself: the tab's URL is the PDF,
and the article page you came from (same tab, or the tab that opened this
one) lends its DOI and title — matched by the DOI in the URL, the Elsevier
`pii=` id, or the PDF sitting under the article's path. A PDF opened on its
own has its DOI read out of the file's metadata (XMP / Info dictionary) and
confirmed with CrossRef. A pre-signed link (ScienceDirect's lasts five
minutes) is fetched directly; a refused one goes through Chrome's download,
which is the viewer's own download button. The record keeps the article
page (or `https://doi.org/<doi>`) as its source, never the signed key.

**A DOI anywhere is the link (0.4.1).** Pages without `citation_*` tags —
repositories, lab sites, older publisher pages — are detected from the first
`doi.org` link inside the article (then anywhere) or a "DOI: 10.…" line; the
popup's DOI is always a clickable doi.org link, labelled when it was read
from the PDF or found on the page.

**Paper pages are never shops (0.4.1).** A page with scholarly meta tags or
a DOI / arXiv / PubMed URL lists nothing under **Items to buy** ("Purchase
PDF $35.95" is not a price), and no page's bare title is offered as an item
any more — **add by hand** on a shop page starts from the title instead.

Tests: `node test/capture-ladder.test.mjs` (the ladder with stub routes),
`test/pdf-links-selftest.html` from disk (the ranker and the in-page
fetch), and `node test/extension-e2e.mjs`, which loads the unpacked
extension into a real Chromium against a local journal page that 403s
everything but a same-origin fetch — the worker is walled, the page route
gets the bytes, the download route lands the file and reads it back; then
the same tab navigates to a pre-signed PDF and inherits the article's DOI
and title, a PDF opened cold reads its DOI from its bytes, and a page with
only a doi.org link is detected. `test/items-selftest.html` covers the
paper-page rule.

## Two paths through this doc

- **Lab member** (you've been told the PI added your email): jump to
  [§Lab member install](#lab-member-install). One-zip install, one
  sign-in, done.
- **Lab PI / admin** (first-time setup, or onboarding new members):
  read top-to-bottom. §1–§4 are the original one-time keypair + OAuth
  setup. The new §0 below explains how to add lab members.

---

## 0. Adding lab members (admin only)

Access to the extension is gated on an email allowlist stored at
`labConfig/extensionMembers` in Firestore. Admins always have access
regardless. To grant a lab member access:

1. Open the dashboard → **Library** page.
2. Expand **📥 Install the McGhee Lab Capture Chrome extension**.
3. Scroll to **Manage extension members (admin)**. (This block only
   appears if you're an admin.)
4. Type the lab member's `@arizona.edu` email → **+ Add**.
5. Tell the lab member to install the extension via §Lab member
   install below.

Removing a member: same UI, click the red **Remove** next to their email.
Effect is immediate after Firestore propagation (~10 s).

The Firestore rules helper [`isExtensionMember()`](../McGheeLabWebsite/firestore.rules)
checks this list on every read/write to `pending_captures` and
`paper_index`. Non-members get `permission-denied` errors that the
popup surfaces as "ask the PI to add your email."

---

## Lab member install

Every lab member can use it (anyone with a lab role on the site — not a guest).
Outside collaborators need the PI to add their email in the Library install card.
The download is the static file `mcgheelab.com/rm/downloads/mcgheelab-capture-extension.zip`,
rebuilt from this folder by `McGheeLabWebsite/scripts/build_extension_zip.py` (V3.858).

1. Open the dashboard → **Library** page.
2. Expand **📥 Install the McGhee Lab Capture Chrome extension** →
   click **↓ Download extension (.zip)**.
3. Unzip wherever you keep dev tools (Downloads is fine — the unzipped
   folder needs to stay around as long as you want the extension
   installed).
4. Open `chrome://extensions/`, flip **Developer mode** ON (top-right).
5. Click **Load unpacked** → select the unzipped `extension/` folder.
6. Pin the **M** icon in the Chrome toolbar (puzzle-piece menu → pin).
7. Click the icon → **Sign in** with your `@arizona.edu` Google account.

**Updating (0.3.1):** when a new zip is announced, unzip it over the same
folder, then open `chrome://extensions/` and press **↻ Reload** on the
McGhee Lab Capture card. Chrome reads the popup from disk every time but
keeps running the OLD background worker and manifest until you reload — the
popup notices the mismatch and shows a yellow **Reload needed** bar with a
**Reload now** button that does the same thing.

That's it. Browse normally; the icon shows `?` on detected papers and
flips to `✓` for papers already in the library. Click → **Capture**
to add a paper.

**If sign-in works but Capture says "Permission denied — ask the PI to
add your email"**, the PI hasn't added you to the allowlist yet (or
hasn't deployed the rule changes). Ping them; the message in the
popup tells them exactly where in the dashboard to do it.

---

## Admin setup (PI only)

This document is the install + configure guide for the PI's
**first-time** setup of the project. **Read it top-to-bottom once.**
The only steps that need a brain are §2 and §3 (key generation and the
Google Cloud OAuth client). Everything after is one-click. After §1–§4
are done, you never re-do them — onboarding new members is handled by
§0 above.

---

## Phase 6 sub-phase status — **all phases implemented**

All sub-phases are wired. Verify each one as you go through them; any
failure mode points to a specific phase.

- **6a — auth + sniffing.** Sign in with Google. Popup shows DOI /
  arXiv / PMID / PDF URL detected on the active tab. Toolbar badge
  shows `?` on detected pages.
- **6b — capture pipeline.** Capture button → fetch PDF → hash →
  CrossRef (DOI papers only) → upload to `papers/{paperId}/{hash}.pdf`
  → Firestore `pending_captures/{paperId}`. Badge flips to `✓` after
  capture.
- **6c — dashboard sync.** Open the dashboard's
  [Library page](../pages/library.html) while signed in →
  [`js/library-sync.js`](../js/library-sync.js) reads every
  `pending_captures` doc, fills in arXiv / PubMed metadata via the
  server's `/api/library/lookup` proxy when sparse, dedupes by hash /
  id / DOI / arXiv / PMID, materializes a paper item, populates
  `paper_index/{kind}_{value}` for 6d, deletes the queue doc, and
  saves `data/items.json` once for the whole batch. A toast confirms
  how many were merged.
- **6d — paper_index lookup + badge.** When a paper is detected on a
  publisher tab, the extension queries `paper_index/doi_<doi>`,
  `paper_index/arxiv_<id>`, `paper_index/pmid_<id>` (in priority order)
  with a 5-min in-memory cache. On hit, badge flips `?` → `✓` and the
  popup shows "Already in library: {paper_id}" with a "Re-capture"
  button instead of "Capture".
- **6e — search popup.** Find-and-add a paper without visiting its
  page. Type a DOI / arXiv / PMID / free text into the popup search
  box; CrossRef bibliographic search runs for free text, identifier
  lookups resolve to a single result. Each result has a `+ Add` button
  that writes a metadata-only `pending_captures` doc with `pdf: null`.
  6c materializes those as paper items with no PDF (just metadata +
  DOI link); the user can drop a PDF later via the dashboard's manual
  upload zone.
- **6f — Unpaywall fallback + manual capture.** When the publisher's
  PDF URL serves HTML or 403s, the orchestrator automatically queries
  Unpaywall (using the signed-in email) and retries the fetch from
  `best_oa_location.url_for_pdf`. The popup also exposes a "Manual
  options ▾" expander with a "Paste PDF URL" override and a "Upload
  file" file picker for cases where neither auto-fetch nor Unpaywall
  finds a copy. Manual file uploads ride through the same hash / dedup
  / Storage / Firestore pipeline as the auto path.

If you hit any phase-specific issue, the matching troubleshooting
sections below cover the common failure modes. When everything passes,
phase 6 is complete; the next item on the paper-library plan is
phase 7 (claims, evidence, BibTeX) which lives in the dashboard, not
the extension.

---

## What you'll do in this guide

1. **Load the extension** in Chrome (1 minute).
2. **Pin the extension ID** so it doesn't change across machines (3 minutes).
3. **Create a Google OAuth client** in Google Cloud Console for the lab's
   Firebase project (5 minutes).
4. **Wire the OAuth client into `manifest.json`** (1 minute).
5. **Sign in and verify detection** (1 minute).

If you've never set up an OAuth client in Google Cloud, this is your
first time — that's the chunk that takes ~5 minutes.

You'll need:
- A Mac terminal with `openssl` (built in).
- A Google account that has admin access to the `mcgheelab-f56cc`
  Firebase / Google Cloud project. (If you're the PI: that's you.)
- Chrome (any version ≥ 115).

---

## 1. Load the unpacked extension (first pass)

We need the extension loaded once so Chrome generates a default ID we
can replace with a stable one in §2.

1. Open Chrome and go to `chrome://extensions/`.
2. Top-right: flip **Developer mode** ON.
3. Click **Load unpacked**.
4. Select `/Users/alexmcghee/Documents/GitHub/ResearchManagement/extension`.
5. The extension card appears. **Don't click anything yet** — sign-in
   will fail until §3 and §4 are done. Just confirm the card is there.

> If Chrome rejects the manifest with an error, paste the error to me and
> I'll fix it. Common issue: the placeholder `key` field upset Chrome
> on a fresh install — that's normal until §2.

---

## 2. Pin the extension ID with a stable key

Chrome assigns an extension ID based on either (a) the manifest's `key`
field, or (b) the absolute filesystem path of the unpacked folder. We
want option (a) so the same ID survives moves and works across machines
(the lab Mac, your laptop, etc.).

### 2a. Generate the keypair

> [!IMPORTANT]
> **Do NOT generate the key inside `extension/`.** Recent Chrome versions
> refuse to load an unpacked extension that contains a `.pem` file
> anywhere in the loaded directory. Generate it at the repo root (or
> any directory outside `extension/`).

In the terminal:

```bash
cd /Users/alexmcghee/Documents/GitHub/ResearchManagement
openssl genrsa 2048 | openssl pkcs8 -topk8 -nocrypt -out key.pem
```

This creates `key.pem` in the repo root (NOT inside `extension/`).
**Keep it safe — back it up to your password manager or a private gist.
Anyone with this file can publish updates as you.** It's already in the
repo's `.gitignore` (covered by `*.pem`), so it won't accidentally land
in git.

The private key is only used for two things: (1) generating the public
key in §2b for the manifest's `key` field, and (2) signing updates if
you ever publish to the Chrome Web Store. Daily extension functionality
relies on the `key` field in `manifest.json`, not on the file's
location.

### 2b. Extract the public key in Chrome's expected format

Same terminal:

```bash
openssl rsa -in key.pem -pubout -outform DER | base64 -i -
```

This prints **one long base64 string** (no line breaks, no header / footer).
Copy the entire string to your clipboard.

### 2c. Add the key to `manifest.json`

Open `extension/manifest.json`. Find the closing `}` of the `oauth2`
block:

```json
  "oauth2": {
    "client_id": "REPLACE_WITH_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "openid",
      "email",
      "profile"
    ]
  }
}
```

Add a comma after the closing `}` of `oauth2` and a new `"key"` line on
the next line, like this:

```json
  "oauth2": {
    "client_id": "REPLACE_WITH_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "openid",
      "email",
      "profile"
    ]
  },
  "key": "PASTE_YOUR_BASE64_PUBLIC_KEY_HERE"
}
```

Replace `PASTE_YOUR_BASE64_PUBLIC_KEY_HERE` with the long base64 string
from §2b (one continuous line, no spaces or newlines). Keep the
surrounding quotes. Save.

### 2d. Reload the extension and copy the new ID

1. Back in `chrome://extensions/`, click the **reload** icon (↻) on the
   extension card.
2. The card now shows an **ID** field — a 32-character lowercase string
   like `kjabcdefghijklmnopqrstuvwxyz1234`. This ID is now stable and
   tied to your `key.pem`.
3. Copy the ID. You'll paste it into Google Cloud in §3.

---

## 3. Create the Google OAuth client

The extension signs in via Google → Firebase. Google needs to know that
this specific extension is allowed to ask for sign-in. We do that with
an OAuth Client ID, scoped to your extension's ID.

### 3a. Open Google Cloud Console for the right project

1. Go to <https://console.cloud.google.com/>.
2. Top bar, project picker → search for **`mcgheelab-f56cc`** → select it.
   - If you don't see it, you may not be a member of that Google Cloud
     project. Ask the PI to add you as Owner / Editor.
3. Left nav → **APIs & Services** → **Credentials**.
   - Direct URL: <https://console.cloud.google.com/apis/credentials?project=mcgheelab-f56cc>

### 3b. Configure the OAuth consent screen

> [!TIP]
> **Already configured OAuth for this project?** ✅ Skip the wizard.
> Jump to **§3b-fast** below (just verify Testing mode and test users),
> then go to §3c.
>
> **First time setting up OAuth on `mcgheelab-f56cc`?** Do **§3b-full**.

> Google renamed this in 2024–2025. The old "OAuth consent screen" page
> is now **Google Auth Platform**, and the wizard is split across an
> **Overview**, **Audience**, **Branding**, and **Data Access** tab.
> Same end goal, different click path.

#### 3b-fast — OAuth already configured (~30 seconds)

You'll know you're in this branch if the Google Auth Platform → Overview
page does **not** show a "Get started" button. Just verify two things:

1. Left nav → **Audience**. Publishing status should read **Testing**.
   If it says `In production`, click **Back to testing**.
2. Same page → scroll to **Test users**. Your `@arizona.edu` account
   should be listed; if not, **+ Add users** → add it → Save. Add any
   other lab members who need to sign in here too.

Done — go to §3c.

#### 3b-full — first-time setup (~3 minutes)

1. Left nav → **APIs & Services** → **OAuth consent screen**. You'll
   land on **Google Auth Platform → Overview**.
2. Click **Get started** (big button mid-page). The wizard opens.
3. **App information** step:
   - App name: `McGhee Lab Capture`
   - User support email: yours
   - **Next**
4. **Audience** step: pick **External** → **Next**.
   (Internal only works if your Arizona Workspace admin has authorized
   this project, which they haven't for a personal project. External +
   Testing is correct.)
5. **Contact information** step: developer contact email = yours → **Next**.
6. **Finish** step: agree to the user data policy → **Continue** → **Create**.
   The project is now in **Testing** mode, which is what you want.
7. Add test users: left nav → **Audience** → scroll to **Test users**
   → **+ Add users** → add every `@arizona.edu` Google account that
   should be allowed to sign in (you, each lab member). Save.
   - You can add up to 100 test users without verification.
8. Scopes: nothing to do — the manifest only requests `email`, `profile`,
   `openid`, which are non-sensitive defaults.

### 3c. Create the OAuth client

1. Left nav → **Clients** (under **Google Auth Platform**). The old
   path **APIs & Services → Credentials** also still works.
2. **+ Create client**.
3. **Application type:** `Chrome Extension`.
4. **Name:** `McGhee Lab Capture (Chrome Extension)`.
5. **Item ID:** paste the 32-char extension ID from §2d.
6. Click **Create**.
7. A modal pops up with **Your Client ID** — looks like
   `665438582202-xxxxxxxxxxxxxxxxxxxxxx.apps.googleusercontent.com`.
   Copy it.

### 3d. Paste the client_id into `manifest.json`

In `extension/manifest.json`:

```json
"oauth2": {
  "client_id": "REPLACE_WITH_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com",
```

Replace `REPLACE_WITH_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com`
with the full client_id you just copied. Save.

### 3e. Reload the extension

`chrome://extensions/` → click the reload icon (↻) on the card.

---

## 4. Sign in and verify detection

### 4a. Sign in

1. Click the extension icon in Chrome's toolbar (the indigo "M").
   - If the icon isn't pinned: click the puzzle-piece icon next to the
     URL bar, then click the pin next to "McGhee Lab Capture".
2. The popup opens. Click **Sign in**.
3. A Google account picker appears. Pick your `@arizona.edu` account.
4. Google asks for permission to share your email/profile. Click
   **Continue**.
5. The popup flips to **Signed in**, dot turns green, your name shows.

If you get stuck here, see Troubleshooting below.

### 4b. Verify paper detection

Open each of these in turn and click the extension icon:

| URL | Popup should show |
| --- | --- |
| `https://arxiv.org/abs/1706.03762` | `arXiv: 1706.03762`, a `pdf_url`, source `arxiv` |
| `https://pubmed.ncbi.nlm.nih.gov/25432010/` | `PMID: 25432010`, source `pubmed` |
| `https://doi.org/10.1016/j.actbio.2023.09.042` | DOI `10.1016/j.actbio.2023.09.042`, often `pdf_url` from the publisher meta tag |
| `https://www.google.com/` | "No paper identifiers detected on this page." |

**Toolbar badge:** On detected pages, the extension icon shows a tiny
`?` overlay (gray-blue background). On non-paper pages, no badge.
(In phase 6d this `?` becomes ✓ / + based on whether the paper is
already in the lab library.)

---

## Troubleshooting

### `OAuth2 not granted or revoked` when signing in

- The client_id in `manifest.json` doesn't match the one in Google Cloud.
  Re-copy from §3c, save, reload extension.
- Your account isn't on the OAuth consent screen's test-user list (§3b
  step 5). Add it, save, retry.

### `Invalid extension id` when creating the OAuth client

- The 32-char ID you pasted has a typo. Re-copy from `chrome://extensions/`.

### Sign-in popup opens then immediately closes with no error

- The OAuth consent screen is in "Production" but your account isn't
  associated. **Google Auth Platform → Audience** → if "Publishing
  status" reads `In production`, click **Back to testing** and add your
  account under **Test users**. For a lab tool, **stay on Testing**.

### "Could not load extension" with a manifest error

- You probably saved the manifest with `REPLACE_WITH_…` still in place.
  The placeholders aren't valid OAuth values. Complete §2 and §3 first.

### Sign-in works but `firebase signInWithIdp failed (400)`

- The Firebase project's Auth tab needs Google added as a sign-in
  provider. Go to
  <https://console.firebase.google.com/project/mcgheelab-f56cc/authentication/providers>
  → Add provider → Google → Enable → Save.

### "Can't read this tab" on a normal vendor page, or a yellow "Reload needed" bar (0.3.1)

- Chrome is still running the background worker from an older load of the
  folder: the popup files are read from disk on every open, but the
  manifest, the service worker and the content scripts only change on a
  reload. Press **Reload now** in the bar (or ↻ on `chrome://extensions/`),
  then open the popup again. This is what "Can't read this tab" with no
  reason in parentheses meant before 0.3.1.
- With a reason in parentheses, the reason is real: Chrome pages, the Web
  Store, the PDF viewer and `file://` tabs (without "Allow access to file
  URLs") are off limits to extensions; "scrape failed: …" is a bug on that
  page's markup — send the URL to Alex and use **add by hand** meanwhile.

### Capture says "Access Denied" / 403 on a journal that opens fine in the tab (0.4.0)

- That is the bot wall refusing the background worker; the ladder above
  fetches as the page and, failing that, through Chrome's download. If the
  popup says the file was saved but cannot be read, turn on **Allow access
  to file URLs** for the extension (the popup's **Open extension settings**
  button lands on the right page) and press Capture again, or use **Upload
  file…**. **What was tried** under the message lists each route's answer —
  send that to Alex when a journal still fails.

### "I captured it but it is not in the library" (0.4.2)

- Look at the toolbar icon on that tab: a red **!** means the capture failed
  (hover it for the reason). Reopen the popup on the tab: **Last capture on
  this tab** shows the result, or the error with **What was tried**. The
  popup closes when focus moves (a download bubble, another click) while
  the worker is still fetching, so the message used to be lost — it is kept
  now. Every capture also writes a line to your own
  `userData/<uid>/captureLog` in Firestore, which the PI can read.
- A capture that worked ends with **Open it in the library ↗**; the Library
  page merges pending captures as it opens ("Merged N extension capture(s)").

### Detection shows nothing on a known paper page

- Some publishers strip the `citation_*` meta tags. Check the page
  source for `<meta name="citation_doi"…>` etc. If absent, the only
  fallback is to try to find the DOI in the URL or page text — usually
  fine, but corner cases exist.

### Where do I see logs?

- Open `chrome://extensions/` → click **service worker** under the
  extension card. That's the background.js console.
- For popup logs: open the popup, right-click inside it → **Inspect** →
  Console.
- For content-script logs: open DevTools on the publisher page → Console.

---

## Phase 6d — verify the paper_index badge

After 6c has merged at least one capture:

1. Re-open the original publisher tab (or any other tab on the same
   paper — DOI / arXiv ID will match).
2. Wait ~1 second. Toolbar badge should flip from `?` to a green `✓`.
3. Open the popup. The "Add to library" section should show a green
   "✓ Already in library: {paper_id}" banner, and the button should
   read **Re-capture** in a ghost style.
4. Open the worker DevTools (`chrome://extensions/` → service worker)
   and watch for a `[paper-index]` warning if the lookup fails — the
   badge silently falls back to `?` on permission errors.

Cache TTL is 5 minutes. If you've just synced and the badge still says
`?`, toggle the extension off/on (or wait 5 min) to force a re-query.

### 6d troubleshooting

- **Badge stays `?` after sync** — `paper_index` rule denies reads.
  Check [Firestore rules](https://console.firebase.google.com/project/mcgheelab-f56cc/firestore/rules)
  has `match /paper_index/{hash}` block with `allow read: if request.auth != null`.
- **Badge says `?` for paper that's in items.json** — the dashboard sync
  didn't write paper_index entries for it (probably an old import from
  the manual upload path before extension was installed). Bump the
  paper by re-saving items.json or running the manual upload through
  again to regenerate the index.

## Phase 6e — verify search & metadata-only add

1. Open the popup → click **Find paper (no PDF needed) → expand**.
2. Type a free-text query (e.g. "attention is all you need") → Search.
   Up to 8 CrossRef results appear with title / authors / journal-year.
3. Click **+ Add** on a result. Button changes to "Added" (or "Already
   queued" if a `pending_captures` doc already exists at that id).
4. Open the dashboard Library page → toast: "Merged N extension
   capture(s)". The new entry shows up in the table with no PDF.

You can also paste a DOI / arXiv ID / PMID — it routes to the
appropriate lookup. arXiv and PMID are saved as stubs; the dashboard
sync fills in title/authors/year/journal via `/api/library/lookup`.

## Phase 6f — verify Unpaywall + manual capture

**Unpaywall (auto):** open a DOI page where the publisher PDF is
paywalled but Unpaywall has a green-OA copy (e.g. an Elsevier paper
with an arXiv preprint). Click Capture — status should show
"PDF unavailable — checking Unpaywall…" then "Downloading PDF
(Unpaywall)…" then "Captured." The capture's `pdf.pdf_source` field is
`unpaywall` for audit.

**Manual URL override:** click **Manual options ▾** under the Capture
button. Paste a direct PDF URL → "Use URL". The orchestrator skips the
page's own links and Unpaywall and pulls from your URL (direct, then as
the page, then through Chrome's download — 0.4.0). Useful for
institutional proxy URLs that the auto path can't infer.

**Manual file upload:** same expander → **Upload file…** → choose a
local PDF. The popup ships the bytes to the worker as ArrayBuffer; the
worker runs the same hash → CrossRef → upload → queue pipeline.
`pdf.pdf_source` records `manual-file`.

### 6f troubleshooting

- **"Network error fetching PDF" then nothing** — Unpaywall didn't
  return a usable URL, and the original error wasn't recoverable. Try
  the manual URL/file path.
- **"Selected file is too small to be a PDF"** — file is <1KB. Pick
  the actual paper, not a stub.
- **`Storage upload failed (403)`** on a manual file — the Storage
  rule for `papers/{paperId}/{file=**}` requires
  `request.resource.contentType == 'application/pdf'`. The popup sets
  it explicitly on the new Blob, but if you see this, check that the
  rule allows `application/pdf` (it does in the McGheeLabWebsite repo).

## Phase 6c — verify the dashboard sync

After completing 6b (a capture is sitting in Firestore), open the
dashboard library page to merge it:

1. Run the dashboard server: `python3 server.py` from the repo root.
2. Visit <http://localhost:8000/pages/library.html>.
3. Sign in via the avatar in the top nav (same Google account).
4. Within ~1 second a toast should fire:
   `Merged N extension capture(s): <title>` (or
   `Cleared N already-merged capture(s)` if the paper was previously
   synced and the queue doc was orphaned).
5. The paper appears in the table; clicking **Read** opens the PDF
   from Firebase Storage.
6. Verify in Firebase: `pending_captures/<paper_id>` is gone,
   `paper_index/<short_hash>` now exists with `{paper_id, full_hash, ...}`.

### 6c troubleshooting

- **"Failed to fetch /api/library/lookup"** — server.py isn't running,
  or the page is being served from `file://` instead of
  `http://localhost:8000`. Sync still partially works (extension's
  CrossRef metadata for DOI papers is enough), but arXiv/PubMed
  enrichment is skipped and you'll see the raw extension metadata.
- **Toast says "Sync hit N errors"** — open the browser console; each
  error line names the `paper_id` and the underlying message.
- **Captures don't merge** — sign-in state. Sync runs on
  `firebridge.onAuth`; if the avatar shows "Sign in", click it first.
- **Same paper merged twice** — shouldn't happen because dedupe checks
  both `full_hash` and `id`. If it does, paste the duplicated `paper_id`
  values to Claude — there's a bug in the materializer.

## Phase 6b — verify the capture pipeline

After completing §1–§4 you can test 6b end-to-end:

1. Open <https://arxiv.org/abs/1706.03762> (Attention Is All You Need —
   small public PDF, won't get you flagged).
2. Click the toolbar **M** → popup → **Capture**.
3. Status should walk through "Downloading PDF… → Hashing… → Looking up
   metadata… → Uploading… → Writing capture record…" and finally
   **Captured.** with the paper id and hash.
4. The toolbar badge flips from `?` to a green `✓`.
5. Verify in Firebase:
   - **Firestore** → `pending_captures` collection should have a doc
     keyed by the paper id.
   - **Storage** → `papers/{paperId}/{hash}.pdf` should be there.

### Firestore rules for 6b

The capture flow writes to `pending_captures/{paperId}` and reads
`paper_index/{hash}` (6d will populate it). Minimal rules that work:

```
match /pending_captures/{paperId} {
  allow read, write: if request.auth != null;
}
match /paper_index/{hash} {
  allow read: if request.auth != null;
}
```

If you see `Firestore PATCH pending_captures/… failed (403)`, the
rules deny the write — open the
[Firestore rules editor](https://console.firebase.google.com/project/mcgheelab-f56cc/firestore/rules)
and add the block above (or merge into your existing rules).

### Storage rules for 6b

PDFs land at `papers/{paperId}/{hash}.pdf`. Match:

```
match /papers/{paperId}/{file=**} {
  allow read, write: if request.auth != null;
}
```

### 6b troubleshooting

- **`URL returned text/html — likely paywalled`** — the publisher served
  HTML instead of a PDF. Try the publisher's "Download PDF" link, then
  capture from the resulting tab. 6f will add Unpaywall fallback.
- **`PDF response was too small`** — server returned a stub or error
  page with PDF Content-Type. Same workaround as paywalled.
- **`Storage upload failed (403)`** — Storage rules don't allow
  authenticated writes to `papers/`. See above.
- **`Firestore … failed (403)`** — same, but for the `pending_captures`
  collection.
- **Badge doesn't flip to ✓** — the worker's chrome.action calls run
  after the message response. If the popup closes mid-flow, the badge
  won't update; reopen the popup, the result is in Firestore regardless.

## Daily use (after setup)

1. Sign in once via the popup. The token persists across browser
   restarts; you'll only sign in again if the refresh token expires
   (~30 days idle) or you sign out manually.
2. Browse normally. The toolbar icon shows `?` whenever the current
   tab is a paper.
3. (6b onward) Click the icon → **Capture** → the PDF uploads to
   Firebase Storage and a `pending_captures` doc lands in Firestore.
4. (6c onward) Open the RM dashboard library page. Pending captures
   merge into `data/items.json` automatically; toast confirms count.

---

## File layout

```
extension/
├── manifest.json        — MV3 manifest with oauth2 + content_scripts + action
├── background.js        — service worker (auth + detection cache + capture/search/library-lookup handlers)
├── content.js           — meta-tag + URL sniffer for DOI / arXiv / PMID / PDF
├── capture.js           — 6b/6f orchestrator: fetch PDF → hash → CrossRef → upload → queue (+ Unpaywall fallback)
├── search.js            — 6e CrossRef bibliographic search + identifier lookup + metadata-only add
├── popup.html / .js     — toolbar popup (auth + detection + capture + search + manual)
├── firebase-rest.js     — Firebase Auth / Firestore / Storage REST wrappers
├── icons/               — 16 / 32 / 48 / 128 px PNG icons (M on indigo)
└── README.md            — you are here

../key.pem               — RSA private key for the stable extension ID
                           (lives at the repo root — Chrome refuses to load
                           unpacked extensions when a .pem file is inside
                           the loaded directory; gitignored via *.pem)

dashboard side:
├── ../js/library-sync.js     — 6c: pending_captures → items.json + paper_index
└── ../js/library.js          — wires sync into the Library page init flow
```

## Why REST instead of the Firebase JS SDK?

MV3 service workers can't dynamically `import` scripts at runtime, and
bundling the Firebase JS SDK adds a build step we wanted to avoid. The
Firebase Auth / Firestore / Cloud Storage REST APIs are well-documented
and stable; the entire client we need fits in ~250 lines of vanilla JS.
See `firebase-rest.js`.
