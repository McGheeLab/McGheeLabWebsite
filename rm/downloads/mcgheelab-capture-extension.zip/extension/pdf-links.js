/* pdf-links.js — V3.822 "use the journal's own Download PDF button".
 *
 * Classic content script (no imports), also injected on demand by
 * background.js, so it is idempotent. Two helpers on window:
 *
 *   __mcgheePdfLinks()    → { url, candidates: [{ url, score, how, text }] }
 *       the PDF routes this page offers, best first: citation_pdf_url,
 *       <link type=application/pdf>, an embedded viewer, and anchors whose
 *       href or text says PDF / download (supplements, permissions, citation
 *       exports and the like are sunk to the bottom).
 *
 *   __mcgheeFetchPdf(url) → Promise<{ ok, base64, size, contentType, finalUrl }
 *                                   | { ok:false, error, status, contentType }>
 *       fetches AS THE PAGE — same origin, same cookies, same Referer — which
 *       is what the person's click on the button sends. A bot wall that 403s
 *       the extension's service worker lets this through. The bytes are
 *       checked for the %PDF- magic (walls answer 200 with HTML) and returned
 *       base64 so they survive chrome.runtime messaging.
 */
(function () {
  'use strict';

  var MAX = 6;
  var SINK = /supplement|suppl?[-_.]|\bsi\b|appendix|cover|permission|citation|\.ris\b|bibtex|endnote|licen[cs]e|terms|privacy|figure|\btable\b|erratum|correction|sample|preview|\btoc\b|checklist|graphical/i;

  function str(v) { return v == null ? '' : String(v).replace(/\s+/g, ' ').trim(); }
  function abs(u) { try { return new URL(u, location.href).href; } catch (e) { return ''; } }
  function http(u) { u = abs(u); return /^https?:\/\//i.test(u) ? u : ''; }
  function sameOrigin(u) { try { return new URL(u).origin === location.origin; } catch (e) { return false; } }

  function add(out, url, score, how, text) {
    url = http(url); if (!url) return;
    var path = url.replace(/^https?:\/\/[^/]+/, '');
    if (how === 'anchor' && (SINK.test(path) || SINK.test(text))) score -= 60;
    if (!sameOrigin(url)) score -= 10;
    out.push({ url: url, score: score, how: how, text: str(text).slice(0, 80) });
  }

  function collect() {
    var out = [], i;
    var m = document.querySelector('meta[name="citation_pdf_url" i]');
    if (m && m.content) add(out, m.content, 100, 'citation_pdf_url', '');
    var links = document.querySelectorAll('link[type="application/pdf" i][href]');
    for (i = 0; i < links.length; i++) add(out, links[i].getAttribute('href'), 90, 'link-alternate', links[i].title);
    var emb = document.querySelectorAll('iframe[src], embed[src], object[data]');
    for (i = 0; i < emb.length; i++) {
      var s = emb[i].getAttribute('src') || emb[i].getAttribute('data') || '';
      if (/\.pdf(\?|#|$)/i.test(s)) add(out, s, 80, 'embed', '');
    }
    var as = document.querySelectorAll('a[href]');
    for (i = 0; i < as.length && i < 4000; i++) {
      var a = as[i], href = a.getAttribute('href') || '';
      if (!href || /^(javascript:|mailto:|tel:|#)/i.test(href)) continue;
      var text = [a.textContent, a.getAttribute('aria-label'), a.getAttribute('title'), a.getAttribute('data-title')].map(str).join(' ');
      var score = 0;
      if (/\.pdf(\?|#|$)/i.test(href)) score += 60;
      else if (/\/pdf(\/|\?|#|$)|[?&](format|type|output)=pdf\b|\/download\/|fulltext\.pdf|\bepdf\b|pdfdirect|downloadpdf|getpdf|\/pdfft\b|\/article-pdf\//i.test(href)) score += 50;
      if (a.hasAttribute('download')) score += 15;
      if (/\bdownload\b[^|·]*\bpdf\b|\bpdf\b[^|·]*\bdownload\b/i.test(text)) score += 25;
      else if (/\b(view|open|get|read|show|access)\b[^|·]*\bpdf\b/i.test(text)) score += 20;   // "View PDF" (ScienceDirect), "Get PDF"
      else if (/\bpdf\b/i.test(text)) score += 10;
      else if (/\bdownload\b|\bfull[\s-]?text\b/i.test(text)) score += 5;
      if (score < 20) continue;
      add(out, href, score, 'anchor', text);
    }
    var seen = {}, list = [];
    out.forEach(function (c) {
      var have = seen[c.url];
      if (have) { if (c.score > have.score) { have.score = c.score; have.how = c.how; } if (!have.text && c.text) have.text = c.text; return; }
      seen[c.url] = c; list.push(c);
    });
    list.sort(function (x, y) { return y.score - x.score; });
    return { url: location.href, candidates: list.slice(0, MAX) };
  }

  function toBase64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { rej(r.error || new Error('read failed')); };
      r.readAsDataURL(blob);
    });
  }

  function fetchPdf(url) {
    var out;
    return fetch(url, { credentials: 'include', redirect: 'follow', headers: { 'Accept': 'application/pdf,application/x-pdf;q=0.9,*/*;q=0.5' } })
      .then(function (res) {
        var ct = (res.headers.get('Content-Type') || '').toLowerCase();
        if (!res.ok) return { ok: false, error: 'HTTP ' + res.status + (res.statusText ? ' ' + res.statusText : ''), status: res.status, contentType: ct };
        return res.blob().then(function (blob) {
          return blob.slice(0, 1024).text().then(function (head) {
            if (head.indexOf('%PDF-') < 0) return { ok: false, error: 'not a PDF (' + (ct || 'no content-type') + ', ' + blob.size + ' bytes)', status: res.status, contentType: ct, size: blob.size };
            if (blob.size > 60 * 1024 * 1024) return { ok: false, error: 'PDF larger than 60 MB', size: blob.size };
            return toBase64(blob).then(function (b) { return { ok: true, base64: b, size: blob.size, contentType: ct, finalUrl: res.url || url }; });
          });
        });
      })
      .catch(function (e) { return { ok: false, error: 'network: ' + ((e && e.message) || String(e)) }; });
  }

  window.__mcgheePdfLinks = collect;
  window.__mcgheeFetchPdf = fetchPdf;
})();
