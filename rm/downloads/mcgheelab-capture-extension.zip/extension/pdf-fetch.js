/* pdf-fetch.js — V3.822. The two ways to get a PDF that the service
 * worker's own fetch cannot: as the page (pdf-links.js, injected into the
 * tab, fetches with the page's origin and cookies) and through Chrome's
 * download pipeline (the file lands in Downloads, exactly as the journal's
 * button would put it there, and is read back from disk when the extension
 * has "Allow access to file URLs"; otherwise the person uploads it).
 *
 * Runs in the background service worker. capture.js takes these as
 * `strategies` so its ladder stays DOM-free and node-testable.
 */

const DOWNLOAD_TIMEOUT_MS = 120000;
const POLL_MS = 500;

/** First kilobyte holds "%PDF-" for every real PDF (walls answer 200 + HTML). */
export function looksLikePdf(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const n = Math.min(u8.length, 1024);
  for (let i = 0; i + 4 < n; i++) {
    if (u8[i] === 0x25 && u8[i + 1] === 0x50 && u8[i + 2] === 0x44 && u8[i + 3] === 0x46 && u8[i + 4] === 0x2d) return true;   // %PDF-
  }
  return false;
}

export function base64ToBytes(b64) {
  const bin = atob(b64 || '');
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** "/Users/x/Downloads/a.pdf" → "file:///Users/x/Downloads/a.pdf"; "C:\\x\\a.pdf" → "file:///C:/x/a.pdf". */
export function toFileUrl(path) {
  let p = String(path || '').replace(/\\/g, '/');
  if (/^[a-zA-Z]:\//.test(p)) p = '/' + p;
  return 'file://' + p.split('/').map((seg, i) => (i === 0 || /^[a-zA-Z]:$/.test(seg) ? seg : encodeURIComponent(seg))).join('/');
}
export function basename(path) { return String(path || '').split(/[\\/]/).pop() || ''; }

async function _inject(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['pdf-links.js'] });
}

/** The PDF routes a tab offers, best first (see pdf-links.js). */
export async function pdfLinksOnTab(tabId) {
  await _inject(tabId);
  const res = await chrome.scripting.executeScript({ target: { tabId }, func: () => (window.__mcgheePdfLinks ? window.__mcgheePdfLinks() : null) });
  const out = res && res[0] && res[0].result;
  return (out && Array.isArray(out.candidates)) ? out.candidates : [];
}

/** strategies.page — fetch `url` from inside the tab, as the page would. */
export function pageFetcher(tabId) {
  return async (url) => {
    await _inject(tabId);
    const res = await chrome.scripting.executeScript({ target: { tabId }, func: (u) => (window.__mcgheeFetchPdf ? window.__mcgheeFetchPdf(u) : { ok: false, error: 'no fetch helper on the tab' }), args: [url] });
    const out = res && res[0] && res[0].result;
    if (!out || !out.ok) throw new Error('as the page: ' + ((out && out.error) || 'no result'));
    const bytes = base64ToBytes(out.base64);
    if (!looksLikePdf(bytes)) throw new Error('as the page: the bytes are not a PDF');
    return { blob: new Blob([bytes], { type: 'application/pdf' }), url: out.finalUrl || url };
  };
}

async function _waitForDownload(id, timeoutMs) {
  const t0 = Date.now();
  for (;;) {
    const [item] = await chrome.downloads.search({ id });
    if (!item) throw new Error('download vanished');
    if (item.state !== 'in_progress') return item;
    if (Date.now() - t0 > timeoutMs) { try { await chrome.downloads.cancel(id); } catch (_) {} throw new Error('download timed out'); }
    await new Promise((r) => setTimeout(r, POLL_MS));
  }
}

/** strategies.download — save through Chrome, then read the file back.
 * Resolves { blob, url, filename, path } or { needsFileAccess, filename, path, fileUrl }. */
export function browserDownloader() {
  return async (url) => {
    if (!chrome.downloads) throw new Error('the downloads permission is missing (reload the extension)');
    const id = await chrome.downloads.download({ url, conflictAction: 'uniquify', saveAs: false });
    const item = await _waitForDownload(id, DOWNLOAD_TIMEOUT_MS);
    if (item.state !== 'complete') throw new Error('Chrome could not download it (' + (item.error || item.state) + ')');
    const isPdf = /pdf/i.test(item.mime || '') || /\.pdf$/i.test(item.filename || '');
    if (!isPdf) {
      try { await chrome.downloads.removeFile(id); await chrome.downloads.erase({ id }); } catch (_) {}
      throw new Error('the journal sent ' + (item.mime || 'something that is not a PDF') + ' instead of a PDF');
    }
    const path = item.filename || '';
    const fileUrl = toFileUrl(path);
    try {
      const r = await fetch(fileUrl);
      const buf = await r.arrayBuffer();
      if (looksLikePdf(buf)) return { blob: new Blob([buf], { type: 'application/pdf' }), url, filename: basename(path), path };
      throw new Error('the saved file is not a PDF');
    } catch (e) {
      // No "Allow access to file URLs" (or a transient read error): the file is on disk, the person finishes.
      return { needsFileAccess: true, filename: basename(path), path, fileUrl, error: (e && e.message) || String(e) };
    }
  };
}

/* ── V3.823 — a tab that IS the PDF (Chrome's viewer; no content script runs there) ── */

/** The URL is a PDF route: …/main.pdf?…, /doi/pdf/…, /pdfft?…, /content/pdf/…, or Chrome's viewer. */
export function looksLikePdfUrl(url) {
  const u = String(url || '');
  if (/^chrome-extension:\/\/mhjfbmdgcfjbbpaeojofohoefgiehjai\//i.test(u)) return true;
  if (!/^https?:\/\//i.test(u)) return false;
  const path = u.replace(/^https?:\/\/[^/]+/i, '').split(/[?#]/)[0];
  return /\.pdf$/i.test(path) || /\/(pdf|pdfft|epdf|pdfdirect|article-pdf)(\/|$)/i.test(path) || /\/content\/pdf\//i.test(path);
}

/** Identifiers readable off a PDF URL: a DOI in the path, an arXiv id, an Elsevier PII. */
export function minePdfUrl(url) {
  const u = String(url || ''); let dec = u; try { dec = decodeURIComponent(u); } catch (_) {}
  const out = { doi: '', arxiv_id: '', pii: '' };
  const d = dec.match(/\b10\.\d{4,9}\/[-._;()/:A-Z0-9]+/i);
  if (d) out.doi = d[0].replace(/\.pdf$/i, '').replace(/[.,;:)]+$/, '').toLowerCase();
  const a = dec.match(/arxiv\.org\/(?:abs|pdf)\/([\w.\-]+?)(?:v\d+)?(?:\.pdf)?(?:[?#]|$)/i);
  if (a) out.arxiv_id = a[1];
  const p = dec.match(/\bS\d{15}[\dX]\b/i) || dec.match(/\bS\d{4}-\d{4}\(\d{2}\)\d{5}-[\dX]\b/i);
  if (p) out.pii = p[0].toUpperCase();
  return out;
}

/** Elsevier: S1476558601800518 → 10.1016/S1476-5586(01)80051-8 (a guess — verify against CrossRef). */
export function piiToDoi(pii) {
  const p = String(pii || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const m = p.match(/^S(\d{4})(\d{4})(\d{2})(\d{5})([\dX])$/);
  return m ? `10.1016/S${m[1]}-${m[2]}(${m[3]})${m[4]}-${m[5]}` : '';
}

/** The article page this tab (or its opener) showed is the same work as this PDF URL. */
export function sameWork(prev, url) {
  if (!prev || !url) return false;
  const u = String(url); let dec = u; try { dec = decodeURIComponent(u); } catch (_) {}
  const lc = dec.toLowerCase();
  if (prev.url === u) return true;
  if (prev.doi && lc.includes(String(prev.doi).toLowerCase())) return true;
  if (prev.arxiv_id && lc.includes(String(prev.arxiv_id).toLowerCase())) return true;
  if (prev.pdf_url && (u === prev.pdf_url || dec === prev.pdf_url)) return true;
  if (Array.isArray(prev.pdf_candidates) && prev.pdf_candidates.some((c) => (c && (c.url || c)) === u)) return true;
  const mined = minePdfUrl(u);
  if (mined.pii) { const pu = String(prev.url || '').toUpperCase(); if (pu.includes(mined.pii) || pu.includes(mined.pii.replace(/[-()]/g, ''))) return true; }
  const prevPath = String(prev.url || '').split(/[?#]/)[0].replace(/\/$/, '');
  if (prevPath && /^https?:\/\/[^/]+\/.+/.test(prevPath) && u.startsWith(prevPath + '/')) return true;   // MDPI: /article → /article/pdf
  return false;
}

/** A pre-signed URL without its key: the record keeps where the PDF came from, not a five-minute credential. */
export function publicUrl(url) {
  const u = String(url || '');
  if (!/[?&](X-Amz-[A-Za-z-]+|Signature|Key-Pair-Id|Policy|token|md5)=/i.test(u)) return u;
  return u.split(/[?#]/)[0];
}

/* ── V3.823 — the DOI inside the PDF itself ────────────────────────────
 * Publisher PDFs carry it in plain text: the XMP packet (<prism:doi>,
 * <pdfx:doi>, <dc:identifier>doi:…) or the Info dictionary (/Subject (… doi:…)).
 * Those parts are not compressed, so a regex over the raw bytes finds them;
 * a labelled match wins over a bare "10.xxxx/…" (reference lists). */
const DOI_RE = /\b10\.\d{4,9}\/[-._;()/:A-Z0-9]+/ig;
function _cleanDoi(d) {
  // Cut at a PDF text operator glued to the DOI ("…76)Tj"), at a closing tag,
  // then trailing punctuation. A DOI's own parentheses are followed by digits.
  return String(d || '').replace(/\)(?![0-9-])[^]*$/, '').replace(/<\/.*$/, '').replace(/[.,;:)\]>'"]+$/, '').toLowerCase();
}
export function doiFromPdfBytes(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || 0);
  if (!u8.length) return '';
  let text = ''; try { text = new TextDecoder('latin1').decode(u8); } catch (_) { return ''; }
  const labelled = text.match(/(?:prism:doi|pdfx:doi|dc:identifier|doi\.org\/|\bdoi\s*[:=]\s*|\/doi\s*\()[^0-9]{0,12}(10\.\d{4,9}\/[-._;()/:A-Z0-9]+)/i);
  if (labelled) return _cleanDoi(labelled[1]);
  const bare = text.match(DOI_RE);
  return bare ? _cleanDoi(bare[0]) : '';
}
/** Head + tail of the PDF at `url` (two ranged GETs; a pre-signed URL allows them) → DOI or ''. */
export async function sniffPdfDoi(url, opts = {}) {
  const span = opts.bytes || 262144;
  const grab = async (range) => { const r = await fetch(url, { credentials: 'include', headers: { Range: 'bytes=' + range, Accept: 'application/pdf,*/*;q=0.5' } }); if (!r.ok) throw new Error('HTTP ' + r.status); return new Uint8Array(await r.arrayBuffer()); };
  try {
    const head = await grab('0-' + (span - 1));
    if (!looksLikePdf(head)) return '';
    const fromHead = doiFromPdfBytes(head); if (fromHead) return fromHead;
    if (head.length < span) return '';   // the whole file fit
    const tail = await grab('-' + span);
    return doiFromPdfBytes(tail);
  } catch (_) { return ''; }
}
/** The same over a Blob already in hand (head + tail, 1 MB each). */
export async function doiFromPdfBlob(blob, span = 1048576) {
  if (!blob || !blob.size) return '';
  const head = new Uint8Array(await blob.slice(0, span).arrayBuffer());
  const fromHead = doiFromPdfBytes(head); if (fromHead) return fromHead;
  if (blob.size <= span) return '';
  return doiFromPdfBytes(new Uint8Array(await blob.slice(Math.max(span, blob.size - span)).arrayBuffer()));
}

/** Diagnostic: what each route returns for a tab, nothing uploaded. */
export async function probePdfRoutes(tabId, opts = {}) {
  const out = { candidates: [], direct: null, page: null, download: null };
  try { out.candidates = await pdfLinksOnTab(tabId); } catch (e) { out.candidatesError = e.message; }
  const url = opts.url || (out.candidates[0] && out.candidates[0].url) || '';
  if (!url) return out;
  out.url = url;
  try { const r = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/pdf,*/*;q=0.5' } }); const buf = await r.arrayBuffer(); out.direct = { ok: r.ok && looksLikePdf(buf), status: r.status, size: buf.byteLength }; }
  catch (e) { out.direct = { ok: false, error: e.message }; }
  try { const got = await pageFetcher(tabId)(url); out.page = { ok: true, size: got.blob.size }; }
  catch (e) { out.page = { ok: false, error: e.message }; }
  if (opts.download) {
    try { const got = await browserDownloader()(opts.downloadUrl || url); out.download = got.blob ? { ok: true, size: got.blob.size, filename: got.filename, path: got.path } : { ok: false, needsFileAccess: true, filename: got.filename, path: got.path, error: got.error }; }
    catch (e) { out.download = { ok: false, error: e.message }; }
  }
  return out;
}
