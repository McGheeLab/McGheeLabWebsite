/* firebase-rest.js — minimal Firebase Auth + Firestore + Storage clients via
 * the public REST APIs. The Chrome extension never bundles the Firebase JS
 * SDK (which is heavy and awkward in MV3 service workers). Instead we hold
 * a Firebase ID token in chrome.storage.local and call the REST endpoints
 * directly with `fetch()`.
 *
 * The same FIREBASE_CONFIG values from js/firebase-bridge.js are embedded
 * verbatim so this extension talks to the McGhee Lab project.
 *
 * Public exports (named):
 *   FIREBASE_CONFIG
 *   signInWithGoogle()        — interactive Google OAuth → Firebase ID token
 *   signOut()
 *   getCurrentUser()          — cached profile, or null
 *   getValidIdToken()         — refresh if near expiry; throws if not signed in
 *   firestoreGetDoc(path)
 *   firestoreSetDoc(path, doc) — uses serverTimestamp via REST sentinel
 *   firestoreDeleteDoc(path)
 *   firestoreCollectionAdd(path, doc) — creates with auto-id, returns id
 *   uploadToStorage(storagePath, blob, contentType)
 *   storageDownloadUrl(storagePath)
 *
 * Phase 6a uses only the auth pieces; the rest is wired in 6b.
 */

export const FIREBASE_CONFIG = {
  apiKey:            'AIzaSyAnkKivjCcjAS8_Lp-R2JSIG4wSDSJBFI0',
  authDomain:        'mcgheelab-f56cc.firebaseapp.com',
  projectId:         'mcgheelab-f56cc',
  storageBucket:     'mcgheelab-f56cc.firebasestorage.app',
  messagingSenderId: '665438582202',
  appId:             '1:665438582202:web:57416863d588bcdeff9983',
};

const STORAGE_KEY = 'mcgheelib_auth';
// Refresh the ID token if it has < this many seconds left. Firebase ID
// tokens last 1h; refreshing 5 min early avoids racing the boundary.
const REFRESH_LEEWAY_SECONDS = 300;

/* ---------------- Auth ---------------- */

/**
 * Interactive Google sign-in via chrome.identity.getAuthToken, then exchange
 * the Google access token for a Firebase ID token using the Identity Toolkit
 * REST endpoint accounts:signInWithIdp.
 *
 * Caches {idToken, refreshToken, expiresAt, profile} in chrome.storage.local.
 *
 * Requires manifest.oauth2.client_id to be a real Chrome-Extension OAuth
 * client created in Google Cloud Console for the mcgheelab-f56cc project.
 */
export async function signInWithGoogle() {
  const googleToken = await new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!token) return reject(new Error('No Google OAuth token returned'));
      resolve(token);
    });
  });

  // Exchange the Google access token for a Firebase ID token.
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${FIREBASE_CONFIG.apiKey}`;
  const body = {
    postBody: `access_token=${encodeURIComponent(googleToken)}&providerId=google.com`,
    requestUri: 'http://localhost',  // ignored when access_token is in postBody
    returnIdpCredential: true,
    returnSecureToken: true,
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Firebase signInWithIdp failed (${res.status}): ${detail}`);
  }
  const data = await res.json();

  const expiresAt = Date.now() + (parseInt(data.expiresIn, 10) || 3600) * 1000;
  const cached = {
    idToken:      data.idToken,
    refreshToken: data.refreshToken,
    expiresAt,
    profile: {
      uid:         data.localId,
      email:       data.email,
      displayName: data.fullName || data.displayName || data.email,
      photoUrl:    data.photoUrl || '',
      provider:    'google.com',
    },
  };
  await chrome.storage.local.set({ [STORAGE_KEY]: cached });
  return cached.profile;
}

export async function signOut() {
  // Drop the cached Google OAuth token so the next sign-in re-prompts.
  try {
    const token = await new Promise((resolve) =>
      chrome.identity.getAuthToken({ interactive: false }, (t) => resolve(t || null))
    );
    if (token) {
      await new Promise((resolve) =>
        chrome.identity.removeCachedAuthToken({ token }, resolve)
      );
    }
  } catch (_) { /* best effort */ }
  await chrome.storage.local.remove(STORAGE_KEY);
}

async function _readCache() {
  const obj = await chrome.storage.local.get(STORAGE_KEY);
  return obj[STORAGE_KEY] || null;
}

export async function getCurrentUser() {
  const c = await _readCache();
  return c ? c.profile : null;
}

export async function getValidIdToken() {
  const c = await _readCache();
  if (!c) throw new Error('Not signed in');
  if (c.expiresAt - REFRESH_LEEWAY_SECONDS * 1000 > Date.now()) return c.idToken;

  // Refresh via secureToken endpoint.
  const url = `https://securetoken.googleapis.com/v1/token?key=${FIREBASE_CONFIG.apiKey}`;
  const params = new URLSearchParams({
    grant_type: 'refresh_token',
    refresh_token: c.refreshToken,
  });
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString(),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Firebase token refresh failed (${res.status}): ${detail}`);
  }
  const data = await res.json();
  const expiresAt = Date.now() + (parseInt(data.expires_in, 10) || 3600) * 1000;
  const updated = Object.assign({}, c, {
    idToken: data.id_token,
    refreshToken: data.refresh_token,
    expiresAt,
  });
  await chrome.storage.local.set({ [STORAGE_KEY]: updated });
  return updated.idToken;
}

/* ---------------- Firestore (REST) — wired in 6b ---------------- */

const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${FIREBASE_CONFIG.projectId}/databases/(default)/documents`;

/** Convert a JS object to Firestore's typed Value JSON. */
function _toFirestoreFields(obj) {
  const fields = {};
  for (const [k, v] of Object.entries(obj || {})) {
    fields[k] = _toFirestoreValue(v);
  }
  return fields;
}
function _toFirestoreValue(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') {
    return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  }
  if (typeof v === 'string') return { stringValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(_toFirestoreValue) } };
  if (typeof v === 'object') return { mapValue: { fields: _toFirestoreFields(v) } };
  return { stringValue: String(v) };
}
function _fromFirestoreValue(val) {
  if (!val) return null;
  if ('nullValue' in val) return null;
  if ('booleanValue' in val) return val.booleanValue;
  if ('integerValue' in val) return parseInt(val.integerValue, 10);
  if ('doubleValue' in val) return val.doubleValue;
  if ('stringValue' in val) return val.stringValue;
  if ('timestampValue' in val) return val.timestampValue;
  if ('arrayValue' in val) return (val.arrayValue.values || []).map(_fromFirestoreValue);
  if ('mapValue' in val) return _fromFirestoreFields(val.mapValue.fields || {});
  return null;
}
function _fromFirestoreFields(fields) {
  const out = {};
  for (const [k, v] of Object.entries(fields || {})) out[k] = _fromFirestoreValue(v);
  return out;
}

async function _fsFetch(path, init = {}) {
  const idToken = await getValidIdToken();
  const headers = Object.assign({
    Authorization: `Bearer ${idToken}`,
    'Content-Type': 'application/json',
  }, init.headers || {});
  const res = await fetch(`${FIRESTORE_BASE}/${path}`, Object.assign({}, init, { headers }));
  if (!res.ok && res.status !== 404) {
    const detail = await res.text().catch(() => res.statusText);
    // Surface a permission-denied 403 with a more actionable message so the
    // popup can tell the user "ask the PI" instead of dumping raw JSON.
    if (res.status === 403 && /permission/i.test(detail || '')) {
      const err = new Error(
        `Permission denied. Your account isn't on the extension allowlist yet — ` +
        `ask the PI to add your email to labConfig/extensionMembers via the ` +
        `dashboard's Library page.`
      );
      err.code = 'permission-denied';
      throw err;
    }
    throw new Error(`Firestore ${init.method || 'GET'} ${path} failed (${res.status}): ${detail}`);
  }
  return res;
}

export async function firestoreGetDoc(path) {
  const res = await _fsFetch(path, { method: 'GET' });
  if (res.status === 404) return null;
  const data = await res.json();
  return _fromFirestoreFields(data.fields || {});
}

export async function firestoreSetDoc(path, doc) {
  await _fsFetch(`${path}`, {
    method: 'PATCH',
    body: JSON.stringify({ fields: _toFirestoreFields(doc) }),
  });
}

export async function firestoreCollectionAdd(collectionPath, doc) {
  const res = await _fsFetch(collectionPath, {
    method: 'POST',
    body: JSON.stringify({ fields: _toFirestoreFields(doc) }),
  });
  const data = await res.json();
  // name = "projects/.../databases/(default)/documents/<path>/<docId>"
  const id = String(data.name || '').split('/').pop();
  return id;
}

export async function firestoreDeleteDoc(path) {
  await _fsFetch(path, { method: 'DELETE' });
}

/** V3.820 — PATCH only the named fields (an updateMask), leaving the rest of the doc alone. */
export async function firestoreUpdateFields(path, fields) {
  const keys = Object.keys(fields || {});
  if (!keys.length) return;
  const mask = keys.map((k) => 'updateMask.fieldPaths=' + encodeURIComponent(k)).join('&');
  await _fsFetch(`${path}?${mask}`, {
    method: 'PATCH',
    body: JSON.stringify({ fields: _toFirestoreFields(fields) }),
  });
}

/** V3.820 — a structured query over one collection → [{ id, data }]. */
export async function firestoreRunQuery(structuredQuery) {
  const idToken = await getValidIdToken();
  const res = await fetch(`${FIRESTORE_BASE}:runQuery`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${idToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ structuredQuery }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Firestore runQuery failed (${res.status}): ${detail}`);
  }
  const rows = await res.json();
  return (Array.isArray(rows) ? rows : []).filter((r) => r.document).map((r) => ({
    id: String(r.document.name || '').split('/').pop(),
    data: _fromFirestoreFields(r.document.fields || {}),
  }));
}

/* ---------------- Storage (REST) — wired in 6b ---------------- */

const STORAGE_BASE = `https://firebasestorage.googleapis.com/v0/b/${FIREBASE_CONFIG.storageBucket}/o`;

export async function uploadToStorage(storagePath, blob, contentType) {
  const idToken = await getValidIdToken();
  const url = `${STORAGE_BASE}?uploadType=media&name=${encodeURIComponent(storagePath)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${idToken}`,
      'Content-Type': contentType || 'application/octet-stream',
    },
    body: blob,
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Storage upload failed (${res.status}): ${detail}`);
  }
  return await res.json();   // { name, downloadTokens, ... }
}

export async function storageDownloadUrl(storagePath) {
  const idToken = await getValidIdToken();
  const url = `${STORAGE_BASE}/${encodeURIComponent(storagePath)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${idToken}` } });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Storage metadata fetch failed (${res.status}): ${detail}`);
  }
  const data = await res.json();
  if (!data.downloadTokens) throw new Error('No download token on storage object');
  return `${STORAGE_BASE}/${encodeURIComponent(storagePath)}?alt=media&token=${data.downloadTokens.split(',')[0]}`;
}
