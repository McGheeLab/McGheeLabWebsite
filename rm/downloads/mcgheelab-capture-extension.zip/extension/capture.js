/* capture.js — phase 6b orchestrator. Runs in the background service
 * worker. Given a detection record from content.js, it:
 *
 *   1. Fetches the PDF blob (best effort — paywalled URLs will fail loudly).
 *   2. Computes a SHA-256 hash.
 *   3. Looks up CrossRef metadata when a DOI is present (CrossRef's REST API
 *      is CORS-enabled and returns JSON, so it works from a service worker).
 *      arXiv / PubMed lookups are deliberately deferred to phase 6c, which
 *      has access to the dashboard's /api/library/lookup proxy.
 *   4. Mints a kebab-case paper ID from author+year+title-word, with
 *      identifier and hash fallbacks. Mirrors js/library-metadata.js.
 *   5. Uploads the PDF to Firebase Storage at papers/{paperId}/{hash}.pdf.
 *   6. Writes a Firestore doc to pending_captures/{paperId} carrying every
 *      field the dashboard's 6c sync will need to materialize a paper item.
 *
 * The queue-doc shape is the source of truth for 6c — keep it stable.
 */

import {
  uploadToStorage,
  firestoreSetDoc,
  firestoreGetDoc,
  getCurrentUser,
} from './firebase-rest.js';
import { publicUrl, doiFromPdfBlob } from './pdf-fetch.js';

// Content-type prefixes we accept as "this is actually a PDF". Some
// publisher CDNs return application/x-pdf or octet-stream.
const PDF_CONTENT_TYPE_RE = /(application\/(pdf|x-pdf|octet-stream))/i;

const STOP_WORDS = new Set([
  'a', 'an', 'the', 'of', 'and', 'or', 'in', 'on', 'for', 'to', 'with',
  'from', 'by', 'as', 'at', 'is', 'are', 'be', 'this', 'that', 'using',
  'via', 'over', 'under', 'between', 'into',
]);

/* ---------------- Public ---------------- */

/**
 * Capture a paper from a detection record. Throws on any unrecoverable
 * error; the popup surfaces the message verbatim.
 *
 * @param {Object} detection - shape from content.js _detectFromMetaAndUrl
 * @param {Object} [opts]
 * @param {(stage:string)=>void} [opts.onStage] - progress hook
 * @param {string}      [opts.pdfUrlOverride] - bypass _resolvePdfUrl (6f)
 * @param {ArrayBuffer} [opts.pdfBuffer]      - raw PDF bytes from popup (6f)
 * @param {string}      [opts.pdfFilename]    - cosmetic, for source_url
 * @returns {Promise<{paper_id, storage_path, hash, size_bytes, dedup, metadata, pdf_source}>}
 */
export async function captureFromDetection(detection, opts = {}) {
  const onStage = typeof opts.onStage === 'function' ? opts.onStage : () => {};

  if (!_isPaperish(detection) && !opts.pdfBuffer) {
    throw new Error('No paper identifiers detected on this page.');
  }
  const profile = await getCurrentUser();
  if (!profile) throw new Error('Not signed in.');

  let pdfUrl = opts.pdfUrlOverride || _resolvePdfUrl(detection);
  let pdfSource = 'auto';   // 'auto' | 'auto-link' | 'page-fetch' | 'browser-download' | 'unpaywall' | 'manual-url' | 'manual-file'

  let blob;
  if (opts.pdfBuffer) {
    if (opts.pdfBuffer.byteLength < 1024) throw new Error('Selected file is too small to be a PDF.');
    blob = new Blob([opts.pdfBuffer], { type: 'application/pdf' });
    pdfSource = 'manual-file';
    if (!pdfUrl) pdfUrl = `(local file: ${opts.pdfFilename || 'paper.pdf'})`;
  } else {
    // V3.822 — the ladder (obtainPdf): the worker's own fetch of the page's
    // PDF routes, the same routes AS THE PAGE, Chrome's download pipeline,
    // then Unpaywall. A pasted URL skips the page's links and Unpaywall.
    const candidates = opts.pdfUrlOverride ? [] : (opts.candidates || []);
    if (!pdfUrl && !candidates.length) {
      throw new Error('No PDF URL on this page. Try the publisher\'s "Download PDF" link, then capture from there.');
    }
    const got = await obtainPdf({
      pdfUrl, candidates, doi: opts.pdfUrlOverride ? '' : (detection.doi || ''), email: profile.email, onStage,
      strategies: Object.assign({ direct: _fetchPdf, unpaywall: _tryUnpaywallPdf }, opts.strategies || {}),
    });
    blob = got.blob; pdfUrl = got.url;
    pdfSource = opts.pdfUrlOverride && got.source === 'auto' ? 'manual-url' : got.source;
  }

  // V3.823 — no DOI from the page? The PDF usually carries its own (XMP /
  // Info dictionary); it then drives the CrossRef lookup and the paper id.
  let doiFound = '';
  if (!detection.doi) {
    try { doiFound = await doiFromPdfBlob(blob); } catch (_) {}
    if (doiFound) detection = Object.assign({}, detection, { doi: doiFound, doi_source: 'pdf-bytes' });
  }

  onStage('Hashing…');
  const fullHash = await _sha256Hex(blob);
  const shortHash = fullHash.slice(0, 16);

  // 6d will replace this with a paper_index/{hash} lookup. For 6b we settle
  // for "is there already a pending_captures doc whose pdf.hash matches?"
  // — done after we mint the id, since pending_captures docs are keyed by
  // paper_id and we need to look at fields. Cheaper proxy: try the obvious
  // candidate id first.
  onStage('Looking up metadata…');
  const metadata = await _lookupMetadata(detection);

  const paperId = _mintPaperId(detection, metadata, shortHash);

  // Light dedupe: if pending_captures/{paperId} already has the same hash,
  // skip the upload and reuse the existing doc.
  let dedup = false;
  try {
    const existing = await firestoreGetDoc(`pending_captures/${paperId}`);
    if (existing && existing.pdf && (existing.pdf.full_hash === fullHash || existing.pdf.hash === shortHash)) {
      dedup = true;
    }
  } catch (_) { /* not a fatal error path */ }

  const storagePath = `papers/${paperId}/${shortHash}.pdf`;

  if (!dedup) {
    onStage('Uploading to Firebase Storage…');
    await uploadToStorage(storagePath, blob, 'application/pdf');
  }

  onStage('Writing capture record…');
  const nowIso = new Date().toISOString();
  await firestoreSetDoc(`pending_captures/${paperId}`, {
    paper_id: paperId,
    captured_at_iso: nowIso,
    captured_by_uid: profile.uid,
    captured_by_email: profile.email || '',
    captured_by_name: profile.displayName || '',
    // V3.823 — a PDF tab records the article page it came from, else the DOI
    // as a link, never a pre-signed key (publicUrl strips X-Amz-* / Signature).
    source_url: publicUrl(detection.from_page || (detection.source === 'pdf-tab' && detection.doi ? 'https://doi.org/' + detection.doi : '') || detection.url || ''),
    detection: {
      doi: detection.doi || '',
      arxiv_id: detection.arxiv_id || '',
      pmid: detection.pmid || '',
      pdf_url: publicUrl(pdfUrl),
      title: detection.title || '',
      source: detection.source || '',
    },
    metadata: metadata || {},
    pdf: {
      storage_path: storagePath,
      hash: shortHash,
      full_hash: fullHash,
      size_bytes: blob.size,
      content_type: 'application/pdf',
      pdf_source: pdfSource,
    },
    status: 'pending',  // 6c flips this to 'merged' after items.json update
  });

  return {
    paper_id: paperId,
    storage_path: storagePath,
    hash: shortHash,
    pdf_source: pdfSource,
    size_bytes: blob.size,
    dedup,
    metadata: metadata || null,
    title: (metadata && metadata.title) || detection.title || '',
    doi: detection.doi || '',
    doi_found: doiFound ? 'pdf' : '',
  };
}

/**
 * V3.822 — get the PDF bytes, one route after another. DOM-free: every
 * route is a strategy the caller passes, so node tests drive the ladder with
 * stubs and the service worker passes the real ones (pdf-fetch.js).
 *
 *   strategies.direct(url)           → Blob                       the worker's own fetch (_fetchPdf)
 *   strategies.page(url)             → { blob, url }              fetched inside the tab, as the page
 *   strategies.download(url)         → { blob, url, filename } | { needsFileAccess, filename, path }
 *   strategies.unpaywall(doi, email) → url | null
 *
 * Order: direct on up to three routes → page on up to two → Chrome download
 * on the best route → Unpaywall (then direct on its URL). A download that
 * reached the disk but could not be read back is reported last, as
 * error.code 'needs-file-access' with the filename, so the person can allow
 * file access or upload it.
 *
 * @returns {Promise<{ blob: Blob, url: string, source: string }>}
 */
export async function obtainPdf(ctx) {
  const onStage = typeof ctx.onStage === 'function' ? ctx.onStage : () => {};
  const S = ctx.strategies || {};
  const urls = _candidateUrls(ctx.pdfUrl, ctx.candidates);
  const tried = [];
  let landed = null;   // a download on disk the worker could not read

  if (S.direct) {
    for (const url of urls.slice(0, 3)) {
      onStage(url === ctx.pdfUrl ? 'Downloading PDF…' : 'Trying the page\'s PDF link…');
      try { const blob = await S.direct(url); if (blob) return { blob, url, source: url === ctx.pdfUrl ? 'auto' : 'auto-link' }; tried.push('direct ' + _short(url) + ': nothing'); }
      catch (e) { tried.push('direct ' + _short(url) + ': ' + e.message); }
    }
  }
  if (S.page) {
    for (const url of urls.slice(0, 2)) {
      onStage('Fetching the PDF as the page (the journal\'s own download)…');
      try { const got = await S.page(url); if (got && got.blob) return { blob: got.blob, url: got.url || url, source: 'page-fetch' }; tried.push('page ' + _short(url) + ': nothing'); }
      catch (e) { tried.push('page ' + _short(url) + ': ' + e.message); }
    }
  }
  if (S.download && urls.length) {
    const url = urls[0];
    onStage('Asking Chrome to download it…');
    try {
      const got = await S.download(url);
      if (got && got.blob) return { blob: got.blob, url: got.url || url, source: 'browser-download' };
      if (got && got.needsFileAccess) { landed = got; tried.push('download ' + _short(url) + ': saved as ' + (got.filename || 'a file') + ', but the extension may not read files from disk'); }
      else tried.push('download ' + _short(url) + ': nothing came back');
    } catch (e) { tried.push('download ' + _short(url) + ': ' + e.message); }
  }
  if (S.unpaywall && ctx.doi) {
    onStage('PDF unavailable — checking Unpaywall…');
    let oaUrl = null, asked = false;
    try { oaUrl = await S.unpaywall(ctx.doi, ctx.email); asked = true; } catch (e) { tried.push('unpaywall: ' + e.message); }
    if (oaUrl && !urls.includes(oaUrl) && S.direct) {
      onStage('Downloading PDF (Unpaywall)…');
      try { const blob = await S.direct(oaUrl); if (blob) return { blob, url: oaUrl, source: 'unpaywall' }; tried.push('unpaywall mirror: nothing'); }
      catch (e) { tried.push('unpaywall mirror: ' + e.message); }
    } else if (asked && !oaUrl) tried.push('unpaywall: no open-access copy');
  }
  const err = new Error(landed
    ? `Chrome saved "${landed.filename}" to your Downloads, but the extension is not allowed to read files from disk. Turn on "Allow access to file URLs" for it (Open extension settings), then press Capture again — or Upload file… below.`
    : (tried.length ? 'Could not get the PDF.\n' + tried.join('\n') : 'No PDF URL on this page.'));
  err.tried = tried;
  if (landed) { err.code = 'needs-file-access'; err.filename = landed.filename || ''; err.path = landed.path || ''; }
  throw err;
}

function _candidateUrls(pdfUrl, candidates) {
  const out = [];
  const push = (u) => { u = typeof u === 'string' ? u.trim() : (u && u.url) || ''; if (u && /^https?:\/\//i.test(u) && !out.includes(u)) out.push(u); };
  push(pdfUrl); (candidates || []).forEach(push);
  return out;
}
function _short(u) { return String(u || '').replace(/^https?:\/\//, '').slice(0, 60); }

/* ---------------- Internals ---------------- */

function _isPaperish(d) {
  return !!(d && (d.doi || d.arxiv_id || d.pmid || d.pdf_url));
}

function _resolvePdfUrl(d) {
  if (d.pdf_url) return d.pdf_url;
  if (d.url && /\.pdf($|\?)/i.test(d.url)) return d.url;
  // arXiv abs URL → derive pdf URL (content.js usually does this, but
  // belt-and-braces if a future detector path skips it).
  if (d.arxiv_id) return `https://arxiv.org/pdf/${d.arxiv_id}.pdf`;
  return '';
}

// Fetch a URL and return a Blob, but only if it's a real PDF. If the
// server returns text/html (publisher landing page, JS-redirect, etc.),
// retry strategies in order:
//   1. Send Accept: application/pdf (some servers content-negotiate)
//   2. Send the request with credentials so the user's institutional
//      cookies ride along
//   3. Sniff the HTML body for an embedded PDF (meta-refresh, iframe,
//      embed, object, or plain anchor) and recursively follow once
// Only after all of those fail do we surface a "looks paywalled" error.
async function _fetchPdf(url, opts = {}) {
  const depth = opts._depth || 0;
  if (depth > 3) {
    throw new Error('Too many redirects while resolving PDF URL.');
  }

  const headers = { 'Accept': 'application/pdf,application/x-pdf;q=0.9,*/*;q=0.5' };
  // Default to credentials:'include' — paper PDFs behind institutional
  // logins (ezProxy, Shibboleth, publisher SSO) need the browser session
  // cookies to come through. Privacy is fine here: the request goes to
  // the publisher the user just navigated to.
  const useCreds = opts.credentials || 'include';

  let res;
  try {
    res = await fetch(url, { credentials: useCreds, redirect: 'follow', headers });
  } catch (e) {
    throw new Error(`Network error fetching PDF: ${e.message || e}`);
  }
  if (!res.ok) throw new Error(`PDF fetch failed (${res.status} ${res.statusText}).`);

  const ct = (res.headers.get('Content-Type') || '').toLowerCase();
  if (ct && PDF_CONTENT_TYPE_RE.test(ct)) {
    const blob = await res.blob();
    if (!blob || blob.size < 1024) {
      throw new Error('PDF response was too small to be a real paper.');
    }
    return blob;
  }

  // Got HTML (or no content-type). Try once more with cookies disabled —
  // some servers downgrade HTML when they see a session cookie they
  // don't expect. Only do this on the first attempt.
  if (!opts._noCredsRetry && useCreds === 'include') {
    try {
      const blob2 = await _fetchPdf(url, { _depth: depth + 1, credentials: 'omit', _noCredsRetry: true });
      return blob2;
    } catch (_) { /* fall through to HTML sniffing */ }
  }

  // Sniff the HTML body for an embedded / linked PDF.
  if (/text\/html/i.test(ct) || !ct) {
    const text = await res.text();
    const inner = _sniffPdfUrlFromHtml(text, res.url || url);
    if (inner && inner !== url) {
      return _fetchPdf(inner, { _depth: depth + 1 });
    }
  }

  throw new Error(
    `URL returned ${ct || 'non-PDF content'} — the page may be a publisher landing page, a JS-driven viewer, or behind a login wall. ` +
    `Try Manual options ▾ → "Paste PDF URL" with a direct .pdf link, or Upload file.`
  );
}

// Look for a PDF URL inside an HTML body. Returns an absolute URL or
// null. Strategies, in priority order:
//   - <meta http-equiv="refresh" content="N; url=...">
//   - <iframe|embed|object src="...pdf">
//   - <a ... href="...pdf"> with text matching "Download" / "PDF"
//   - First .pdf URL appearing in the page
function _sniffPdfUrlFromHtml(html, baseUrl) {
  if (!html || typeof html !== 'string') return null;
  // 1. meta refresh
  const meta = html.match(/<meta[^>]+http-equiv\s*=\s*["']?refresh["']?[^>]+content\s*=\s*["']?\s*\d+\s*;\s*url=([^"'>\s]+)/i);
  if (meta && meta[1]) return _absoluteUrl(meta[1], baseUrl);
  // 2. embedded viewer / iframe / object pointing at a PDF
  const embed = html.match(/<(?:iframe|embed|object)[^>]+(?:src|data)\s*=\s*["']([^"']+\.pdf(?:\?[^"']*)?)["']/i);
  if (embed && embed[1]) return _absoluteUrl(embed[1], baseUrl);
  // 3. anchor whose text suggests a download
  const downloadAnchor = html.match(/<a[^>]+href\s*=\s*["']([^"']+\.pdf(?:\?[^"']*)?)["'][^>]*>\s*[^<]*?(?:download|pdf|full text)/i);
  if (downloadAnchor && downloadAnchor[1]) return _absoluteUrl(downloadAnchor[1], baseUrl);
  // 4. citation_pdf_url meta (mirrors what content.js sniffs on the
  //    publisher page itself, but useful when the URL we fetched IS the
  //    publisher landing page).
  const cite = html.match(/<meta[^>]+name\s*=\s*["']citation_pdf_url["'][^>]+content\s*=\s*["']([^"']+)["']/i);
  if (cite && cite[1]) return _absoluteUrl(cite[1], baseUrl);
  // 5. last resort — any .pdf URL
  const any = html.match(/https?:\/\/[^\s"'<>]+\.pdf(?:\?[^\s"'<>]*)?/i);
  if (any && any[0]) return any[0];
  return null;
}

function _absoluteUrl(href, base) {
  try { return new URL(href, base).href; } catch { return href; }
}

async function _sha256Hex(blob) {
  const buf = await blob.arrayBuffer();
  const hash = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

async function _lookupMetadata(d) {
  if (d.doi) {
    try {
      const res = await fetch(`https://api.crossref.org/works/${encodeURIComponent(d.doi)}`, {
        headers: { 'Accept': 'application/json' },
      });
      if (res.ok) {
        const j = await res.json();
        return _crossrefToUnified(j.message, d);
      }
    } catch (_) { /* fall through */ }
  }
  // arXiv / PubMed metadata are filled in by the dashboard sync (6c) which
  // can call /api/library/lookup with proper XML parsing.
  return {
    source: 'extension-detection',
    title: d.title || '',
    doi: d.doi || '',
    pmid: d.pmid || '',
    arxiv_id: d.arxiv_id || '',
  };
}

function _crossrefToUnified(m, detection) {
  if (!m) return null;
  const authors = (m.author || []).map(a => ({
    given: a.given || '',
    family: a.family || a.name || '',
  }));
  const issued = (m.issued && m.issued['date-parts'] && m.issued['date-parts'][0]) || [];
  const year = issued[0] ? String(issued[0]) : '';
  const title = Array.isArray(m.title) ? (m.title[0] || '') : (m.title || '');
  const journal = Array.isArray(m['container-title']) ? (m['container-title'][0] || '') : (m['container-title'] || '');
  const journalIso = Array.isArray(m['short-container-title']) ? (m['short-container-title'][0] || '') : '';
  const pages = m.page || '';
  return {
    source: 'crossref',
    title,
    authors,
    year,
    journal,
    journal_iso: journalIso,
    issn: (m.ISSN && m.ISSN[0]) || '',
    volume: m.volume || '',
    issue: m.issue || '',
    pages,
    doi: (m.DOI || detection.doi || '').toLowerCase(),
    pmid: detection.pmid || '',
    arxiv_id: detection.arxiv_id || '',
    abstract: m.abstract || '',
    url: m.URL || (m.DOI ? `https://doi.org/${m.DOI}` : ''),
  };
}

function _mintPaperId(detection, metadata, shortHash) {
  const m = metadata || {};
  const firstAuthor = (m.authors && m.authors[0]) || null;
  const lastName = firstAuthor && firstAuthor.family ? _slug(firstAuthor.family) : '';
  const year = String(m.year || '').slice(0, 4);
  const titleWord = _shortTitleWord(m.title || detection.title || '');

  // A bare title-word like "foo" is too generic to mint an id from on its
  // own — require an author surname or a year to anchor it. Otherwise fall
  // through to the identifier-based fallbacks below.
  if (lastName || year) {
    return [lastName, year, titleWord].filter(Boolean).join('-');
  }

  if (detection.doi) return _slug(detection.doi);
  if (detection.arxiv_id) return `arxiv-${_slug(detection.arxiv_id)}`;
  if (detection.pmid) return `pmid-${detection.pmid}`;
  return `paper-${shortHash.slice(0, 8)}`;
}

function _slug(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60) || '';
}

function _shortTitleWord(title) {
  return (title || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter(w => w && !STOP_WORDS.has(w))[0] || '';
}

/* ---------------- Unpaywall (6f) ---------------- */

// Look up an Open-Access PDF mirror via Unpaywall. The API requires an
// `email` parameter (no key, no auth). We use the signed-in user's email
// when available so Unpaywall's analytics can attribute the request.
async function _tryUnpaywallPdf(doi, email) {
  if (!doi) return null;
  const params = new URLSearchParams({ email: email || 'mcgheelab@arizona.edu' });
  const url = `https://api.unpaywall.org/v2/${encodeURIComponent(doi)}?${params}`;
  try {
    const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if (!res.ok) return null;
    const j = await res.json();
    if (!j) return null;
    if (j.best_oa_location && j.best_oa_location.url_for_pdf) {
      return j.best_oa_location.url_for_pdf;
    }
    for (const loc of (j.oa_locations || [])) {
      if (loc && loc.url_for_pdf) return loc.url_for_pdf;
    }
  } catch (_) { /* not fatal */ }
  return null;
}

// Exposed only so background.js can call them in tests / manual probes if
// needed. Not part of the public API.
export const _internals = {
  _isPaperish, _resolvePdfUrl, _slug, _shortTitleWord,
  _crossrefToUnified, _mintPaperId, _tryUnpaywallPdf,
  _sniffPdfUrlFromHtml, _absoluteUrl, _candidateUrls,
};
