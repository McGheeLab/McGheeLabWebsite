/* background.js — MV3 service worker. Holds the auth lifecycle, the
 * per-tab paper-detection cache, the capture orchestrator, and a
 * message bus the popup uses.
 *
 * Phase 6a:
 *   - Receive paper-detection events from content scripts; cache by tab id.
 *   - Sign-in / sign-out / get-current-user via runtime messages.
 *   - Toolbar badge '?' on tabs that look like papers.
 *
 * Phase 6b (this file's `capture` handler):
 *   - On user click in the popup, fetch the PDF, hash it, look up CrossRef,
 *     upload to Firebase Storage, and write a pending_captures Firestore
 *     doc that the dashboard merges into items.json on its next load.
 *
 * 6c will add dashboard sync; 6d will replace the '?' badge with ✓ / +
 * based on paper-index.
 */
import {
  signInWithGoogle,
  signOut,
  getCurrentUser,
  getValidIdToken,
  firestoreGetDoc,
  firestoreCollectionAdd,
} from './firebase-rest.js';
import { captureFromDetection } from './capture.js';
import { pdfLinksOnTab, pageFetcher, browserDownloader, probePdfRoutes, looksLikePdfUrl, minePdfUrl, piiToDoi, sameWork, sniffPdfDoi } from './pdf-fetch.js';
import { recordObservation, runDueChecks, watchStatus } from './price-watch.js';
import {
  classifyQuery,
  searchByText,
  lookupByIdentifier,
  addMetadataOnly,
} from './search.js';

// tabId → { url, doi, arxiv_id, pmid, pdf_url, title, source, in_library_paper_id? }
const _tabDetections = new Map();
// V3.819 — tabId → number of items for sale the content script found
// (confident sources only). Drives the '+' badge on vendor pages.
const _tabItemCounts = new Map();
// V3.820 — tabId → the last full scrape (items + the page as text), so
// add-item can save the page a price came from without a second round trip.
const _tabScrapes = new Map();
const RM_PROCUREMENT_URL = 'https://mcgheelab.com/rm/pages/procurement.html';

/* V3.824 — a capture's outcome outlives the popup. The popup closes the moment
 * focus moves (a download bubble, a click elsewhere) while the worker is still
 * climbing the PDF ladder, so the result or the error used to vanish — Alex
 * saw a PDF arrive and found nothing in the library. Now every stage, the
 * outcome and what was tried are kept per tab in chrome.storage.session (the
 * popup shows "Last capture on this tab" when it reopens), the badge turns
 * '!' on failure, and a line goes to userData/{uid}/captureLog for forensics. */
const _sessionStore = (chrome.storage && chrome.storage.session) || null;
async function _setCaptureState(tabId, patch) {
  const key = 'capture:' + tabId;
  try {
    const cur = _sessionStore ? ((await _sessionStore.get(key))[key] || {}) : {};
    const next = Object.assign({}, cur, patch, { at: new Date().toISOString() });
    if (_sessionStore) await _sessionStore.set({ [key]: next });
    return next;
  } catch (_) { return patch; }
}
async function _getCaptureState(tabId) {
  const key = 'capture:' + tabId;
  try { return _sessionStore ? ((await _sessionStore.get(key))[key] || null) : null; } catch (_) { return null; }
}
async function _clearCaptureState(tabId) { try { if (_sessionStore) await _sessionStore.remove('capture:' + tabId); } catch (_) {} }
function _tellPopup(msg) { try { chrome.runtime.sendMessage(msg, () => { void chrome.runtime.lastError; }); } catch (_) {} }
async function _logCapture(entry) {
  try {
    const profile = await getCurrentUser(); if (!profile) return;
    await firestoreCollectionAdd(`userData/${profile.uid}/captureLog`, Object.assign({ at: new Date().toISOString(), version: EXTENSION_VERSION, how: 'extension' }, entry));
  } catch (e) { console.warn('[capture] log not written:', e && e.message); }
}
const PRICE_ALARM = 'mcghee-price-watch';

// V3.820 — the three-monthly re-check: wake every 6 hours, re-scrape what is due.
function _armPriceAlarm() {
  try { chrome.alarms.create(PRICE_ALARM, { periodInMinutes: 360, delayInMinutes: 5 }); } catch (_) { /* alarms permission missing */ }
}
chrome.runtime.onInstalled.addListener(_armPriceAlarm);
chrome.runtime.onStartup.addListener(_armPriceAlarm);
if (chrome.alarms && chrome.alarms.onAlarm) {
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (!alarm || alarm.name !== PRICE_ALARM) return;
    try { const r = await runDueChecks({ max: 3 }); console.log('[price-watch] alarm run:', JSON.stringify(r)); }
    catch (e) { console.warn('[price-watch] alarm run failed:', e && e.message); }
  });
}
const EXTENSION_VERSION = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '';

// Cache of paper_index lookups so we don't re-hit Firestore on every tab
// activation. key = `${kind}:${value}` (lowercased). value = { paperId,
// ts }. paperId === null means "checked, not in library".
const _libraryCache = new Map();
const LIBRARY_CACHE_TTL_MS = 5 * 60 * 1000;

function _isPaperish(d) {
  return !!(d && (d.doi || d.arxiv_id || d.pmid || d.pdf_url));
}

// MUST stay in sync with _indexKey() in js/library-sync.js — both are how
// paper_index Firestore doc ids are computed. If you change one, change
// the other.
function _idKey(kind, value) {
  const v = String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return `${kind}_${v}`;
}

async function _checkLibrary(detection) {
  if (!detection) return null;
  const profile = await getCurrentUser();
  if (!profile) return null;  // Can't read paper_index without auth.
  // Try identifiers in priority order — DOI is the most authoritative,
  // then arXiv (publishers don't always mint DOIs for preprints), then
  // PubMed for biomedical papers without DOI metadata.
  const tries = [];
  if (detection.doi)      tries.push(['doi', detection.doi]);
  if (detection.arxiv_id) tries.push(['arxiv', detection.arxiv_id]);
  if (detection.pmid)     tries.push(['pmid', detection.pmid]);
  for (const [kind, value] of tries) {
    const cacheKey = `${kind}:${String(value).toLowerCase()}`;
    const cached = _libraryCache.get(cacheKey);
    if (cached && (Date.now() - cached.ts) < LIBRARY_CACHE_TTL_MS) {
      if (cached.paperId) return cached.paperId;
      continue;
    }
    try {
      const doc = await firestoreGetDoc(`paper_index/${_idKey(kind, value)}`);
      if (doc && doc.paper_id) {
        _libraryCache.set(cacheKey, { paperId: doc.paper_id, ts: Date.now() });
        return doc.paper_id;
      }
      _libraryCache.set(cacheKey, { paperId: null, ts: Date.now() });
    } catch (e) {
      // Permission errors shouldn't crash the badge logic.
      console.warn('[paper-index] lookup failed:', e.message);
    }
  }
  return null;
}

/* V3.823 — a tab that IS the PDF. Chrome's viewer runs no content script, so
 * the worker builds the detection itself: the tab's URL is the PDF route, and
 * the article page this tab (or its opener) showed a moment ago lends its
 * DOI and title when the two are the same work (sameWork: the DOI, arXiv id
 * or Elsevier PII appears in the PDF URL, or the PDF route sits under the
 * article's path). Failing that, an Elsevier PII in the URL becomes a DOI
 * guess that CrossRef must confirm. */
const _piiDoiCache = new Map();
async function _doiFromPii(pii) {
  const cand = piiToDoi(pii); if (!cand) return '';
  if (_piiDoiCache.has(cand)) return _piiDoiCache.get(cand);
  let doi = '';
  try {
    const r = await fetch('https://api.crossref.org/works/' + encodeURIComponent(cand), { headers: { Accept: 'application/json' } });
    if (r.ok) { const j = await r.json(); doi = String((j && j.message && j.message.DOI) || cand).toLowerCase(); }
  } catch (_) { /* offline: no guess */ }
  _piiDoiCache.set(cand, doi);
  return doi;
}
/** A content-script detection that is really a PDF document: the viewer's own page, or a pdf-looking URL with nothing on it. */
function _isPdfDocument(det) {
  return !!det && !(det.doi || det.arxiv_id || det.pmid) && (det.is_pdf === true || looksLikePdfUrl(det.url || ''));
}
async function _pdfTabDetection(tabId, scriptDet) {
  let tab; try { tab = await chrome.tabs.get(tabId); } catch (_) { return null; }
  const url = tab.url || tab.pendingUrl || (scriptDet && scriptDet.url) || '';
  if (!looksLikePdfUrl(url) && !(scriptDet && scriptDet.is_pdf)) return null;
  const here = _tabDetections.get(tabId);
  const prevSame = here && here.source === 'pdf-tab' ? here._prev : here;   // a second look keeps the article it already found
  const prevOpener = typeof tab.openerTabId === 'number' ? _tabDetections.get(tab.openerTabId) : null;
  const prev = [prevSame, prevOpener].find((p) => p && p.source !== 'pdf-tab' && sameWork(p, url)) || null;
  const mined = minePdfUrl(url);
  const d = {
    url, pdf_url: url, source: 'pdf-tab',
    title: (prev && prev.title) || '',
    doi: (prev && prev.doi) || mined.doi || '',
    arxiv_id: (prev && prev.arxiv_id) || mined.arxiv_id || '',
    pmid: (prev && prev.pmid) || '',
    from_page: prev ? prev.url : '',
    pdf_candidates: prev && prev.pdf_url && prev.pdf_url !== url ? [{ url: prev.pdf_url, how: 'article-page', text: '' }] : [],
    _prev: prev || null,
  };
  if (!d.doi) { try { const doi = await sniffPdfDoi(url); if (doi) { d.doi = doi; d.doi_source = 'pdf-bytes'; } } catch (_) {} }   // the PDF's own metadata
  if (!d.doi && mined.pii) { d.doi = await _doiFromPii(mined.pii); if (d.doi) d.doi_source = 'pii'; }
  // The viewer's tab title is usually the file name or the URL — not a title.
  if (!d.title && tab.title && !/\.pdf(\?|$)/i.test(tab.title) && !/^\d+-s2\.0-/.test(tab.title) && !/^(https?:\/\/)?[a-z0-9.-]+(:\d+)?\//i.test(tab.title)) d.title = tab.title;
  return d;
}
async function _resolveDetection(tabId) {
  let detection = null;
  try { detection = await chrome.tabs.sendMessage(tabId, { type: 'request-detection' }); } catch (_) { /* no content script */ }
  if (!detection || _isPdfDocument(detection)) {
    const cached = _tabDetections.get(tabId);
    if (cached && cached.source === 'pdf-tab' && cached.url === ((detection && detection.url) || cached.url)) detection = cached;   // built at paper-detected / onUpdated
    else { const d = await _pdfTabDetection(tabId, detection); if (d) { detection = d; _tabDetections.set(tabId, d); } }
  }
  if (!detection) detection = _tabDetections.get(tabId) || null;
  return detection;
}
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!info || info.status !== 'complete' || !looksLikePdfUrl(tab && tab.url)) return;
  let viaScript = null;
  try { viaScript = await chrome.tabs.sendMessage(tabId, { type: 'request-detection' }); } catch (_) {}
  if (viaScript && !_isPdfDocument(viaScript)) return;   // an HTML page with a pdf-looking URL: the content script owns it
  const cached = _tabDetections.get(tabId);
  if (cached && cached.source === 'pdf-tab' && cached.url === tab.url) return;   // paper-detected already built it
  try { const d = await _pdfTabDetection(tabId, viaScript); if (d) { _tabDetections.set(tabId, d); await _refreshBadge(tabId); } } catch (_) {}
});

async function _refreshBadge(tabId) {
  const d = _tabDetections.get(tabId);
  try {
    if (!_isPaperish(d)) {
      // V3.819 — a vendor page with items for sale gets a '+' instead of nothing.
      const n = _tabItemCounts.get(tabId) || 0;
      if (n > 0) {
        await chrome.action.setBadgeText({ tabId, text: '+' });
        await chrome.action.setBadgeBackgroundColor({ tabId, color: '#16a34a' });
        await chrome.action.setTitle({ tabId, title: `${n} item${n === 1 ? '' : 's'} to buy on this page — click to add to a purchase request` });
        return;
      }
      await chrome.action.setBadgeText({ tabId, text: '' });
      await chrome.action.setTitle({ tabId, title: 'No paper or item detected' });
      return;
    }

    // Show '?' immediately — the paper_index lookup is async and we
    // don't want the user staring at a blank toolbar while it runs.
    await chrome.action.setBadgeText({ tabId, text: '?' });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: '#6366f1' });
    await chrome.action.setTitle({
      tabId,
      title: `Detected: ${d.doi || d.arxiv_id || d.pmid || d.pdf_url}`,
    });

    const paperId = await _checkLibrary(d);
    // If the user navigated away while we were querying, the cached
    // detection will have been replaced. Don't clobber the new tab's badge.
    if (_tabDetections.get(tabId) !== d) return;
    if (paperId) {
      d.in_library_paper_id = paperId;
      await chrome.action.setBadgeText({ tabId, text: '✓' });
      await chrome.action.setBadgeBackgroundColor({ tabId, color: '#16a34a' });
      await chrome.action.setTitle({ tabId, title: `In library: ${paperId}` });
    }
  } catch (_) { /* tab may have closed */ }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Async handlers must return true and call sendResponse later.
  (async () => {
    try {
      if (!msg || !msg.type) return sendResponse({ ok: false, error: 'no type' });

      // V3.821 — which worker is answering (the popup's stale-load check, tests).
      if (msg.type === 'ping') return sendResponse({ ok: true, version: chrome.runtime.getManifest().version, handlers: ['whoami', 'get-items', 'add-item', 'price-watch-status', 'price-check-now', 'capture', 'pdf-probe', 'open-extension-details', 'last-capture'] });

      if (msg.type === 'paper-detected') {
        const tabId = sender && sender.tab && sender.tab.id;
        if (typeof tabId === 'number') {
          const incoming = msg.data || null;
          // V3.823 — a PDF document reported by a content script (the viewer
          // runs one in some builds) carries no identifiers of its own: build
          // the PDF-tab detection now, while the article this tab showed a
          // moment ago is still cached, instead of overwriting it.
          if (_isPdfDocument(incoming)) {
            let d = null; try { d = await _pdfTabDetection(tabId, incoming); } catch (_) {}
            _tabDetections.set(tabId, d || incoming);
          } else {
            _tabDetections.set(tabId, incoming);
          }
          _tabItemCounts.set(tabId, typeof msg.items === 'number' ? msg.items : 0);
          await _refreshBadge(tabId);
        }
        return sendResponse({ ok: true });
      }

      // V3.819 — "+ Item": the popup asks for what is for sale on the tab.
      if (msg.type === 'get-items') {
        const tabId = msg.tabId;
        if (typeof tabId !== 'number') return sendResponse({ ok: false, error: 'no tabId' });
        let data = null, how = 'content-script', why = '';
        try { data = await chrome.tabs.sendMessage(tabId, { type: 'request-items' }); }
        catch (_) { /* no content script on this tab */ }
        if (data && data.error) { why = data.error; data = null; }   // V3.821 — the scraper threw in the content script
        if (!data) {
          // The tab was open before this version was loaded (its content script
          // predates "+ Item"), or the script never ran there. Inject the scraper
          // now — the manifest holds `scripting` + <all_urls>, and executeScript
          // with `files` lands in the same isolated world as the `func` call.
          try {
            await chrome.scripting.executeScript({ target: { tabId }, files: ['scrape-items.js'] });
            // V3.821 — a throw inside the injected function is NOT surfaced by
            // executeScript (the result is just undefined), so catch it there.
            const res = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
              try { return { ok: true, data: window.__mcgheeScrapeItems ? window.__mcgheeScrapeItems() : null }; }
              catch (e) { return { ok: false, error: 'scrape failed: ' + ((e && e.message) || String(e)) }; }
            } });
            const out = (res && res[0] && res[0].result) || null;
            if (out && out.ok === false) why = out.error || 'scrape failed';
            else if (out && out.data) data = out.data;
            else if (!why) why = 'the scraper did not load on this tab';
            how = 'injected';
          } catch (e) {
            why = (e && e.message) || String(e);   // chrome://, the Web Store, a PDF viewer, a file:// tab without access
          }
        }
        if (data) { _tabItemCounts.set(tabId, data.confident ? data.items.length : 0); _tabScrapes.set(tabId, data); }
        // V3.823 — a PDF tab is not unreadable, it is a PDF: say so instead
        // (a content script in the viewer finds nothing for sale either).
        let pdfTab = false;
        try { const t = await chrome.tabs.get(tabId); const cached = _tabDetections.get(tabId); pdfTab = looksLikePdfUrl(t.url || t.pendingUrl || '') || !!(cached && cached.source === 'pdf-tab'); } catch (_) {}
        if (pdfTab && data && !data.confident) { data = null; }
        // The popup does not need the page text; keep the message small.
        return sendResponse({ ok: true, data: data ? Object.assign({}, data, { text: undefined, textChars: (data.text || '').length }) : null, how, why, pdfTab });
      }

      // V3.820 — price watch: what is due, and a manual run from the popup.
      if (msg.type === 'price-watch-status') {
        try { return sendResponse(Object.assign({ ok: true }, await watchStatus())); }
        catch (e) { return sendResponse({ ok: false, error: e.message || String(e) }); }
      }
      if (msg.type === 'price-check-now') {
        try { return sendResponse(Object.assign({ ok: true }, await runDueChecks({ max: msg.max || 5 }))); }
        catch (e) { return sendResponse({ ok: false, error: e.message || String(e) }); }
      }

      // V3.819 — write one captured item to the person's own queue. Nothing
      // is a purchase request yet: the RM Procurement page turns a capture
      // into a ticket (project, why, one-time/recurring are decided there),
      // and only an APPROVED ticket reaches the item catalogue.
      if (msg.type === 'add-item') {
        const profile = await getCurrentUser();
        if (!profile) return sendResponse({ ok: false, error: 'Sign in first.' });
        const it = msg.item || {};
        const name = String(it.name || '').trim();
        if (!name) return sendResponse({ ok: false, error: 'The item needs a name.' });
        const qty = parseFloat(msg.quantity);
        const price = (it.price === '' || it.price == null) ? null : parseFloat(it.price);
        const doc = {
          name: name.slice(0, 300),
          vendor: String(it.vendor || '').trim().slice(0, 120),
          catalogueNumber: String(it.catalogueNumber || '').trim().slice(0, 80),
          url: /^https?:\/\/\S+$/i.test(String(it.url || '')) ? String(it.url) : '',
          price: isFinite(price) && price >= 0 ? price : null,
          priceText: String(it.priceText || '').slice(0, 60),
          currency: String(it.currency || '').slice(0, 8),
          packSize: String(it.packSize || '').trim().slice(0, 80),
          description: String(it.description || '').trim().slice(0, 400),
          image: /^https?:\/\/\S+$/i.test(String(it.image || '')) ? String(it.image) : '',
          quantity: isFinite(qty) && qty > 0 ? qty : 1,
          note: String(msg.note || '').trim().slice(0, 500),
          source: String(it.source || 'manual').slice(0, 20),
          sourceUrl: String(msg.sourceUrl || it.url || '').slice(0, 1000),
          sourceHost: String(msg.sourceHost || '').slice(0, 120),
          status: 'captured',
          ticketId: null,
          capturedAtIso: new Date().toISOString(),
          capturedByUid: profile.uid,
          capturedByEmail: profile.email || '',
          extensionVersion: EXTENSION_VERSION,
        };
        try {
          const id = await firestoreCollectionAdd(`userData/${encodeURIComponent(profile.uid)}/procurementCaptures`, doc);
          // V3.820 — a price with a page: start (or extend) the watch on that
          // URL and keep the page as printed text, so the number can be re-read
          // and re-checked every three months.
          let watchId = null;
          if (doc.price != null && doc.url) {
            try {
              const scrape = typeof msg.tabId === 'number' ? _tabScrapes.get(msg.tabId) : null;
              const w = await recordObservation({ url: doc.url, price: doc.price, currency: doc.currency || 'USD', vendor: doc.vendor, catalogueNumber: doc.catalogueNumber, name: doc.name, method: 'capture' },
                { text: scrape && scrape.text, title: scrape && scrape.title });
              watchId = w ? w.id : null;
            } catch (e) { console.warn('[price-watch] observation not saved:', e && e.message); }
          }
          return sendResponse({ ok: true, id, watchId, rmUrl: `${RM_PROCUREMENT_URL}?capture=${encodeURIComponent(id)}` });
        } catch (e) {
          const m = (e && e.message) || String(e);
          // userData/{uid} is owner-only: a 403 here means the extension's
          // Google account is not the one with the lab-site profile.
          const friendly = e && e.code === 'permission-denied'
            ? 'Firestore refused the write. Sign out and back in with the same Google account you use on the lab site.'
            : m;
          return sendResponse({ ok: false, error: friendly });
        }
      }

      if (msg.type === 'get-detection') {
        // Popup asks for the active tab's detection. Re-query the content
        // script live so SPAs that updated meta tags after load are caught.
        const tabId = msg.tabId;
        if (typeof tabId !== 'number') return sendResponse({ ok: false, error: 'no tabId' });
        const detection = await _resolveDetection(tabId);   // content script → PDF tab (V3.823) → cache
        // Stamp in_library_paper_id so the popup can render the "Already
        // in library" banner. Cheap because _checkLibrary memoizes by id.
        if (detection && _isPaperish(detection)) {
          try {
            const paperId = await _checkLibrary(detection);
            if (paperId) detection.in_library_paper_id = paperId;
          } catch (_) {}
        }
        // V3.822/V3.823 — the page's own View PDF / Download PDF route: it
        // enables Capture when there is no citation_pdf_url, and the popup
        // shows it with an open link so the person can click it themselves,
        // pass a human check, and capture from the PDF tab.
        if (detection && _isPaperish(detection) && detection.source !== 'pdf-tab' && !detection.arxiv_id) {
          try { detection.pdf_candidates = (await pdfLinksOnTab(tabId)).slice(0, 3).map((c) => ({ url: c.url, how: c.how, text: c.text })); } catch (_) { /* chrome://, PDF viewer */ }
        }
        if (detection) _tabDetections.set(tabId, detection);
        return sendResponse({ ok: true, data: detection });
      }

      if (msg.type === 'sign-in') {
        const profile = await signInWithGoogle();
        return sendResponse({ ok: true, profile });
      }
      if (msg.type === 'sign-out') {
        await signOut();
        return sendResponse({ ok: true });
      }
      if (msg.type === 'whoami') {
        const profile = await getCurrentUser();
        return sendResponse({ ok: true, profile });
      }
      if (msg.type === 'ping-token') {
        try {
          const tok = await getValidIdToken();
          return sendResponse({ ok: !!tok, hasToken: !!tok });
        } catch (e) {
          return sendResponse({ ok: false, error: e.message });
        }
      }

      if (msg.type === 'search') {
        const query = String(msg.query || '').trim();
        if (!query) return sendResponse({ ok: false, error: 'empty query' });
        const classified = classifyQuery(query);
        try {
          if (!classified) return sendResponse({ ok: true, results: [] });
          let results = [];
          if (classified.kind === 'text') {
            results = await searchByText(classified.value, 8);
          } else {
            const single = await lookupByIdentifier(classified);
            if (single) results = [single];
          }
          // Mark each result that already has a paper_index entry. The
          // popup renders "✓ In library" instead of the "+ Add" button
          // for those rows. _checkLibrary memoizes by identifier so this
          // is cheap when the same paper appears across queries.
          await Promise.all(results.map(async (r) => {
            try {
              const paperId = await _checkLibrary({
                doi: r.doi || '',
                arxiv_id: r.arxiv_id || '',
                pmid: r.pmid || '',
              });
              if (paperId) r.in_library_paper_id = paperId;
            } catch (_) { /* not a fatal error path */ }
          }));
          return sendResponse({ ok: true, results, classified });
        } catch (e) {
          return sendResponse({ ok: false, error: e.message || String(e) });
        }
      }

      if (msg.type === 'add-by-metadata') {
        try {
          const result = await addMetadataOnly(msg.metadata, msg.source_url || '');
          _libraryCache.clear();
          return sendResponse({ ok: true, result });
        } catch (e) {
          return sendResponse({ ok: false, error: e.message || String(e) });
        }
      }

      if (msg.type === 'capture') {
        const tabId = msg.tabId;
        if (typeof tabId !== 'number') return sendResponse({ ok: false, error: 'no tabId' });
        // Re-query the content script for the latest detection — SPA pages
        // can mutate meta tags after the cached entry was written. A PDF tab
        // (V3.823) is built by the worker from the URL + the article page.
        const detection = await _resolveDetection(tabId);
        await _setCaptureState(tabId, { status: 'running', stage: 'Starting…', outcome: null, url: (detection && detection.url) || '' });
        try {
          // 6f: support manual overrides (URL or local file). The popup
          // ferries the file as an ArrayBuffer because Blob doesn't always
          // round-trip through chrome.runtime.sendMessage.
          const captureOpts = {
            onStage: (stage) => {
              console.log('[capture]', stage);
              _setCaptureState(tabId, { status: 'running', stage });   // V3.824 — survives the popup closing
              _tellPopup({ type: 'capture-stage', tabId, stage });
            },
          };
          if (msg.pdfUrlOverride) captureOpts.pdfUrlOverride = msg.pdfUrlOverride;
          if (msg.pdfBuffer)      captureOpts.pdfBuffer      = msg.pdfBuffer;
          if (msg.pdfFilename)    captureOpts.pdfFilename    = msg.pdfFilename;
          // V3.822 — the page's own PDF routes, and the two ways to fetch what
          // the worker cannot: as the page, and through Chrome's download
          // pipeline (pdf-fetch.js; the order lives in capture.js obtainPdf).
          if (!msg.pdfBuffer) {
            let links = [];
            try { links = (await pdfLinksOnTab(tabId)).map((c) => c.url); } catch (e) { console.warn('[capture] pdf links:', e && e.message); }   // a PDF viewer tab cannot be scripted
            const fromDetection = ((detection && detection.pdf_candidates) || []).map((c) => (c && c.url) || c).filter(Boolean);
            captureOpts.candidates = links.concat(fromDetection);
            captureOpts.strategies = { page: pageFetcher(tabId), download: browserDownloader() };
          }
          const result = await captureFromDetection(detection, captureOpts);
          // Visual confirmation on the toolbar — captured tabs flip
          // immediately to '✓'. The paper_index lookup will only return a
          // hit once the dashboard sync (6c) runs, so for the in-flight
          // session we trust the capture itself as the indicator.
          try { await chrome.action.setBadgeText({ tabId, text: '✓' }); } catch (_) {}
          try { await chrome.action.setBadgeBackgroundColor({ tabId, color: '#16a34a' }); } catch (_) {}
          // Drop the library-lookup cache so the next get-detection
          // doesn't return a stale "not in library" answer.
          _libraryCache.clear();
          // V3.824 — the outcome outlives the popup; a log line for forensics.
          const outcome = { ok: true, result: { paper_id: result.paper_id, title: result.title, size_bytes: result.size_bytes, hash: result.hash, pdf_source: result.pdf_source, dedup: result.dedup, doi: result.doi, doi_found: result.doi_found } };
          await _setCaptureState(tabId, { status: 'done', stage: '', outcome });
          _tellPopup({ type: 'capture-done', tabId, outcome });
          _logCapture({ ok: true, url: (detection && detection.url) || '', source: (detection && detection.source) || '', doi: result.doi || '', title: result.title || '', paper_id: result.paper_id, pdf_source: result.pdf_source, size_bytes: result.size_bytes, dedup: !!result.dedup });
          return sendResponse({ ok: true, result });
        } catch (e) {
          const out = { ok: false, error: e.message || String(e) };
          if (e && e.code === 'needs-file-access') { out.needsFileAccess = true; out.filename = e.filename || ''; out.path = e.path || ''; }
          if (e && Array.isArray(e.tried)) out.tried = e.tried;
          // V3.824 — keep it, show it on the toolbar, log it.
          await _setCaptureState(tabId, { status: 'failed', stage: '', outcome: out });
          _tellPopup({ type: 'capture-done', tabId, outcome: out });
          try { await chrome.action.setBadgeText({ tabId, text: '!' }); await chrome.action.setBadgeBackgroundColor({ tabId, color: '#dc2626' }); await chrome.action.setTitle({ tabId, title: 'Capture failed: ' + out.error.split('\n')[0].slice(0, 120) + ' — open the popup for details' }); } catch (_) {}
          _logCapture({ ok: false, url: (detection && detection.url) || '', source: (detection && detection.source) || '', doi: (detection && detection.doi) || '', title: (detection && detection.title) || '', error: out.error.slice(0, 2000), tried: out.tried || [], needsFileAccess: !!out.needsFileAccess, filename: out.filename || '', pdfUrlOverride: !!msg.pdfUrlOverride, pdfBuffer: !!msg.pdfBuffer });
          return sendResponse(out);
        }
      }

      // V3.824 — what happened to the last capture on this tab (the popup may have closed meanwhile).
      if (msg.type === 'last-capture') {
        if (typeof msg.tabId !== 'number') return sendResponse({ ok: false, error: 'no tabId' });
        return sendResponse({ ok: true, state: await _getCaptureState(msg.tabId) });
      }

      // V3.822 — diagnostics (nothing uploaded) and the settings page for "Allow access to file URLs".
      if (msg.type === 'pdf-probe') {
        if (typeof msg.tabId !== 'number') return sendResponse({ ok: false, error: 'no tabId' });
        try { return sendResponse(Object.assign({ ok: true }, await probePdfRoutes(msg.tabId, { url: msg.url, download: !!msg.download, downloadUrl: msg.downloadUrl }))); }
        catch (e) { return sendResponse({ ok: false, error: e.message || String(e) }); }
      }
      if (msg.type === 'open-extension-details') {
        try { await chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }); return sendResponse({ ok: true }); }
        catch (e) { return sendResponse({ ok: false, error: e.message || String(e) }); }
      }

      return sendResponse({ ok: false, error: `unknown type: ${msg.type}` });
    } catch (e) {
      return sendResponse({ ok: false, error: e.message || String(e) });
    }
  })();
  return true;  // keep the message channel open for async sendResponse
});

// Clean up cached detection when a tab closes.
chrome.tabs.onRemoved.addListener((tabId) => {
  _clearCaptureState(tabId);   // V3.824
  _tabDetections.delete(tabId);
  _tabItemCounts.delete(tabId);
  _tabScrapes.delete(tabId);
});

// Re-run badge refresh on tab activation (so switching tabs updates icon).
chrome.tabs.onActivated.addListener(({ tabId }) => _refreshBadge(tabId));
